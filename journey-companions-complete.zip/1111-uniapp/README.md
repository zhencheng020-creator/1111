# 征途生灵 · uni-app 迁移目录

这是从 `/workspace/1111` 复制出的独立迁移源目录，不覆盖 Web 原项目。页面与组件使用 uni-app 原生模板标签（`view`、`text`、`image`、`button`、`progress`），Pinia 数据模型和真实素材映射保持一致。

## 命令

- `npm run build`：使用正式 `@dcloudio/vite-plugin-uni` 编译微信小程序，产物为 `dist/build/mp-weixin`。
- `npm test`：运行迁移契约与平台适配检查。
- `npm run build:contract`：只执行不依赖编译器的静态迁移校验。

微信编译包已配置 AppID `wxae505c34c3713d61`；未包含 AppSecret。微信开发者工具仍需在外部环境导入验证。

## Windows PowerShell / macOS / Linux

微信小程序构建使用正式 uni-app CLI 的跨平台 Node 包装器，不需要在 PowerShell 中设置 Bash 风格的环境变量：

```powershell
npm install
npm run build
node scripts/verify-mp-build.mjs
```

产物位于 `dist/build/mp-weixin`。包装器会设置绝对输入/输出路径、调用 `uni build -p mp-weixin`，并在编译成功后自动运行产物验证。
