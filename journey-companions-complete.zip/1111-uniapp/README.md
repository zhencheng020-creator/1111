# 征途生灵 · uni-app 迁移目录

这是从 `/workspace/1111` 复制出的独立迁移源目录，不覆盖 Web 原项目。页面与组件使用 uni-app 原生模板标签（`view`、`text`、`image`、`button`、`progress`），Pinia 数据模型和真实素材映射保持一致。

## 命令

- `npm run build`：使用正式 `@dcloudio/vite-plugin-uni` 编译微信小程序，产物为 `dist/build/mp-weixin`。
- `npm test`：运行迁移契约与平台适配检查。
- `npm run build:contract`：只执行不依赖编译器的静态迁移校验。

微信开发者工具和真实 AppID 仍需在外部环境配置；当前目录的编译包使用 `touristappid` 占位值。
