import type { MapNode } from './models.ts';

export const mapNodes: readonly MapNode[] = [
  { id: 'departure', name: '同行启程站', kind: 'mission', initialStatus: 'current', missionId: null, storyId: null },
  { id: 'grassland', name: '草地补给站', kind: 'mission', initialStatus: 'locked', missionId: 'grassland-supply', storyId: null },
  { id: 'snow-mountain', name: '雪山挑战站', kind: 'mission', initialStatus: 'locked', missionId: null, storyId: null },
  { id: 'bridge', name: '桥梁协作站', kind: 'mission', initialStatus: 'locked', missionId: null, storyId: null },
  { id: 'silent-partner', name: '无声伙伴故事站', kind: 'story', initialStatus: 'locked', missionId: null, storyId: null },
  { id: 'finish', name: '同行终点站', kind: 'finish', initialStatus: 'locked', missionId: null, storyId: null },
];
