import type { AchievementBadge } from './models.ts';

// 尚未提供徽章定义、获得条件及素材。
export const badges: readonly AchievementBadge[] = [];
