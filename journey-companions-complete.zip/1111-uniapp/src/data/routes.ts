import type { Route } from './models.ts';
import { mapNodes } from './mapNodes.ts';

// 三条路线暂共用需求列出的六个节点，保留各自独立的节点列表。
export const routes: readonly Route[] = [
  { id: 'easy', name: '轻体验线', durationMinutes: { min: 40, max: 50 }, nodeIds: mapNodes.map(node => node.id) },
  { id: 'normal', name: '标准探索线', durationMinutes: { min: 60, max: 75 }, nodeIds: mapNodes.map(node => node.id) },
  { id: 'challenge', name: '伙伴挑战线', durationMinutes: { min: 75, max: 90 }, nodeIds: mapNodes.map(node => node.id) },
];
