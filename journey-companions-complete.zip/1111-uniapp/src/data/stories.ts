import type { Story } from './models.ts';

// 尚未提供真实史料及出处，不编造历史故事。
export const stories: readonly Story[] = [];
