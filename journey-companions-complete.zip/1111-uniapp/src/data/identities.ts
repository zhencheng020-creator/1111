import type { Identity } from './models.ts';

export const identities: readonly Identity[] = [
  { id: 'support', name: '后勤员', ability: '资源管理', skill: 'resource_bonus' },
  { id: 'scout', name: '侦察员', ability: '路线探索', skill: 'map_bonus' },
  { id: 'medical', name: '医护员', ability: '伙伴恢复', skill: 'heal_bonus' },
  { id: 'record', name: '记录员', ability: '故事收集', skill: 'story_bonus' },
];
