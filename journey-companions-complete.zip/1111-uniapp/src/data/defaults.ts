import type { PartnerId, PartnerStatus, Resource, User } from './models.ts';
import { partners } from './partners.ts';

export const initialResources: Readonly<Resource> = Object.freeze({
  energy: 5,
  food: 10,
  medical: 3,
  badge: 0,
});

export const partnerCareTrustThreshold = 2;

/** 仅创建独立的初始数据，不保存或更新任何全局状态。 */
export function createInitialUser(id: string): User {
  if (!id.trim()) throw new Error('用户 ID 不能为空');
  return { id, identity: null, partner: null, route: null, progress: 0 };
}

export function createInitialResources(): Resource {
  return { ...initialResources };
}

export function createInitialPartnerStatus(id: PartnerId): PartnerStatus {
  const partner = partners.find(item => item.id === id);
  if (!partner) throw new Error(`未知伙伴 ID：${id}`);
  return { energy: partner.energy, comfort: partner.comfort, trust: partner.trust };
}
