import type { Mission } from './models.ts';

/** 仅收录原需求给出的任务示例，其他节点任务待提供。 */
export const missions: readonly Mission[] = [
  {
    id: 'grassland-supply',
    nodeId: 'grassland',
    title: '草地补给站',
    description: '选择补充粮食或让伙伴休息。',
    choices: [
      { id: 'supply-food', label: '补充粮食', effect: { resources: { food: 3, energy: -1 } } },
      { id: 'rest-partner', label: '伙伴休息', effect: { partner: { comfort: 2, trust: 1 } } },
    ],
  },
];
