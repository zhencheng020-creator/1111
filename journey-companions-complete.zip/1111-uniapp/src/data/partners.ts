import type { Partner } from './models.ts';

export const partners: readonly Partner[] = [
  { id: 'xiaowei', name: '小卫', type: '探索型', energy: 5, comfort: 5, trust: 5, assetPath: 'characters/xiaowei.png' },
  { id: 'chifeng', name: '赤风', type: '挑战型', energy: 5, comfort: 4, trust: 5, assetPath: 'characters/chifeng.png' },
  { id: 'feiyu', name: '飞羽', type: '信息型', energy: 4, comfort: 5, trust: 4, assetPath: 'characters/feiyu.png' },
  // 需求未给出小驮、阿牛初始数值，暂统一采用 5/5/5，等待产品确认。
  { id: 'xiaotuo', name: '小驮', type: '资源型', energy: 5, comfort: 5, trust: 5, assetPath: 'characters/xiaotuo.png' },
  { id: 'aniu', name: '阿牛', type: '稳定型', energy: 5, comfort: 5, trust: 5, assetPath: 'characters/aniu.png' },
];
