/** 框架无关的数据契约；不包含状态更新、页面路由或 UI 实现。 */
export type IdentityId = 'support' | 'scout' | 'medical' | 'record';
export type PartnerId = 'xiaowei' | 'chifeng' | 'feiyu' | 'xiaotuo' | 'aniu';
export type RouteId = 'easy' | 'normal' | 'challenge';
export type MapNodeId = 'departure' | 'grassland' | 'snow-mountain' | 'bridge' | 'silent-partner' | 'finish';
export type MissionId = string;
export type StoryId = string;
export type BadgeId = string;

export interface User {
  id: string;
  identity: IdentityId | null;
  partner: PartnerId | null;
  route: RouteId | null;
  /** 已完成任务数；后续状态管理负责与 completedTasks 保持一致。 */
  progress: number;
}

export interface Identity {
  readonly id: IdentityId;
  readonly name: string;
  readonly ability: string;
  readonly skill: 'resource_bonus' | 'map_bonus' | 'heal_bonus' | 'story_bonus';
}

export interface PartnerStatus {
  energy: number;
  comfort: number;
  trust: number;
}

/** 静态伙伴定义中的数值是初始值，游戏过程中不应直接修改目录数据。 */
export interface Partner extends Readonly<PartnerStatus> {
  readonly id: PartnerId;
  readonly name: string;
  readonly type: '探索型' | '挑战型' | '信息型' | '资源型' | '稳定型';
  /** 相对于 src/assets/ 的素材路径；实际图片尚未提供。 */
  readonly assetPath: string;
}

export interface Resource {
  /** 人物体力，与 PartnerStatus.energy 分开管理。 */
  energy: number;
  food: number;
  medical: number;
  /** 已获得徽章数；具体徽章 ID 保存在 JourneyState.badges 中。 */
  badge: number;
}

export interface Route {
  readonly id: RouteId;
  readonly name: string;
  readonly durationMinutes: Readonly<{ min: number; max: number }>;
  /** Demo 共用六个节点，路线差异机制尚未给出。 */
  readonly nodeIds: readonly MapNodeId[];
}

/** UI 的 Completed 对应数据状态 complete，与需求中的地图状态一致。 */
export type MapNodeStatus = 'locked' | 'current' | 'complete' | 'story';
export interface MapNode {
  readonly id: MapNodeId;
  readonly name: string;
  readonly kind: 'mission' | 'story' | 'finish';
  readonly initialStatus: MapNodeStatus;
  /** null 表示内容待补充，不能当作已完成任务或已解锁故事。 */
  readonly missionId: MissionId | null;
  readonly storyId: StoryId | null;
}

export interface MissionEffect {
  /** 数值均为增量；未出现的字段表示无变化。 */
  readonly resources?: Readonly<Partial<Resource>>;
  readonly partner?: Readonly<Partial<PartnerStatus>>;
  readonly unlockStoryIds?: readonly StoryId[];
  readonly awardBadgeIds?: readonly BadgeId[];
}

export interface MissionChoice {
  readonly id: string;
  readonly label: string;
  readonly effect: MissionEffect;
}

export interface Mission {
  readonly id: MissionId;
  readonly nodeId: MapNodeId;
  readonly title: string;
  readonly description: string;
  readonly choices: readonly MissionChoice[];
}

export interface StorySource {
  readonly title: string;
  readonly citation: string;
  readonly url?: string;
}

/** 只有提供可核验史料来源的内容才应加入故事目录。 */
export interface Story {
  readonly id: StoryId;
  readonly title: string;
  readonly content: string;
  readonly sources: readonly StorySource[];
}

export interface AchievementBadge {
  readonly id: BadgeId;
  readonly name: string;
  readonly description: string;
  readonly assetPath: string;
}

/** 后续状态管理采用的数据形状；此处不实现 store 或持久化。 */
export interface JourneyState {
  user: User;
  resources: Resource;
  partnerStatus: PartnerStatus | null;
  nodeStatuses: Record<MapNodeId, MapNodeStatus>;
  completedTasks: MissionId[];
  stories: StoryId[];
  badges: BadgeId[];
}

/** 最终档案须有完整选择；这里只定义契约，不生成档案。 */
export interface Archive {
  identity: IdentityId;
  partner: PartnerId;
  route: RouteId;
  completedTasks: MissionId[];
  stories: StoryId[];
  badges: BadgeId[];
}
