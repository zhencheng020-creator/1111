export type PageName = 'Home' | 'Identity' | 'Partner' | 'Route' | 'Map' | 'Mission' | 'Status' | 'Archive';
