<script setup lang="ts">
withDefaults(defineProps<{ selected?: boolean }>(), { selected: false });
</script>
<template><view class="journey-card" :class="{ 'journey-card--selected': selected }" data-figma="Card"><slot /></view></template>
