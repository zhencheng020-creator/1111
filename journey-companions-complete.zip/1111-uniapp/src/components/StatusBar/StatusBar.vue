<script setup lang="ts">
defineProps<{ label: string; value: number; max: number; icon?: string }>();
</script>
<template><view class="status-bar" data-figma="StatusBar"><image v-if="icon" :src="icon" mode="aspectFit" /><view class="status-bar__body"><view class="status-bar__label"><text>{{ label }}</text><text>{{ value }}/{{ max }}</text></view><progress :percent="max ? value / max * 100 : 0" activeColor="#739B56" /></view></view></template>
<style scoped>.status-bar{display:flex;align-items:center;gap:16rpx}.status-bar image{width:40rpx;height:40rpx}.status-bar__body{flex:1}.status-bar__label{display:flex;justify-content:space-between;margin-bottom:4rpx}.status-bar progress{width:100%;height:14rpx}</style>
