<script setup lang="ts">
withDefaults(defineProps<{ name: string; icon?: string; unlocked?: boolean }>(), { unlocked: false });
</script>
<template><view class="journey-card badge" :class="{ 'badge--locked': !unlocked }" data-figma="Badge"><image v-if="icon" :src="icon" mode="aspectFit" /><text>{{ name }}</text></view></template>
<style scoped>.badge{display:flex;align-items:center;gap:16rpx}.badge image{width:84rpx;height:84rpx}.badge--locked{opacity:.5}</style>
