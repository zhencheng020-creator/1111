<script setup lang="ts">
const props = withDefaults(defineProps<{ id: string; name: string; description: string; skill: string; icon?: string; selected?: boolean; onSelect?: (id: string) => void }>(), { selected: false });
const emit = defineEmits<{ select: [id: string] }>();
function select() { props.onSelect?.(props.id); emit('select', props.id); }
</script>
<template>
  <button class="journey-card identity-card" :class="{ 'journey-card--selected': selected }" data-figma="Card/Identity" :aria-pressed="selected" @tap="select">
    <view class="identity-card__main">
      <view class="identity-card__portrait"><image v-if="icon" :src="icon" mode="aspectFill" /><text v-else>{{ name.slice(0, 1) }}</text></view>
      <view class="identity-card__content"><text class="identity-card__name">{{ name }}</text><text class="identity-card__skill">{{ skill }}</text><text>{{ description }}</text></view>
      <text class="identity-card__check">{{ selected ? '✓' : '' }}</text>
    </view>
    <view class="identity-card__footer"><text class="journey-muted">同行身份</text><text>{{ selected ? '已选择' : '点击选择' }}</text></view>
  </button>
</template>
<style scoped>
.identity-card { text-align:left; padding:28rpx; } .identity-card__main { display:flex; gap:20rpx; align-items:flex-start; } .identity-card__portrait { width:144rpx; height:144rpx; display:flex; align-items:center; justify-content:center; border:2rpx dashed var(--journey-orange); border-radius:24rpx; background:rgba(232,107,42,.08); } .identity-card__portrait image { width:100%; height:100%; } .identity-card__content { flex:1; display:flex; flex-direction:column; gap:10rpx; } .identity-card__name { font-size:36rpx; font-weight:700; } .identity-card__skill { align-self:flex-start; padding:4rpx 12rpx; color:var(--field-green); } .identity-card__check { width:40rpx; height:40rpx; text-align:center; border:2rpx solid var(--journey-orange); border-radius:50%; } .identity-card__footer { display:flex; justify-content:space-between; margin-top:24rpx; padding-top:18rpx; border-top:1rpx solid rgba(59,41,32,.12); }
</style>
