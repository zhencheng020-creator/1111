<script setup lang="ts">
interface Choice { id: string; label: string }
const props = defineProps<{ title: string; description: string; choices: readonly Choice[]; selectedChoiceId?: string | null; onChoice?: (id: string) => void }>();
const emit = defineEmits<{ choice: [id: string] }>();
function choose(id: string) { props.onChoice?.(id); emit('choice', id); }
</script>
<template><view class="journey-card mission-card" data-figma="Card/Mission"><text class="mission-card__title">{{ title }}</text><text class="mission-card__description">{{ description }}</text><view class="mission-card__choices"><button v-for="choice in choices" :key="choice.id" class="journey-button" :class="{ 'journey-button--secondary': selectedChoiceId === choice.id }" :aria-pressed="selectedChoiceId === choice.id" @tap="choose(choice.id)"><text>{{ choice.label }}</text></button></view></view></template>
<style scoped>.mission-card{border-top:8rpx solid var(--journey-orange)}.mission-card__title{display:block;font-size:40rpx;font-weight:700;margin-bottom:14rpx}.mission-card__description{display:block;line-height:1.6}.mission-card__choices{display:flex;flex-direction:column;gap:8rpx;margin-top:24rpx}</style>
