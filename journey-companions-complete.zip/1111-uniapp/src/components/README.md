# uni-app components

组件名称与 Web/Figma Design System 保持一致。模板只使用 uni-app 组件标签，业务状态通过 Props 输入，用户操作通过 `select`、`choice`、`click` 等事件回传。
