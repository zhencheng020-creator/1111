<script setup lang="ts">
const props = withDefaults(defineProps<{ name: string; status: 'locked'|'current'|'complete'|'story'; icon?: string; onClick?: () => void }>(), { status: 'locked' });
const emit = defineEmits<{ click: [] }>();
function click() { if (props.status === 'locked') return; props.onClick?.(); emit('click'); }
</script>
<template><button class="journey-card map-node" :class="`map-node--${status}`" :disabled="status === 'locked'" data-figma="MapNode" @tap="click"><image v-if="icon" :src="icon" mode="aspectFit" /><text class="map-node__name">{{ name }}</text><text class="map-node__status">{{ status === 'locked' ? '未解锁' : status === 'current' ? '当前' : status === 'complete' ? '已完成' : '故事' }}</text></button></template>
<style scoped>.map-node{display:flex;align-items:center;gap:18rpx;text-align:left}.map-node image{width:72rpx;height:72rpx}.map-node__name{flex:1;font-size:30rpx;font-weight:700}.map-node__status{padding:6rpx 12rpx;border-radius:12rpx;background:rgba(115,155,86,.14)}.map-node--locked{opacity:.5}.map-node--current{border-color:var(--journey-orange)}.map-node--story{border-color:var(--sky-blue)}</style>
