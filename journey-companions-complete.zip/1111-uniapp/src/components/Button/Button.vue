<script setup lang="ts">
const props = withDefaults(defineProps<{ text: string; variant?: 'Primary'|'Secondary'|'Disabled'; disabled?: boolean; onClick?: () => void }>(), { variant: 'Primary', disabled: false });
const emit = defineEmits<{ click: [] }>();
function click() { if (props.disabled || props.variant === 'Disabled') return; props.onClick?.(); emit('click'); }
</script>
<template><button class="journey-button" :class="`journey-button--${variant.toLowerCase()}`" :disabled="disabled || variant === 'Disabled'" data-figma="Button" @tap="click"><text>{{ text }}</text></button></template>
