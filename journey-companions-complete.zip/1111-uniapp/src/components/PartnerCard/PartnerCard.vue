<script setup lang="ts">
const props = withDefaults(defineProps<{ id: string; name: string; type: string; avatar?: string; energy: number; comfort: number; trust: number; selected?: boolean; onSelect?: (id: string) => void }>(), { selected: false });
const emit = defineEmits<{ select: [id: string] }>();
const condition = () => props.trust < 2 ? 'injured' : props.energy < 3 || props.comfort < 5 ? 'recovering' : 'normal';
function select() { props.onSelect?.(props.id); emit('select', props.id); }
</script>
<template>
  <button class="journey-card partner-card" :class="[{ 'journey-card--selected': selected }, `partner-card--${condition()}`]" data-figma="Card/Partner" @tap="select">
    <image v-if="avatar" class="partner-card__avatar" :src="avatar" mode="aspectFit" /><view v-else class="partner-card__avatar partner-card__placeholder"><text>{{ name }}</text></view>
    <view class="partner-card__body"><view class="partner-card__heading"><text class="partner-card__name">{{ name }}</text><text class="journey-muted">{{ type }}</text></view>
      <view class="partner-card__stats"><view><text>体力 {{ energy }}</text><progress :percent="energy * 10" activeColor="#E86B2A" /></view><view><text>安心 {{ comfort }}</text><progress :percent="comfort * 10" activeColor="#739B56" /></view><view><text>信任 {{ trust }}</text><progress :percent="trust * 10" activeColor="#5B8FB9" /></view></view>
      <text class="journey-muted">{{ condition() === 'injured' ? '需要照顾' : condition() === 'recovering' ? '恢复中' : '状态良好' }}</text>
    </view>
  </button>
</template>
<style scoped>.partner-card{display:flex;gap:24rpx;text-align:left}.partner-card__avatar{width:220rpx;height:220rpx;flex-shrink:0}.partner-card__placeholder{display:flex;align-items:center;justify-content:center;background:rgba(115,155,86,.1);border-radius:18rpx}.partner-card__body{flex:1}.partner-card__heading{display:flex;flex-direction:column;gap:6rpx}.partner-card__name{font-size:36rpx;font-weight:700}.partner-card__stats{display:flex;flex-direction:column;gap:10rpx;margin:18rpx 0}.partner-card progress{width:100%;height:14rpx}</style>
