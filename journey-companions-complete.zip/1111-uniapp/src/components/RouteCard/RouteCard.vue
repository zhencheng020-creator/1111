<script setup lang="ts">
const props = withDefaults(defineProps<{ id: string; name: string; time: string; difficulty: string; description: string; selected?: boolean; scene?: string; onSelect?: (id: string) => void }>(), { selected: false });
const emit = defineEmits<{ select: [id: string] }>();
function select() { props.onSelect?.(props.id); emit('select', props.id); }
</script>
<template><button class="journey-card route-card" :class="{ 'journey-card--selected': selected }" data-figma="Card/Route" @tap="select"><image v-if="scene" class="route-card__scene" :src="scene" mode="aspectFill" /><view class="route-card__head"><text class="route-card__name">{{ name }}</text><text class="route-card__badge">{{ difficulty }}</text></view><text>{{ description }}</text><text class="journey-muted">预计 {{ time }}</text></button></template>
<style scoped>.route-card{text-align:left}.route-card__scene{width:100%;height:220rpx;border-radius:16rpx;margin-bottom:16rpx}.route-card__head{display:flex;justify-content:space-between;align-items:center;margin-bottom:10rpx}.route-card__name{font-size:36rpx;font-weight:700}.route-card__badge{padding:6rpx 12rpx;border-radius:12rpx;background:rgba(91,143,185,.14);color:var(--sky-blue)}</style>
