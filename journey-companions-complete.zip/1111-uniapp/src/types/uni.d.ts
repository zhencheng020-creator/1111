declare const uni: {
  navigateTo(options: { url: string; success?: () => void; fail?: (error: unknown) => void }): void;
  redirectTo(options: { url: string; success?: () => void; fail?: (error: unknown) => void }): void;
  navigateBack(options?: { delta?: number }): void;
  getStorageSync(key: string): unknown;
  setStorageSync(key: string, value: unknown): void;
  removeStorageSync(key: string): void;
  getSystemInfoSync(): { windowWidth: number; windowHeight: number; safeArea?: { top: number; bottom: number; left: number; right: number } };
};
