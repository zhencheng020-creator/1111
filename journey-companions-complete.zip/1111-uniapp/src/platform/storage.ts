export const journeyStorageKey = 'journey-companions:state:v1';

export interface JourneyStorageAdapter {
  get<T>(key: string): T | null;
  set<T>(key: string, value: T): void;
  remove(key: string): void;
}

export const uniStorageAdapter: JourneyStorageAdapter = {
  get<T>(key) {
    try {
      const value = uni.getStorageSync(key);
      return value === '' || value === null || value === undefined ? null : value as T;
    } catch { return null; }
  },
  set<T>(key, value) { uni.setStorageSync(key, value); },
  remove(key) { uni.removeStorageSync(key); },
};

export interface JourneyStorageV1 {
  version: 1;
  updatedAt: number;
  user: { identity: string | null; partner: string | null; route: string | null; progress: number };
  partner: { partner: { id: string; name: string; energy: number; comfort: number; trust: number } | null };
  route: { routeId: string | null; nodeStatuses: Record<string, string>; currentNodeId: string | null; unlockedStoryIds: string[] };
  mission: { records: readonly unknown[]; activeMissionId: string | null; selectedChoiceId: string | null };
  resource: { energy: number; food: number; medical: number; earnedBadgeIds: string[] };
}
