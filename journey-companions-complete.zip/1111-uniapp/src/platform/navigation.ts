import type { PageName } from '../router/types.ts';

const pagePaths: Record<PageName, string> = {
  Home: '/src/pages/Home/Home', Identity: '/src/pages/Identity/Identity', Partner: '/src/pages/Partner/Partner',
  Route: '/src/pages/Route/Route', Map: '/src/pages/Map/Map', Mission: '/src/pages/Mission/Mission',
  Status: '/src/pages/Status/Status', Archive: '/src/pages/Archive/Archive',
};

export function pageUrl(page: PageName, params?: Record<string, string | number | undefined>): string {
  const query = Object.entries(params ?? {}).filter(([, value]) => value !== undefined)
    .map(([key, value]) => `${encodeURIComponent(key)}=${encodeURIComponent(String(value))}`).join('&');
  return `${pagePaths[page]}${query ? `?${query}` : ''}`;
}

export function navigate(page: PageName, params?: Record<string, string | number | undefined>): void {
  uni.navigateTo({ url: pageUrl(page, params) });
}
export function redirect(page: PageName, params?: Record<string, string | number | undefined>): void {
  uni.redirectTo({ url: pageUrl(page, params) });
}
export function back(delta = 1): void { uni.navigateBack({ delta }); }
