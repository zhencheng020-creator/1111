import type { PageName } from '../router/types.ts';

/** pages.json 的真实页面路径；这里不能使用 src/pages，因为它不是小程序运行时路由根。 */
export const pagePaths: Record<PageName, string> = {
  Home: '/pages/Home/Home',
  Identity: '/pages/Identity/Identity',
  Partner: '/pages/Partner/Partner',
  Route: '/pages/Route/Route',
  Map: '/pages/Map/Map',
  Mission: '/pages/Mission/Mission',
  Status: '/pages/Status/Status',
  Archive: '/pages/Archive/Archive',
};

export function pageUrl(page: PageName, params?: Record<string, string | number | undefined>): string {
  const query = Object.entries(params ?? {}).filter(([, value]) => value !== undefined)
    .map(([key, value]) => `${encodeURIComponent(key)}=${encodeURIComponent(String(value))}`).join('&');
  return `${pagePaths[page]}${query ? `?${query}` : ''}`;
}

function reportFailure(action: string, url: string, error: unknown): void {
  console.error(`[征途生灵] ${action} 跳转失败`, { url, error });
}

export function navigate(page: PageName, params?: Record<string, string | number | undefined>): void {
  const url = pageUrl(page, params);
  uni.navigateTo({ url, fail: error => reportFailure('navigateTo', url, error) });
}
export function redirect(page: PageName, params?: Record<string, string | number | undefined>): void {
  const url = pageUrl(page, params);
  uni.redirectTo({ url, fail: error => reportFailure('redirectTo', url, error) });
}
export function back(delta = 1): void {
  uni.navigateBack({ delta, fail: error => reportFailure('navigateBack', `delta=${delta}`, error) });
}
