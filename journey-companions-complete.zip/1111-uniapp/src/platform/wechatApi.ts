/**
 * 微信能力占位层：只定义迁移契约，不伪造登录、网络或真机能力结果。
 * Phase 9.3 页面暂不调用这些方法；接入后只需替换实现，不改页面业务逻辑。
 */
export interface WechatLoginResult { code: string; authState?: unknown }
export interface WechatRequestOptions { url: string; method?: 'GET'|'POST'|'PUT'|'DELETE'; data?: unknown; header?: Record<string, string> }
export interface WechatUploadOptions { url: string; filePath: string; name: string; formData?: Record<string, string> }
export interface WechatLocation { latitude: number; longitude: number; accuracy?: number }
export interface WechatShareOptions { title: string; path?: string; imageUrl?: string }
export interface WechatApiAdapter {
  login(): Promise<WechatLoginResult>;
  request<T>(options: WechatRequestOptions): Promise<T>;
  upload(options: WechatUploadOptions): Promise<{ url: string; statusCode: number }>;
  getLocation(): Promise<WechatLocation>;
  openMap(location: WechatLocation): Promise<void>;
  share(options: WechatShareOptions): Promise<void>;
  requestSubscribeMessage(templateIds: readonly string[]): Promise<Record<string, string>>;
}

function pending(feature: string): never {
  throw new Error(`WECHAT_API_NOT_IMPLEMENTED: ${feature} 需要在微信开发者工具/真机环境接入`);
}

/** 默认实现明确失败，防止开发环境把“未接入”误判为成功。 */
export const wechatApiPlaceholder: WechatApiAdapter = {
  async login() { return pending('login'); },
  async request<T>(_options: WechatRequestOptions) { return pending(`request<T>`); },
  async upload(_options: WechatUploadOptions) { return pending('uploadFile'); },
  async getLocation() { return pending('getLocation'); },
  async openMap(_location: WechatLocation) { return pending('openLocation/map'); },
  async share(_options: WechatShareOptions) { return pending('share'); },
  async requestSubscribeMessage(_templateIds: readonly string[]) { return pending('requestSubscribeMessage'); },
};
