# 征途生灵状态管理 · Step 5

使用 Vue 3 Composition API 和 Pinia setup store：`ref` 保存状态，`computed` 生成派生状态，函数作为 action。每个 Vue 应用使用一个 Pinia 实例，所有页面共享同一次同行状态。

## 目录与 Pinia 代码

```text
store/
├── userStore.ts
├── partnerStore.ts
├── routeStore.ts
├── missionStore.ts
├── resourceStore.ts
├── archiveStore.ts
├── validation.ts
├── index.ts
├── examples/
│   └── useJourneyPageExample.ts
└── README.md
```

| 代码 | 状态及派生值 | 主要 actions |
| --- | --- | --- |
| [userStore](userStore.ts) | identity、partner、route 初始 null；progress 初始 0 | selectIdentity(id)、selectPartner(id)、selectRoute(id)、updateProgress(amount=1) |
| [partnerStore](partnerStore.ts) | partner 初始 null，选中后包含 id/name/energy/comfort/trust；needsCare | updateEnergy(delta)、increaseComfort(amount=1)、increaseTrust(amount=1) |
| [resourceStore](resourceStore.ts) | energy=5、food=10、medical=3；earnedBadgeIds=[]、badge=0 | consumeFood(amount=1)、addFood(amount=1)、recoverEnergy(amount=1)、addBadge(id) |
| [routeStore](routeStore.ts) | routeId、nodeStatuses、currentNodeId、nodes、unlockedStoryIds、isComplete | unlockNode(id)、completeNode(id)、setCurrentNode(id)、unlockStory(id) |
| [missionStore](missionStore.ts) | currentMission、selectedChoice、result 初始 null；records=[]、completedTasks=[] | openMission(id)、selectChoice(choiceId)、applyEffect() |
| [archiveStore](archiveStore.ts) | 自动派生 archive、canGenerate、isComplete | generateArchive() |

`index.ts` 统一导出所有 store，并提供 `resetJourney(pinia?)` 重置整次同行。`validation.ts` 提供输入校验、只读快照和带 code 的 `JourneyError`。

## Store 之间的关系

```mermaid
flowchart LR
  P[页面：Props 输入、事件协调] --> U[userStore]
  P --> M[missionStore]
  U --> B[partnerStore]
  U --> R[routeStore]
  M --> B
  M --> E[resourceStore]
  M --> R
  M --> U
  U --> A[archiveStore]
  M --> A
  R --> A
  E --> A
```

- 用户选择伙伴时初始化 partnerStore，选择路线时初始化 routeStore；同项重选保留状态。已有完成任务后改选会抛出 `SELECTION_LOCKED`，需要先调用 `resetJourney()`，避免旧任务记录与新选择混用。
- missionStore 是任务提交入口：读取目录中的方案，先检查选择、当前节点、数值、奖励 ID 和进度，再更新伙伴及资源、记录故事/徽章、完成节点、解锁下一节点、增加一次进度并保存结果快照。
- routeStore 管理节点和已解锁故事 ID；resourceStore 管理资源和已获得徽章 ID。徽章数量由唯一 ID 列表计算，避免状态栏与档案数量不一致。
- archiveStore 读取用户选择、任务完成记录、故事 ID 和徽章 ID，自动生成当前档案预览。没有第二份可写的任务或奖励列表，避免副本状态漂移。
- 各 store 在 setup 内取得依赖，绑定同一个 Pinia 实例；多个应用或测试实例之间状态独立。

## 状态更新规则

1. 用户、伙伴和路线选择使用数据目录中的 ID。展示中文名称时通过 `src/data` 目录查询。伙伴状态是独立副本，不修改静态初始值。
2. 人物体力在 resourceStore.energy；伙伴体力在 partnerStore.partner.energy。伙伴数值没有未定义的上限，5+2 会得到 7；trust<2 时 needsCare 为 true。
3. 资源数量和伙伴状态不允许负数或无穷值。资源不足、非法数字或未知 ID 会抛出 JourneyError；单个 delta 更新和任务预校验失败不会留下部分数值更新。
4. 地图采用 locked/current/complete/story。前序节点完成后才可解锁下一节点；故事节点解锁时为 story，已完成节点不能降级回 current。completeNode 只完成当前已解锁节点；任务提交还会自动解锁下一节点。
5. selectChoice 仅保存方案，applyEffect 执行已选方案。页面不要传入任意效果对象。已完成任务再次提交或重开会返回原结果，不重复效果、任务记录或进度。
6. 普通任务流程只调用 missionStore.applyEffect；它会自动调用 userStore.updateProgress。页面不要另外增加同一次任务的进度，也不要直接写 Pinia 状态字段。
7. addBadge(id) 要求 ID 存在于徽章目录，重复 ID 不增加数量。任务徽章奖励使用 effect.awardBadgeIds；不能仅设置 resources.badge 增量。故事奖励使用 effect.unlockStoryIds，并要求目录中有正文和来源。
8. 身份、伙伴、路线选择完整后 archive 自动提供预览；isComplete 还要求所有节点完成且进度与任务记录数量一致。generateArchive 返回独立副本，导出或修改副本不会写回 store。
9. 状态保存在当前 Pinia 实例内；本步骤没有持久化、后台服务或自动跨会话恢复。页面及组件尚未挂载或接线，仍留给 Step 6。

## 页面调用示例

### 注册 Pinia

在后续 Vue 应用初始化时注册一次，页面调用 store 前需要完成此步骤：

```ts
import type { App } from 'vue';
import { createPinia } from 'pinia';

export function installJourneyState(app: App) {
  const pinia = createPinia();
  app.use(pinia);
  return pinia;
}
```

下面为接线示例，没有修改现有页面。完整、可执行并经过测试的 composable 见 [useJourneyPageExample.ts](examples/useJourneyPageExample.ts)。它使用 storeToRefs 保留响应性，并将组件回传的字符串收窄为合法目录 ID。

### 选择身份、伙伴和路线

```vue
<script setup lang="ts">
import { identities, partners, routes } from '../data/index.ts';
import { IdentityCard, PartnerCard, RouteCard } from '../components/index.ts';
import { useJourneyPageExample } from '../store/examples/useJourneyPageExample.ts';

const {
  identity, partnerId, routeId,
  onIdentitySelect, onPartnerSelect, onRouteSelect,
} = useJourneyPageExample();
</script>

<template>
  <IdentityCard
    v-for="item in identities" :key="item.id"
    :id="item.id" :name="item.name" :description="item.ability" :skill="item.ability"
    :selected="identity === item.id" :onSelect="onIdentitySelect"
  />
  <PartnerCard
    v-for="item in partners" :key="item.id"
    :id="item.id" :name="item.name" :type="item.type"
    :energy="item.energy" :comfort="item.comfort" :trust="item.trust"
    :selected="partnerId === item.id" :onSelect="onPartnerSelect"
  />
  <RouteCard
    v-for="item in routes" :key="item.id"
    :id="item.id" :name="item.name"
    :time="`${item.durationMinutes.min}–${item.durationMinutes.max}分钟`"
    difficulty="难度待补充" description="同行路线"
    :selected="routeId === item.id" :onSelect="onRouteSelect"
  />
</template>
```

示例集中展示三种选择调用；实际接入时分别放在既有的 Identity、Partner、Route 页面。头像素材尚未提供，因此示例不传入不存在的图片。选择页展示目录初始值；状态页读取 activePartner 的实时值。

### 打开和完成任务

```ts
import type { MissionChoice } from '../data/models.ts';
import { useJourneyPageExample } from '../store/examples/useJourneyPageExample.ts';

const { openMission, currentMission, selectedChoice, result, onChoice } = useJourneyPageExample();

// 由页面路由参数提供 missionId，并且对应地图节点必须已解锁且为当前节点。
function enterMission(missionId: string) {
  openMission(missionId);
}

function handleChoice(choice: MissionChoice) {
  // 页面可捕获 JourneyError 并展示反馈；组件不处理资源或任务效果。
  return onChoice(choice);
}
```

```vue
<MissionCard
  v-if="currentMission"
  :title="currentMission.title" :description="currentMission.description"
  :choices="currentMission.choices" :onChoice="handleChoice"
/>
```

选择草地补给站的“伙伴休息”后，小卫从 comfort=5、trust=5 变为 7、6；人物资源不变，草地节点变为 complete，雪山节点变为 current，progress=1。

### 状态和地图读取

```ts
import { storeToRefs } from 'pinia';
import { usePartnerStore, useResourceStore, useRouteStore } from '../store/index.ts';

const { partner, needsCare } = storeToRefs(usePartnerStore());
const { energy, food, medical, badge } = storeToRefs(useResourceStore());
const { nodes, currentNodeId } = storeToRefs(useRouteStore());
// 将这些 ref 的值作为 StatusBar/MapNode Props，点击事件交给页面协调导航。
```

不要直接解构 store 中的数值状态；使用 storeToRefs。StatusBar.max 是展示参数，其产品上限尚未定义，store 不会将恢复值硬截断到初始值。

### 档案与重新开始

```ts
import { storeToRefs } from 'pinia';
import { useArchiveStore, resetJourney } from '../store/index.ts';

const archiveStore = useArchiveStore();
const { archive, canGenerate, isComplete } = storeToRefs(archiveStore);
// archive 自动更新；最终档案页面可以依据 isComplete 做完成态展示。
const exportSnapshot = () => archiveStore.generateArchive();
const restart = () => resetJourney();
```

## 验证与当前内容边界

```sh
npm run typecheck
npm test
```

新增测试覆盖初始状态、关联选择、信任提示、数值与资源校验、节点顺序、两种任务效果、重复提交、进度溢出、未知奖励预校验、自动档案、独立快照、整次重置、实例隔离及页面 composable。奖励正常发放使用进程内测试 fixture，测试结束恢复目录，不属于产品史料或徽章定义。

目前只有草地补给任务有正式数据，启程站及其他节点任务、真实故事、徽章定义仍待补充。测试通过手动节点 action 准备草地任务及验证地图完成态，只验证 store 契约，不代表完整业务流程已实现。未完成的史料或徽章不会被伪造为奖励，也不会自动跳过缺内容的启程节点。完整页面交互与流程测试分别留给 Step 6、Step 7。
