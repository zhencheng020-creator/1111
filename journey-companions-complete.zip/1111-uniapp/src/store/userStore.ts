import { ref } from 'vue';
import { defineStore } from 'pinia';
import { identities, partners, routes } from '../data/index.ts';
import type { IdentityId, PartnerId, RouteId } from '../data/models.ts';
import { usePartnerStore } from './partnerStore.ts';
import { useRouteStore } from './routeStore.ts';
import { JourneyError } from './validation.ts';

export const useUserStore = defineStore('user', () => {
  const identity = ref<IdentityId | null>(null);
  const partner = ref<PartnerId | null>(null);
  const route = ref<RouteId | null>(null);
  const progress = ref(0);
  const partnerStore = usePartnerStore();
  const routeStore = useRouteStore();

  // 完成任务后的身份、伙伴和路线属于同一份档案，改选时重新开始同行。
  function assertCanSelect(current: string | null, next: string): void {
    if (progress.value > 0 && current !== next) throw new JourneyError('SELECTION_LOCKED', '已有完成任务，请重新开始同行后再改选');
  }

  function selectIdentity(id: IdentityId): void {
    if (!identities.some(item => item.id === id)) throw new JourneyError('UNKNOWN_IDENTITY', `未知身份：${id}`);
    assertCanSelect(identity.value, id);
    identity.value = id;
  }

  function selectPartner(id: PartnerId): void {
    if (!partners.some(item => item.id === id)) throw new JourneyError('UNKNOWN_PARTNER', `未知伙伴：${id}`);
    assertCanSelect(partner.value, id);
    partnerStore.initializePartner(id);
    partner.value = id;
  }

  function selectRoute(id: RouteId): void {
    if (!routes.some(item => item.id === id)) throw new JourneyError('UNKNOWN_ROUTE', `未知路线：${id}`);
    assertCanSelect(route.value, id);
    routeStore.initializeRoute(id);
    route.value = id;
  }

  function previewProgress(amount = 1): number {
    const next = progress.value + amount;
    if (!Number.isSafeInteger(amount) || amount < 0 || !Number.isSafeInteger(next)) throw new JourneyError('INVALID_PROGRESS', '进度增量必须是安全的非负整数');
    return next;
  }

  function updateProgress(amount = 1): void { progress.value = previewProgress(amount); }

  function reset(): void { identity.value = null; partner.value = null; route.value = null; progress.value = 0; }

  return { identity, partner, route, progress, selectIdentity, selectPartner, selectRoute, previewProgress, updateProgress, reset };
});
