import { computed, ref } from 'vue';
import { defineStore } from 'pinia';
import { createInitialResources } from '../data/index.ts';
import type { BadgeId, Resource } from '../data/models.ts';
import { addDelta, assertAmount, assertBadgeId, JourneyError } from './validation.ts';

export const useResourceStore = defineStore('resource', () => {
  const initial = createInitialResources();
  const energy = ref(initial.energy);
  const food = ref(initial.food);
  const medical = ref(initial.medical);
  const earnedBadgeIds = ref<BadgeId[]>([]);
  // 徽章数量由唯一 ID 列表计算，档案和状态栏不会出现数量不一致。
  const badge = computed(() => earnedBadgeIds.value.length);

  function getSnapshot(): Resource {
    return { energy: energy.value, food: food.value, medical: medical.value, badge: badge.value };
  }

  function previewDelta(delta: Readonly<Partial<Resource>>): Resource {
    // 徽章必须有可记录的 ID，不能仅增加一个匿名数量。
    if (delta.badge !== undefined && delta.badge !== 0) throw new JourneyError('BADGE_ID_REQUIRED', '徽章奖励请使用 awardBadgeIds 或 addBadge(id)');
    return {
      energy: addDelta(energy.value, delta.energy ?? 0),
      food: addDelta(food.value, delta.food ?? 0),
      medical: addDelta(medical.value, delta.medical ?? 0),
      badge: badge.value,
    };
  }

  function applyDelta(delta: Readonly<Partial<Resource>>): void {
    const next = previewDelta(delta);
    energy.value = next.energy;
    food.value = next.food;
    medical.value = next.medical;
  }

  function consumeFood(amount = 1): void { assertAmount(amount); applyDelta({ food: -amount }); }
  function addFood(amount = 1): void { assertAmount(amount); applyDelta({ food: amount }); }
  function recoverEnergy(amount = 1): void { assertAmount(amount); applyDelta({ energy: amount }); }
  function addBadge(id: BadgeId): boolean {
    assertBadgeId(id);
    if (earnedBadgeIds.value.includes(id)) return false;
    earnedBadgeIds.value.push(id);
    return true;
  }

  function reset(): void {
    const defaults = createInitialResources();
    energy.value = defaults.energy;
    food.value = defaults.food;
    medical.value = defaults.medical;
    earnedBadgeIds.value = [];
  }

  return { energy, food, medical, badge, earnedBadgeIds, getSnapshot, previewDelta, applyDelta, consumeFood, addFood, recoverEnergy, addBadge, reset };
});
