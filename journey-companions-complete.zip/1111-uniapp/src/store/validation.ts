import { badges, stories } from '../data/index.ts';
import type { BadgeId, StoryId } from '../data/models.ts';

export class JourneyError extends Error {
  readonly code: string;
  constructor(code: string, message: string) {
    super(message);
    this.name = 'JourneyError';
    this.code = code;
  }
}

export function assertAmount(amount: number): void {
  if (!Number.isFinite(amount) || amount < 0) throw new JourneyError('INVALID_AMOUNT', '数量必须为有限的非负数');
}

export function addDelta(value: number, delta: number): number {
  if (!Number.isFinite(delta)) throw new JourneyError('INVALID_DELTA', '状态增量必须为有限数值');
  const next = value + delta;
  if (!Number.isFinite(next) || next < 0) throw new JourneyError('INSUFFICIENT_RESOURCE', '状态更新后不能为负数或无穷值');
  return next;
}

export function assertBadgeId(id: BadgeId): void {
  if (!badges.some(item => item.id === id)) throw new JourneyError('UNKNOWN_BADGE', `未定义的徽章：${id}`);
}

export function assertStoryId(id: StoryId): void {
  const story = stories.find(item => item.id === id);
  if (!story) throw new JourneyError('UNKNOWN_STORY', `未定义的故事：${id}`);
  if (!story.content.trim() || !story.sources.length) throw new JourneyError('MISSING_STORY_SOURCE', '故事需要正文和可核验史料来源');
}

/** 结果记录是独立、只读的历史快照，不引用响应式状态。 */
export function immutableCopy<T>(value: T): Readonly<T> {
  const copy = structuredClone(value);
  const freeze = (item: unknown): void => {
    if (item !== null && typeof item === 'object') {
      for (const child of Object.values(item)) freeze(child);
      Object.freeze(item);
    }
  };
  freeze(copy);
  return copy;
}
