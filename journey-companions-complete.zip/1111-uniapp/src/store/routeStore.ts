import { computed, ref } from 'vue';
import { defineStore } from 'pinia';
import { mapNodes, routes } from '../data/index.ts';
import type { MapNodeId, MapNodeStatus, RouteId, StoryId } from '../data/models.ts';
import { assertStoryId, JourneyError } from './validation.ts';

function initialStatuses(): Record<MapNodeId, MapNodeStatus> {
  return Object.fromEntries(mapNodes.map(node => [node.id, node.initialStatus])) as Record<MapNodeId, MapNodeStatus>;
}

export const useRouteStore = defineStore('route', () => {
  const routeId = ref<RouteId | null>(null);
  const nodeStatuses = ref(initialStatuses());
  const currentNodeId = ref<MapNodeId | null>('departure');
  const unlockedStoryIds = ref<StoryId[]>([]);
  const nodes = computed(() => mapNodes.map(node => ({ ...node, status: nodeStatuses.value[node.id] })));
  const currentNode = computed(() => nodes.value.find(node => node.id === currentNodeId.value) ?? null);
  const isComplete = computed(() => routeId.value !== null && activeNodeIds().every(id => nodeStatuses.value[id] === 'complete'));

  function activeNodeIds(): readonly MapNodeId[] {
    const route = routes.find(item => item.id === routeId.value);
    if (!route) throw new JourneyError('ROUTE_NOT_SELECTED', '请先选择路线');
    return route.nodeIds;
  }

  function requireNode(id: MapNodeId) {
    if (!activeNodeIds().includes(id)) throw new JourneyError('UNKNOWN_NODE', `当前路线没有节点：${id}`);
    const node = mapNodes.find(item => item.id === id);
    if (!node) throw new JourneyError('UNKNOWN_NODE', `未知节点：${id}`);
    return node;
  }

  function initializeRoute(id: RouteId): void {
    const route = routes.find(item => item.id === id);
    if (!route) throw new JourneyError('UNKNOWN_ROUTE', `未知路线：${id}`);
    if (routeId.value === id) return;
    routeId.value = id;
    nodeStatuses.value = initialStatuses();
    currentNodeId.value = route.nodeIds[0] ?? null;
    unlockedStoryIds.value = [];
  }

  function setCurrentNode(id: MapNodeId): void {
    const node = requireNode(id);
    const status = nodeStatuses.value[id];
    if (status === 'locked') throw new JourneyError('NODE_LOCKED', '节点尚未解锁');
    if (status === 'complete') throw new JourneyError('NODE_COMPLETE', '已完成节点不能重新设为当前节点');
    if (currentNodeId.value !== null && currentNodeId.value !== id) throw new JourneyError('CURRENT_NODE_PENDING', '请先完成当前节点');
    nodeStatuses.value[id] = node.kind === 'story' ? 'story' : 'current';
    currentNodeId.value = id;
  }

  function unlockNode(id: MapNodeId): boolean {
    const node = requireNode(id);
    if (nodeStatuses.value[id] === 'complete') return false;
    const ids = activeNodeIds();
    const index = ids.indexOf(id);
    if (!ids.slice(0, index).every(previous => nodeStatuses.value[previous] === 'complete')) {
      throw new JourneyError('PREVIOUS_NODE_PENDING', '请先完成前面的节点');
    }
    nodeStatuses.value[id] = node.kind === 'story' ? 'story' : 'current';
    currentNodeId.value = id;
    return true;
  }

  function assertCanCompleteNode(id: MapNodeId): void {
    requireNode(id);
    if (currentNodeId.value !== id || !['current', 'story'].includes(nodeStatuses.value[id])) {
      throw new JourneyError('NODE_NOT_CURRENT', '只能完成已解锁的当前节点');
    }
  }

  function completeNode(id: MapNodeId): boolean {
    requireNode(id);
    if (nodeStatuses.value[id] === 'complete') return false;
    assertCanCompleteNode(id);
    nodeStatuses.value[id] = 'complete';
    currentNodeId.value = null;
    return true;
  }

  function nextNodeId(id: MapNodeId): MapNodeId | null {
    requireNode(id);
    const ids = activeNodeIds();
    return ids[ids.indexOf(id) + 1] ?? null;
  }

  function unlockStory(id: StoryId): boolean {
    assertStoryId(id);
    if (unlockedStoryIds.value.includes(id)) return false;
    unlockedStoryIds.value.push(id);
    return true;
  }

  function reset(): void {
    routeId.value = null;
    nodeStatuses.value = initialStatuses();
    currentNodeId.value = 'departure';
    unlockedStoryIds.value = [];
  }

  return { routeId, nodeStatuses, currentNodeId, nodes, currentNode, unlockedStoryIds, isComplete, initializeRoute, unlockNode, completeNode, setCurrentNode, nextNodeId, assertCanCompleteNode, unlockStory, reset };
});
