import type { Pinia } from 'pinia';
import { useUserStore } from './userStore.ts';
import { usePartnerStore } from './partnerStore.ts';
import { useResourceStore } from './resourceStore.ts';
import { useRouteStore } from './routeStore.ts';
import { useMissionStore } from './missionStore.ts';

export { useUserStore, usePartnerStore, useResourceStore, useRouteStore, useMissionStore };
export { useArchiveStore } from './archiveStore.ts';
export { JourneyError } from './validation.ts';
export type { ActivePartner } from './partnerStore.ts';
export type { MissionResult } from './missionStore.ts';

/** 同步重置整次同行；只重置单个 store 会留下不一致的关联数据。 */
export function resetJourney(pinia?: Pinia): void {
  useMissionStore(pinia).reset();
  useUserStore(pinia).reset();
  usePartnerStore(pinia).reset();
  useResourceStore(pinia).reset();
  useRouteStore(pinia).reset();
}
