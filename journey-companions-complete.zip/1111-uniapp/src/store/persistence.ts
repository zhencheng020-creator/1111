import type { Pinia } from 'pinia';
import { journeyStorageKey, uniStorageAdapter, type JourneyStorageV1 } from '../platform/storage.ts';

const persistedIds = new Set(['user', 'partner', 'route', 'mission', 'resource']);

function snapshot(pinia: Pinia): JourneyStorageV1 {
  const state = pinia.state.value as Record<string, any>;
  const user = state.user ?? {};
  const partner = state.partner ?? {};
  const route = state.route ?? {};
  const mission = state.mission ?? {};
  const resource = state.resource ?? {};
  return {
    version: 1, updatedAt: Date.now(),
    user: { identity: user.identity ?? null, partner: user.partner ?? null, route: user.route ?? null, progress: user.progress ?? 0 },
    partner: { partner: partner.partner ?? null },
    route: { routeId: route.routeId ?? null, nodeStatuses: route.nodeStatuses ?? {}, currentNodeId: route.currentNodeId ?? null, unlockedStoryIds: route.unlockedStoryIds ?? [] },
    mission: { records: mission.records ?? [], activeMissionId: mission.currentMission?.id ?? null, selectedChoiceId: mission.selectedChoice?.id ?? null },
    resource: { energy: resource.energy ?? 5, food: resource.food ?? 10, medical: resource.medical ?? 3, earnedBadgeIds: resource.earnedBadgeIds ?? [] },
  };
}

/** 在 Pinia 安装前调用；每个业务 store 变化都写入 uni storage。 */
export function installJourneyPersistence(pinia: Pinia): void {
  pinia.use(({ store }) => {
    if (!persistedIds.has(store.$id)) return;
    store.$subscribe(() => uniStorageAdapter.set(journeyStorageKey, snapshot(pinia)), { detached: true });
  });
}

/** 页面首次创建业务 store 后调用，避免覆盖 store 的默认值。 */
export function hydrateJourney(pinia: Pinia): void {
  const saved = uniStorageAdapter.get<JourneyStorageV1>(journeyStorageKey);
  if (!saved || saved.version !== 1) return;
  const state = pinia.state.value as Record<string, any>;
  if (state.user) Object.assign(state.user, saved.user);
  if (state.partner) Object.assign(state.partner, saved.partner);
  if (state.route) Object.assign(state.route, saved.route);
  if (state.resource) Object.assign(state.resource, saved.resource);
  if (state.mission) Object.assign(state.mission, { records: saved.mission.records });
}

export { snapshot as createJourneySnapshot };
