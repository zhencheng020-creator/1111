import { storeToRefs } from 'pinia';
import { identities, partners, routes } from '../../data/index.ts';
import type { MissionChoice } from '../../data/models.ts';
import { useUserStore, usePartnerStore, useRouteStore, useMissionStore, useResourceStore, useArchiveStore, JourneyError } from '../index.ts';

/** 页面接线示例：只供后续页面调用，本次没有修改或挂载任何页面。 */
export function useJourneyPageExample() {
  const user = useUserStore();
  const partner = usePartnerStore();
  const route = useRouteStore();
  const mission = useMissionStore();
  const resources = useResourceStore();
  const archive = useArchiveStore();
  const { identity, partner: partnerId, route: routeId, progress } = storeToRefs(user);
  const { partner: activePartner, needsCare } = storeToRefs(partner);
  const { energy, food, medical, badge } = storeToRefs(resources);
  const { nodes, currentNodeId } = storeToRefs(route);
  const { currentMission, selectedChoice, result } = storeToRefs(mission);
  const { archive: journeyArchive, isComplete } = storeToRefs(archive);

  // 组件回传 string，目录查询同时完成运行时校验和 ID 类型收窄。
  function onIdentitySelect(id: string): void {
    const item = identities.find(item => item.id === id);
    if (!item) throw new JourneyError('UNKNOWN_IDENTITY', '未知身份');
    user.selectIdentity(item.id);
  }
  function onPartnerSelect(id: string): void {
    const item = partners.find(item => item.id === id);
    if (!item) throw new JourneyError('UNKNOWN_PARTNER', '未知伙伴');
    user.selectPartner(item.id);
  }
  function onRouteSelect(id: string): void {
    const item = routes.find(item => item.id === id);
    if (!item) throw new JourneyError('UNKNOWN_ROUTE', '未知路线');
    user.selectRoute(item.id);
  }
  function onChoice(choice: MissionChoice) {
    // 仅用回传 ID 选择 store 中的方案，效果由 missionStore 自己读取。
    mission.selectChoice(choice.id);
    return mission.applyEffect();
  }

  return {
    identity, partnerId, routeId, progress, activePartner, needsCare,
    energy, food, medical, badge, nodes, currentNodeId,
    currentMission, selectedChoice, result, journeyArchive, isComplete,
    onIdentitySelect, onPartnerSelect, onRouteSelect, onChoice,
    openMission: mission.openMission,
  };
}
