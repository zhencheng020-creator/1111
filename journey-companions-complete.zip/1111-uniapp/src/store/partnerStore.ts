import { computed, ref } from 'vue';
import { defineStore } from 'pinia';
import { partners, createInitialPartnerStatus, partnerCareTrustThreshold } from '../data/index.ts';
import type { PartnerId, PartnerStatus } from '../data/models.ts';
import { addDelta, assertAmount, JourneyError } from './validation.ts';

export interface ActivePartner extends PartnerStatus {
  id: PartnerId;
  name: string;
}

export const usePartnerStore = defineStore('partner', () => {
  const partner = ref<ActivePartner | null>(null);
  const needsCare = computed(() => partner.value !== null && partner.value.trust < partnerCareTrustThreshold);

  function initializePartner(id: PartnerId): void {
    const definition = partners.find(item => item.id === id);
    if (!definition) throw new JourneyError('UNKNOWN_PARTNER', `未知伙伴：${id}`);
    if (partner.value?.id === id) return;
    partner.value = { id, name: definition.name, ...createInitialPartnerStatus(id) };
  }

  function previewDelta(delta: Readonly<Partial<PartnerStatus>>): PartnerStatus {
    if (!partner.value) throw new JourneyError('PARTNER_NOT_SELECTED', '请先选择伙伴');
    return {
      energy: addDelta(partner.value.energy, delta.energy ?? 0),
      comfort: addDelta(partner.value.comfort, delta.comfort ?? 0),
      trust: addDelta(partner.value.trust, delta.trust ?? 0),
    };
  }

  function applyDelta(delta: Readonly<Partial<PartnerStatus>>): void {
    const next = previewDelta(delta);
    Object.assign(partner.value!, next);
  }

  function updateEnergy(delta: number): void { applyDelta({ energy: delta }); }
  function increaseComfort(amount = 1): void { assertAmount(amount); applyDelta({ comfort: amount }); }
  function increaseTrust(amount = 1): void { assertAmount(amount); applyDelta({ trust: amount }); }
  function reset(): void { partner.value = null; }

  return { partner, needsCare, initializePartner, previewDelta, applyDelta, updateEnergy, increaseComfort, increaseTrust, reset };
});
