import { computed } from 'vue';
import { defineStore } from 'pinia';
import type { Archive } from '../data/models.ts';
import { useUserStore } from './userStore.ts';
import { useMissionStore } from './missionStore.ts';
import { useResourceStore } from './resourceStore.ts';
import { useRouteStore } from './routeStore.ts';
import { immutableCopy, JourneyError } from './validation.ts';

export const useArchiveStore = defineStore('archive', () => {
  const user = useUserStore();
  const missions = useMissionStore();
  const resources = useResourceStore();
  const route = useRouteStore();
  const canGenerate = computed(() => user.identity !== null && user.partner !== null && user.route !== null);
  // 选择完整后提供实时档案预览；最终完成状态由 isComplete 单独表达。
  const archive = computed<Readonly<Archive> | null>(() => {
    if (!user.identity || !user.partner || !user.route) return null;
    return immutableCopy({
      identity: user.identity, partner: user.partner, route: user.route,
      completedTasks: [...missions.completedTasks],
      stories: [...route.unlockedStoryIds],
      badges: [...resources.earnedBadgeIds],
    });
  });
  const isComplete = computed(() => canGenerate.value && route.isComplete && user.progress === missions.completedTasks.length);

  function generateArchive(): Archive {
    if (!archive.value) throw new JourneyError('SELECTION_INCOMPLETE', '身份、伙伴和路线选择完整后才能生成档案');
    // 给导出或页面使用的独立副本，修改副本不会写回 store。
    return structuredClone(archive.value);
  }

  return { archive, canGenerate, isComplete, generateArchive };
});
