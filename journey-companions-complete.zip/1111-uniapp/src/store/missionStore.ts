import { computed, shallowRef } from 'vue';
import { defineStore } from 'pinia';
import { missions } from '../data/index.ts';
import type { Mission, MissionChoice, MissionEffect, MissionId, PartnerStatus, Resource } from '../data/models.ts';
import { useUserStore } from './userStore.ts';
import { usePartnerStore } from './partnerStore.ts';
import { useResourceStore } from './resourceStore.ts';
import { useRouteStore } from './routeStore.ts';
import { assertBadgeId, assertStoryId, immutableCopy, JourneyError } from './validation.ts';

export interface MissionResult {
  readonly missionId: MissionId;
  readonly choiceId: string;
  readonly effect: MissionEffect;
  readonly resourcesAfter: Readonly<Resource>;
  readonly partnerAfter: Readonly<PartnerStatus>;
}

export const useMissionStore = defineStore('mission', () => {
  const currentMission = shallowRef<Mission | null>(null);
  const selectedChoice = shallowRef<MissionChoice | null>(null);
  const result = shallowRef<MissionResult | null>(null);
  const records = shallowRef<readonly MissionResult[]>(Object.freeze([]));
  const completedTasks = computed(() => Object.freeze(records.value.map(item => item.missionId)));
  const user = useUserStore();
  const partner = usePartnerStore();
  const resources = useResourceStore();
  const route = useRouteStore();

  function assertContext(): void {
    if (!user.identity || !user.partner || !user.route) throw new JourneyError('SELECTION_INCOMPLETE', '请先选择身份、伙伴和路线');
    if (partner.partner?.id !== user.partner || route.routeId !== user.route) throw new JourneyError('STATE_MISMATCH', '伙伴或路线状态与用户选择不一致');
  }

  function openMission(id: MissionId): void {
    const mission = missions.find(item => item.id === id);
    if (!mission) throw new JourneyError('UNKNOWN_MISSION', `未定义的任务：${id}`);
    assertContext();
    const previous = records.value.find(item => item.missionId === id) ?? null;
    if (!previous) route.assertCanCompleteNode(mission.nodeId);
    currentMission.value = immutableCopy(mission);
    selectedChoice.value = previous ? currentMission.value.choices.find(choice => choice.id === previous.choiceId) ?? null : null;
    result.value = previous;
  }

  function selectChoice(id: string): void {
    if (!currentMission.value) throw new JourneyError('MISSION_NOT_OPEN', '请先打开任务');
    if (records.value.some(item => item.missionId === currentMission.value!.id)) throw new JourneyError('MISSION_COMPLETE', '已完成任务不能再次选择方案');
    const choice = currentMission.value.choices.find(item => item.id === id);
    if (!choice) throw new JourneyError('UNKNOWN_CHOICE', `未知任务方案：${id}`);
    selectedChoice.value = choice;
  }

  function applyEffect(): MissionResult {
    const mission = currentMission.value;
    if (!mission) throw new JourneyError('MISSION_NOT_OPEN', '请先打开任务');
    const previous = records.value.find(item => item.missionId === mission.id);
    // 重复点击或重开已完成任务返回原结果，不重复奖励或推进进度。
    if (previous) { result.value = previous; return previous; }
    const choice = mission.choices.find(item => item.id === selectedChoice.value?.id);
    if (!choice) throw new JourneyError('CHOICE_NOT_SELECTED', '请先选择任务方案');

    assertContext();
    route.assertCanCompleteNode(mission.nodeId);
    const nextNode = route.nextNodeId(mission.nodeId);
    const effect = choice.effect;
    // 先完成所有可能失败的校验，避免失败后留下部分资源或进度更新。
    resources.previewDelta(effect.resources ?? {});
    partner.previewDelta(effect.partner ?? {});
    user.previewProgress();
    for (const id of effect.awardBadgeIds ?? []) assertBadgeId(id);
    for (const id of effect.unlockStoryIds ?? []) assertStoryId(id);

    resources.applyDelta(effect.resources ?? {});
    partner.applyDelta(effect.partner ?? {});
    for (const id of effect.awardBadgeIds ?? []) resources.addBadge(id);
    for (const id of effect.unlockStoryIds ?? []) route.unlockStory(id);
    route.completeNode(mission.nodeId);
    if (nextNode) route.unlockNode(nextNode);
    user.updateProgress();

    const activePartner = partner.partner!;
    const outcome: MissionResult = immutableCopy({
      missionId: mission.id, choiceId: choice.id, effect,
      resourcesAfter: resources.getSnapshot(),
      partnerAfter: { energy: activePartner.energy, comfort: activePartner.comfort, trust: activePartner.trust },
    });
    records.value = Object.freeze([...records.value, outcome]);
    result.value = outcome;
    return outcome;
  }

  function reset(): void {
    currentMission.value = null;
    selectedChoice.value = null;
    result.value = null;
    records.value = Object.freeze([]);
  }

  return { currentMission, selectedChoice, result, records, completedTasks, openMission, selectChoice, applyEffect, reset };
});
