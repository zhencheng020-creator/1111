<script setup lang="ts">
import { storeToRefs } from 'pinia';
import { assetMap } from '../../assets/assetMap.ts';
import { useRouteStore } from '../../store/index.ts';
import MapNode from '../../components/MapNode/MapNode.vue';
import Button from '../../components/Button/Button.vue';
import { navigate } from '../../platform/navigation.ts';
const routeStore = useRouteStore(); const { nodes } = storeToRefs(routeStore);
function open(node: typeof nodes.value[number]) { if (node.status === 'current' && node.missionId) navigate('Mission', { missionId: node.missionId }); }
</script>
<template><view class="journey-page"><image class="map-page__scene" :src="assetMap.backgrounds.Map" mode="aspectFill" /><text class="journey-title">同行地图</text><view class="journey-list"><MapNode v-for="node in nodes" :key="node.id" :name="node.name" :status="node.status" :icon="assetMap.nodeScenes[node.id]" @click="open(node)" /></view><view class="journey-actions"><Button text="查看同行状态" variant="Secondary" @click="navigate('Status')" /><Button text="查看同行档案" @click="navigate('Archive')" /></view></view></template>
<style scoped>.map-page__scene{width:100%;height:300rpx;border-radius:24rpx;margin-bottom:20rpx}</style>
