<script setup lang="ts">
import { storeToRefs } from 'pinia';
import { assetMap } from '../../assets/assetMap.ts';
import { usePartnerStore, useResourceStore } from '../../store/index.ts';
import StatusBar from '../../components/StatusBar/StatusBar.vue';
import Button from '../../components/Button/Button.vue';
import { back } from '../../platform/navigation.ts';
const resources = useResourceStore(); const { energy, food, medical, badge } = storeToRefs(resources); const { partner } = storeToRefs(usePartnerStore());
</script>
<template><view class="journey-page"><text class="journey-title">同行状态</text><view class="journey-card"><text>团队资源</text><StatusBar label="人物体力" :value="energy" :max="10" :icon="assetMap.icons.energy" /><StatusBar label="粮食" :value="food" :max="20" :icon="assetMap.icons.food" /><StatusBar label="医疗" :value="medical" :max="10" :icon="assetMap.icons.medical" /><text>徽章 {{ badge }}</text></view><view v-if="partner" class="journey-card"><text class="journey-title">{{ partner.name }}</text><StatusBar label="体力" :value="partner.energy" :max="10" /><StatusBar label="安心" :value="partner.comfort" :max="10" /><StatusBar label="信任" :value="partner.trust" :max="10" :icon="assetMap.icons.trust" /></view><Button text="返回地图" variant="Secondary" @click="back" /></view></template>
