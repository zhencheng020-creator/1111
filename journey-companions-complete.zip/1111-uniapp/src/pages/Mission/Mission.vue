<script setup lang="ts">
import { computed, ref } from 'vue';
import { onLoad } from '@dcloudio/uni-app';
import { storeToRefs } from 'pinia';
import { useMissionStore } from '../../store/index.ts';
import MissionCard from '../../components/MissionCard/MissionCard.vue';
import Button from '../../components/Button/Button.vue';
import { navigate } from '../../platform/navigation.ts';
const mission = useMissionStore(); const { currentMission, selectedChoice, result } = storeToRefs(mission); const routeMissionId = ref('');
onLoad(options => { routeMissionId.value = String(options?.missionId ?? ''); if (routeMissionId.value) mission.openMission(routeMissionId.value); });
const choices = computed(() => currentMission.value?.choices ?? []);
function choose(id: string) { mission.selectChoice(id); }
function apply() { if (!result.value) mission.applyEffect(); }
</script>
<template><view class="journey-page"><text class="journey-title">同行任务</text><MissionCard v-if="currentMission" :title="currentMission.title" :description="currentMission.description" :choices="choices" :selected-choice-id="selectedChoice?.id" @choice="choose" /><text v-if="result" class="journey-card">任务已完成：{{ result.choiceId }}</text><Button v-if="currentMission && !result" text="确认选择" @click="apply" /><Button text="返回地图" variant="Secondary" @click="navigate('Map')" /></view></template>
