<script setup lang="ts">
import { computed } from 'vue';
import { storeToRefs } from 'pinia';
import { identities, partners, routes } from '../../data/index.ts';
import { assetMap } from '../../assets/assetMap.ts';
import { useArchiveStore } from '../../store/index.ts';
import ArchiveCard from '../../components/ArchiveCard/ArchiveCard.vue';
import Badge from '../../components/Badge/Badge.vue';
import Button from '../../components/Button/Button.vue';
import { getActivePinia } from 'pinia';
import { resetJourney } from '../../store/index.ts';
import { back, redirect } from '../../platform/navigation.ts';
const archiveStore = useArchiveStore(); const { archive, isComplete } = storeToRefs(archiveStore);
const identity = computed(() => identities.find(item => item.id === archive.value?.identity)); const partner = computed(() => partners.find(item => item.id === archive.value?.partner)); const route = computed(() => routes.find(item => item.id === archive.value?.route));
</script>
<template><view class="journey-page"><text class="journey-title">同行档案</text><ArchiveCard v-if="archive && identity && partner && route" :identity-name="identity.name" :identity-ability="identity.ability" :partner-name="partner.name" :partner-type="partner.type" :route-name="route.name" :route-time="`${route.durationMinutes.min}–${route.durationMinutes.max}分钟`" :node-count="route.nodeIds.length" :mission-count="archive.completedTasks.length" :story-count="archive.stories.length" :badge-count="archive.badges.length" :is-complete="isComplete"><template #stories><view v-for="id in archive.stories" :key="id"><image v-if="assetMap.stories[id]" :src="assetMap.stories[id]" mode="aspectFit" /><text>{{ id }}</text></view></template><template #badges><Badge v-for="id in archive.badges" :key="id" :name="id" :icon="assetMap.badges[id]" unlocked /></template></ArchiveCard><text v-else class="journey-card">请先完成身份、伙伴和路线选择。</text><Button text="返回地图" variant="Secondary" @click="back" /><Button text="重新同行" @click="() => { resetJourney(getActivePinia() ?? undefined); redirect('Home'); }" /></view></template>
