<script setup lang="ts">
import { storeToRefs } from 'pinia';
import { routes } from '../../data/index.ts';
import { assetMap } from '../../assets/assetMap.ts';
import RouteCard from '../../components/RouteCard/RouteCard.vue';
import Button from '../../components/Button/Button.vue';
import { useRouteStore, useUserStore } from '../../store/index.ts';
import { navigate, back } from '../../platform/navigation.ts';
const user = useUserStore(); const { routeId } = storeToRefs(useRouteStore());
function select(id: string) { user.selectRoute(id as never); }
</script>
<template><view class="journey-page"><text class="journey-title">选择路线</text><view class="journey-list"><RouteCard v-for="item in routes" :key="item.id" :id="item.id" :name="item.name" :time="`${item.durationMinutes.min}–${item.durationMinutes.max}分钟`" difficulty="探索" :description="`包含 ${item.nodeIds.length} 个同行节点。`" :scene="assetMap.routeScenes[item.id]" :selected="routeId === item.id" @select="select" /></view><view class="journey-actions"><Button text="返回伙伴选择" variant="Secondary" @click="back" /><Button text="进入地图" :disabled="routeId === null" @click="navigate('Map')" /></view></view></template>
