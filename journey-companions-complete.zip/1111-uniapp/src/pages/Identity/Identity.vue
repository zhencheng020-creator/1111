<script setup lang="ts">
import { storeToRefs } from 'pinia';
import { identities } from '../../data/index.ts';
import { assetMap } from '../../assets/assetMap.ts';
import IdentityCard from '../../components/IdentityCard/IdentityCard.vue';
import Button from '../../components/Button/Button.vue';
import { useUserStore } from '../../store/index.ts';
import { navigate, back } from '../../platform/navigation.ts';
const user = useUserStore();
const { identity } = storeToRefs(user);
function select(id: string) { user.selectIdentity(id as never); }
</script>
<template><view class="journey-page"><text class="journey-title">选择同行身份</text><view class="journey-list"><IdentityCard v-for="item in identities" :key="item.id" :id="item.id" :name="item.name" :description="item.ability" :skill="item.skill" :icon="assetMap.identityIllustrations[item.id]" :selected="identity === item.id" @select="select" /></view><view class="journey-actions"><Button text="返回首页" variant="Secondary" @click="back" /><Button text="下一步" :disabled="identity === null" @click="navigate('Partner')" /></view></view></template>
