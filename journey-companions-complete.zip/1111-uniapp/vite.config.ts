import { defineConfig } from 'vite';
import uniImport from '@dcloudio/vite-plugin-uni';

// npm 的 CommonJS 兼容导出在 Node 24 下多一层 default；同时兼容 ESM/CJS 两种正式发布形态。
const uni = typeof uniImport === 'function' ? uniImport : uniImport.default;
export default defineConfig({
  plugins: [...uni()],
  build: { outDir: process.env.UNI_OUTPUT_DIR || 'dist/build/mp-weixin' },
});
