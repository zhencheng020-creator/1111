import { createSSRApp } from 'vue';
import { createPinia } from 'pinia';
import App from './App.vue';
import { installJourneyPersistence } from './src/store/persistence.ts';

export function createApp() {
  const app = createSSRApp(App);
  const pinia = createPinia();
  installJourneyPersistence(pinia);
  app.use(pinia);
  return { app, pinia };
}
