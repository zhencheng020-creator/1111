# Phase 9.4 全链路检查

## 已修复

- 补齐 `project.config.json` 与 `project.private.config.json`，两者均使用 `wxae505c34c3713d61`。
- `verify-mp-build.mjs` 改用 `fileURLToPath`，支持 Windows、空格和括号路径。
- `build-mp-weixin.mjs` 使用正式 `uni build -p mp-weixin`，并在 CLI 完成后显式复制两份项目配置，避免不同路径形态下私有配置遗漏。
- 导航适配器统一使用 `/pages/<Page>/<Page>`，所有 `navigateTo`、`redirectTo`、`navigateBack` 都有 `fail` 与 `console.error`。
- 静态验证覆盖页面注册、编译产物、AppID、素材、按钮事件和 Web API 禁用扫描。

## 验证结果

- Web `npm install`、`npm run build`、`npm test`：通过，53/53。
- uni-app `npm install`、`npm run build`、`npm test`：通过，7/7。
- `node scripts/verify-mp-build.mjs`：通过，8 pages、58 PNG、AppID 正确。
- 带空格和括号的临时项目路径构建：通过。
- `dist/build/mp-weixin/app.json`、`app.js`、`app.wxss`、`project.config.json`、`project.private.config.json`：均存在。
- `touristappid`：配置文件中不存在；AppSecret：未创建、未输出。

## 待外部验证

当前环境没有微信开发者工具、模拟器或微信上传凭据，不能验证真机渲染、按钮点击运行时效果、网络域名白名单和上传成功。导入 `dist/build/mp-weixin` 后需使用对应 AppID 运行八个页面并执行回归。
