<script setup lang="ts">
import { computed } from 'vue';
import { storeToRefs } from 'pinia';
import { partners } from '../../src/data/index.ts';
import { assetMap } from '../../src/assets/assetMap.ts';
import PartnerCard from '../../src/components/PartnerCard/PartnerCard.vue';
import Button from '../../src/components/Button/Button.vue';
import { usePartnerStore, useUserStore } from '../../src/store/index.ts';
import { navigate, back } from '../../src/platform/navigation.ts';
const user = useUserStore(); const partnerStore = usePartnerStore(); const { partner } = storeToRefs(partnerStore);
const selectedId = computed(() => partner.value?.id ?? null);
function select(id: string) { user.selectPartner(id as never); }
function stat(item: typeof partners[number], key: 'energy'|'comfort'|'trust'): number { return selectedId.value === item.id ? (partner.value?.[key] ?? item[key]) : item[key]; }
</script>
<template><view class="journey-page"><text class="journey-title">选择伙伴</text><view class="journey-list"><PartnerCard v-for="item in partners" :key="item.id" :id="item.id" :name="item.name" :type="item.type" :avatar="assetMap.characterVisuals[item.id]?.avatar ?? assetMap.characters[item.id]" :energy="stat(item, 'energy')" :comfort="stat(item, 'comfort')" :trust="stat(item, 'trust')" :selected="selectedId === item.id" @select="select" /></view><view class="journey-actions"><Button text="返回身份选择" variant="Secondary" @click="back" /><Button text="下一步" :disabled="partner === null" @click="navigate('Route')" /></view></view></template>
