<script setup lang="ts">
import { assetMap } from '../../src/assets/assetMap.ts';
import Button from '../../src/components/Button/Button.vue';
import { navigate } from '../../src/platform/navigation.ts';
</script>
<template><view class="journey-page home-page"><image class="home-page__scene" :src="assetMap.backgrounds.Home" mode="aspectFill" /><text class="journey-title">征途生灵</text><text>和动物伙伴一起，走一段有故事的路。</text><Button text="开始同行" @click="navigate('Identity')" /></view></template>
<style scoped>.home-page{text-align:center}.home-page__scene{width:100%;height:460rpx;margin-bottom:30rpx;border-radius:24rpx}.home-page>text{display:block;line-height:1.7}</style>
