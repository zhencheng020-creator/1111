import test from 'node:test';
import assert from 'node:assert/strict';
import { promises as fs } from 'node:fs';
import path from 'node:path';
const root = path.resolve(new URL('..', import.meta.url).pathname);
const read = file => fs.readFile(path.join(root, file), 'utf8');

test('pages.json exposes all eight migrated pages', async () => {
  const config = JSON.parse(await read('pages.json'));
  assert.deepEqual(config.pages.map(page => page.path), ['pages/Home/Home','pages/Identity/Identity','pages/Partner/Partner','pages/Route/Route','pages/Map/Map','pages/Mission/Mission','pages/Status/Status','pages/Archive/Archive']);
});
test('components use uni-app primitives and Figma names', async () => {
  const names = ['Button','Card','IdentityCard','PartnerCard','RouteCard','MissionCard','StatusBar','MapNode','Badge','ArchiveCard'];
  for (const name of names) {
    const source = await read(`src/components/${name}/${name}.vue`);
    assert.match(source, /data-figma=/);
    assert.doesNotMatch(source, /<(?:div|section|article|span|p|h1|h2|img|details|summary)(?:\s|>)/);
  }
});
test('assets are copied to static/assets and mapped to uni paths', async () => {
  const manifest = await read('src/assets/assetManifest.ts');
  assert.match(manifest, /\/static\/assets\/characters\/xiaowei\.png/);
  const files = [];
  async function walk(dir) { for (const entry of await fs.readdir(dir,{withFileTypes:true})) { const full=path.join(dir,entry.name); if(entry.isDirectory()) await walk(full); else if(entry.name.endsWith('.png')) files.push(full); } }
  await walk(path.join(root, 'static/assets'));
  assert.ok(files.length >= 58);
});
test('navigation and persistence adapters are wired', async () => {
  const navigation = await read('src/platform/navigation.ts');
  assert.match(navigation, /uni\.navigateTo/); assert.match(navigation, /uni\.redirectTo/); assert.match(navigation, /uni\.navigateBack/);
  const persistence = await read('src/store/persistence.ts');
  assert.match(persistence, /store\.\$subscribe/); assert.match(persistence, /uniStorageAdapter/);
});
test('微信 API 使用明确的未实现占位且安全区样式存在', async () => {
  const api = await read('src/platform/wechatApi.ts');
  for (const name of ['login', 'request', 'upload', 'getLocation', 'openMap', 'share', 'requestSubscribeMessage']) assert.match(api, new RegExp(`async ${name}`));
  assert.match(api, /WECHAT_API_NOT_IMPLEMENTED/);
  const styles = await read('src/styles/design-system.css');
  assert.match(styles, /safe-area-inset-bottom/);
  assert.match(styles, /rpx/);
});
test('微信构建脚本使用跨平台 Node 包装器和正式 uni CLI', async () => {
  const packageJson = JSON.parse(await read('package.json'));
  assert.equal(packageJson.scripts['build:mp-weixin'], 'node scripts/build-mp-weixin.mjs');
  const wrapper = await read('scripts/build-mp-weixin.mjs');
  assert.match(wrapper, /vite-plugin-uni[\s\S]*bin[\s\S]*uni\.js/);
  assert.match(wrapper, /['"]build['"], ['"]-p['"], ['"]mp-weixin['"]/);
  assert.match(wrapper, /UNI_INPUT_DIR/);
  assert.match(wrapper, /UNI_OUTPUT_DIR/);
  assert.doesNotMatch(packageJson.scripts['build:mp-weixin'], /\bUNI_INPUT_DIR=/);
});
