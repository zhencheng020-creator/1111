<script setup lang="ts">
import { getActivePinia } from 'pinia';
import { onLaunch } from '@dcloudio/uni-app';
import { hydrateJourney } from './src/store/persistence.ts';
import { useUserStore, usePartnerStore, useRouteStore, useMissionStore, useResourceStore } from './src/store/index.ts';
import './src/styles/design-system.css';

onLaunch(() => {
  const pinia = getActivePinia();
  if (pinia) {
    useUserStore(pinia); usePartnerStore(pinia); useRouteStore(pinia); useMissionStore(pinia); useResourceStore(pinia);
    hydrateJourney(pinia);
  }
});
</script>
<template><slot /></template>
