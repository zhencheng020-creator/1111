# Phase 9.3 微信小程序适配与验证

## 正式编译

迁移目录已安装并使用正式 uni-app Vite 工具链：

- `@dcloudio/vite-plugin-uni@3.0.0-alpha-5030120260930001`
- `@dcloudio/uni-mp-weixin@3.0.0-alpha-5030120260930001`
- `@dcloudio/uni-app@3.0.0-alpha-5030120260930001`
- Vite 5.2.8，Node 24.19.0

`npm run build` 已实际执行微信平台编译，输出目录为 `dist/build/mp-weixin`；`npm test` 的 5 个迁移检查也全部通过。自动校验确认 `app.json`、`project.config.json`、8 个页面的 JS/JSON/WXML 和 58 个 PNG 都存在；包内 `appid` 仍为 `touristappid`，导入正式项目时必须替换为真实 AppID。编译器日志显示 `Compiler version: 5.31（vue3）`。

## 微信开发者工具与真机

当前环境没有 HBuilderX，也没有微信开发者工具命令（`wechatdevtools`/`cli`）或模拟器，因此没有运行开发者工具预览、真机调试或截图。不能据此宣称页面跳转、图片渲染和真机布局已经通过。

待在微信开发者工具中导入 `dist/build/mp-weixin` 后逐项验证：

| 项目 | 当前结果 |
| --- | --- |
| Home → Identity → Partner → Route → Map | 待开发者工具运行 |
| Map current → Mission，返回导航 | 待开发者工具运行 |
| Status / Archive 入口 | 待开发者工具运行 |
| 58 张图片加载 | 编译产物已存在；实际渲染待工具验证 |
| Pinia 状态写入、重启恢复 | 代码已接入 `$subscribe`；需工具重启验证 |
| 375px / 414px 布局 | rpx 与页面滚动结构已编译；需工具模拟器检查 |
| 安全区域 | 已加入 `constant/env(safe-area-inset-bottom)`；需刘海屏真机检查 |
| 页面滚动 | 页面根节点保留自然滚动；需长内容页面验证 |

## 微信 API 占位

`src/platform/wechatApi.ts` 提供明确抛出 `WECHAT_API_NOT_IMPLEMENTED` 的接口，不伪造成功结果：登录、网络请求、上传、定位、地图、分享、订阅消息。后续接入时替换 `wechatApiPlaceholder` 实现即可。

## 下一阶段

1. 用微信开发者工具导入 `dist/build/mp-weixin`，配置真实 `appid`。
2. 按上表在 375px、414px 和至少一台刘海屏设备执行回归。
3. 接入后端登录与请求域名白名单，再实现上传、定位、地图、分享和订阅消息。
4. 以真机日志检查 Pinia 恢复时机、图片缓存和包体积。
