# Phase 9.2 迁移交付说明

## 目录与页面

`1111-uniapp` 是 `/workspace/1111` 的 sibling 目录，Web 源项目没有被覆盖。`pages.json` 注册了 `Home`、`Identity`、`Partner`、`Route`、`Map`、`Mission`、`Status`、`Archive` 八个页面；实际 uni-app 页面入口位于根目录 `pages/<Page>/<Page>.vue`，对应逻辑源副本保留在 `src/pages/<Page>/<Page>.vue`。

组件入口位于 `src/components`：`Button`、`Card`、`IdentityCard`、`PartnerCard`、`RouteCard`、`MissionCard`、`StatusBar`、`MapNode`、`Badge`、`ArchiveCard`。每个组件都保留 Figma 名称 `data-figma`，状态由 Props 输入，用户操作通过事件回传。

## 标签与路由转换

| Web | uni-app | 处理 |
| --- | --- | --- |
| `div` / `section` / `article` | `view` | 页面和卡片布局使用 `view` |
| `span` / `p` / `h1` / `h2` | `text` | 文字节点使用 `text` |
| `img` | `image` | 图片使用 `/static/assets/`，缺失时保留卡片文字占位 |
| `button` | `button` | 点击事件通过 `tap` 回传 |
| `progress` | `progress` | 状态条保留数值和比例 |
| `details` / `summary` | `view` + `ref` | ArchiveCard 使用 `open` 状态控制展开 |

`src/platform/navigation.ts` 集中映射路径：普通前进使用 `uni.navigateTo`，重置同行后使用 `uni.redirectTo`，返回使用 `uni.navigateBack`。任务参数用 URL query 编码传递。

## 素材

原 Web 的 58 个 PNG 已复制到 `static/assets/{characters,identity,icons,badges,scenes,stories}`，未修改像素内容；`src/assets/assetManifest.ts` 和 `src/assets/assetMap.ts` 的 URL 统一为 `/static/assets/...`。`resolveAssetUrl` 和各卡片的空资源分支保留缺失回退。

## Pinia 持久化

`src/store` 保留 Web 的数据模型与业务 actions。`src/platform/storage.ts` 提供 `uniStorageAdapter`，使用 `uni.getStorageSync`、`setStorageSync`、`removeStorageSync`。`src/store/persistence.ts` 在 `main.ts` 中安装 Pinia 插件，监听 `user`、`partner`、`route`、`mission`、`resource` 的 `$subscribe`，写入 `journey-companions:state:v1`；App 启动时对已创建 store 做版本校验后恢复。

## 验证

- `npm run build`：迁移契约校验通过，8 页面、10 组件、58 PNG。
- `npm test`：4 个迁移校验测试全部通过。
- `/workspace/1111` 原 Web 项目：`npm run build` 通过；`npm test` 53/53 通过。

本环境没有安装 uni-app/HBuilderX 编译器，所以迁移目录的 `npm run build` 是静态契约构建；接入目标工具链后使用同一套 `pages.json`、`manifest.json` 和 SFC 源码执行真实平台构建。

## 尚未适配的微信小程序 API

当前产品逻辑只需要页面导航、同步本地存储和页面生命周期，已分别由 `uni.navigateTo/redirectTo/navigateBack`、`uni.*StorageSync`、`@dcloudio/uni-app` 生命周期承接。以下 API 尚未接入，因为现有 Web 产品没有对应功能：

- `wx.login` / `uni.login`、用户授权与服务端会话
- `wx.request` / `uni.request` 网络接口与离线同步
- `wx.chooseImage`、上传、相机、文件系统
- 地图、定位、陀螺仪、音频、视频、支付、订阅消息和分享
- 小程序分包、真机性能监控和平台差异化主题配置
