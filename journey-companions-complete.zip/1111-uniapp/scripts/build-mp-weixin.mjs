import { promises as fs } from 'node:fs';
import { spawn } from 'node:child_process';
import path from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';

const root = path.resolve(fileURLToPath(new URL('..', import.meta.url)));
const outputDir = path.join(root, 'dist', 'build', 'mp-weixin');
const cli = path.join(root, 'node_modules', '@dcloudio', 'vite-plugin-uni', 'bin', 'uni.js');

await fs.rm(outputDir, { recursive: true, force: true });
const env = {
  ...process.env,
  UNI_INPUT_DIR: root,
  UNI_OUTPUT_DIR: outputDir,
  UNI_PLATFORM: 'mp-weixin',
};

const child = spawn(process.execPath, [cli, 'build', '-p', 'mp-weixin'], {
  cwd: root,
  env,
  stdio: 'inherit',
  windowsHide: false,
});

const exitCode = await new Promise((resolve, reject) => {
  child.once('error', reject);
  child.once('exit', (code, signal) => resolve(code ?? (signal ? 1 : 0)));
});
if (exitCode !== 0) process.exit(exitCode);

await import(pathToFileURL(path.join(root, 'scripts', 'verify-mp-build.mjs')).href);
