import { promises as fs } from 'node:fs';
import { spawn } from 'node:child_process';
import path from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';

const root = path.resolve(fileURLToPath(new URL('..', import.meta.url)));
const outputDir = path.join(root, 'dist', 'build', 'mp-weixin');
const cli = path.join(root, 'node_modules', '@dcloudio', 'vite-plugin-uni', 'bin', 'uni.js');

await fs.rm(outputDir, { recursive: true, force: true });
const env = {
  ...process.env,
  UNI_INPUT_DIR: root,
  UNI_OUTPUT_DIR: outputDir,
  UNI_PLATFORM: 'mp-weixin',
};

const child = spawn(process.execPath, [cli, 'build', '-p', 'mp-weixin'], {
  cwd: root,
  env,
  stdio: 'inherit',
  windowsHide: false,
});

const exitCode = await new Promise((resolve, reject) => {
  child.once('error', reject);
  child.once('exit', (code, signal) => resolve(code ?? (signal ? 1 : 0)));
});
if (exitCode !== 0) process.exit(exitCode);

// uni CLI 对 project.private.config.json 的复制在不同平台/路径形态下并不稳定；
// 显式复制配置，确保微信开发者工具拿到与源码一致的 AppID 配置。
for (const configFile of ['project.config.json', 'project.private.config.json']) {
  await fs.copyFile(path.join(root, configFile), path.join(outputDir, configFile));
}

await import(pathToFileURL(path.join(root, 'scripts', 'verify-mp-build.mjs')).href);
