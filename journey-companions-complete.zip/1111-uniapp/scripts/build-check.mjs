import { promises as fs } from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root = path.resolve(fileURLToPath(new URL('..', import.meta.url)));
const requiredPages = ['Home','Identity','Partner','Route','Map','Mission','Status','Archive'];
const requiredComponents = ['Button','Card','IdentityCard','PartnerCard','RouteCard','MissionCard','StatusBar','MapNode','Badge','ArchiveCard'];
const forbiddenTag = /<(?:div|section|article|span|p|h1|h2|img|details|summary)(?:\s|>)/;
const read = file => fs.readFile(path.join(root, file), 'utf8');
const exists = async file => { try { await fs.access(path.join(root, file)); return true; } catch { return false; } };

const pagesConfig = JSON.parse(await read('pages.json'));
const pagePaths = new Set(pagesConfig.pages.map(page => page.path));
const pageResults = [];
for (const page of requiredPages) {
  const file = `pages/${page}/${page}.vue`;
  const source = await read(file);
  if (forbiddenTag.test(source)) throw new Error(`${file} still contains a Web-only DOM tag`);
  if (!source.includes('<template>') || !/<(?:view|text|image|button|progress)[\s>]/.test(source)) throw new Error(`${file} is not a uni template`);
  if (!pagePaths.has(`pages/${page}/${page}`)) throw new Error(`pages.json missing ${page}`);
  pageResults.push({ page, file, status: 'ok' });
}
const componentResults = [];
for (const component of requiredComponents) {
  const file = `src/components/${component}/${component}.vue`;
  const source = await read(file);
  if (forbiddenTag.test(source)) throw new Error(`${file} still contains a Web-only DOM tag`);
  if (!source.includes('data-figma=')) throw new Error(`${file} is missing Figma component identity`);
  componentResults.push({ component, file, status: 'ok' });
}
const pngs = [];
async function walk(dir) {
  for (const entry of await fs.readdir(dir, { withFileTypes: true })) {
    const full = path.join(dir, entry.name);
    if (entry.isDirectory()) await walk(full);
    else if (entry.name.toLowerCase().endsWith('.png')) pngs.push(path.relative(root, full));
  }
}
await walk(path.join(root, 'static/assets'));
if (pngs.length < 58) throw new Error(`expected at least 58 copied PNG assets, found ${pngs.length}`);
const assetMap = await read('src/assets/assetMap.ts');
const manifest = await read('src/assets/assetManifest.ts');
if (!assetMap.includes("'/static/assets/characters/")) throw new Error('assetMap is not using /static/assets');
if (!manifest.includes('"/static/assets/characters/')) throw new Error('assetManifest is not using /static/assets');
const persistence = await read('src/store/persistence.ts');
if (!persistence.includes('$subscribe') || !persistence.includes('uniStorageAdapter')) throw new Error('Pinia persistence adapter is not wired');
const navigation = await read('src/platform/navigation.ts');
for (const api of ['navigateTo','redirectTo','navigateBack']) if (!navigation.includes(`uni.${api}`)) throw new Error(`missing ${api} adapter`);
const report = { kind: 'uni-app-migration-scaffold', compiler: 'static-contract-check', pages: pageResults, components: componentResults, assets: { pngCount: pngs.length, root: 'static/assets', pathPrefix: '/static/assets/' }, persistence: { adapter: 'uniStorageAdapter', key: 'journey-companions:state:v1', subscribe: true }, navigation: { supported: ['uni.navigateTo','uni.redirectTo','uni.navigateBack'], pages: Object.fromEntries(requiredPages.map(page => [page, `/pages/${page}/${page}`])) }, generatedAt: new Date().toISOString() };
await fs.mkdir(path.join(root, 'dist'), { recursive: true });
await fs.writeFile(path.join(root, 'dist/uniapp-build-report.json'), JSON.stringify(report, null, 2));
console.log(`uni-app migration contract passed: ${requiredPages.length} pages, ${requiredComponents.length} components, ${pngs.length} PNG assets`);
