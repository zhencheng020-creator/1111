import { promises as fs } from 'node:fs';
import path from 'node:path';
const root = path.resolve(new URL('..', import.meta.url).pathname);
const out = path.join(root, 'dist/build/mp-weixin');
const pages = ['Home','Identity','Partner','Route','Map','Mission','Status','Archive'];
const exists = async f => { try { await fs.access(f); return true; } catch { return false; } };
if (!await exists(path.join(out, 'app.json'))) throw new Error('正式编译未生成 app.json');
if (!await exists(path.join(out, 'project.config.json'))) throw new Error('正式编译未生成 project.config.json');
const app = JSON.parse(await fs.readFile(path.join(out, 'app.json'), 'utf8'));
for (const page of pages) {
  const prefix = path.join(out, 'pages', page, page);
  for (const ext of ['.js', '.json', '.wxml']) if (!await exists(prefix + ext)) throw new Error(`缺少页面产物：pages/${page}/${page}${ext}`);
}
const pngs=[];
async function walk(dir) { for (const e of await fs.readdir(dir,{withFileTypes:true})) { const f=path.join(dir,e.name); if(e.isDirectory()) await walk(f); else if(e.name.endsWith('.png')) pngs.push(f); } }
await walk(path.join(out,'static/assets'));
if (pngs.length < 58) throw new Error(`微信包素材不完整：${pngs.length}/58 PNG`);
if (app.pages.length !== pages.length) throw new Error(`app.json 页面数量异常：${app.pages.length}`);
console.log(`正式 uni-app 微信编译通过：${pages.length} pages, ${pngs.length} PNG assets`);
