import { promises as fs } from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root = path.resolve(fileURLToPath(new URL('..', import.meta.url)));
const out = path.join(root, 'dist', 'build', 'mp-weixin');
const appId = 'wxae505c34c3713d61';
const pages = ['Home', 'Identity', 'Partner', 'Route', 'Map', 'Mission', 'Status', 'Archive'];
const expectedPagePaths = pages.map(page => `pages/${page}/${page}`);
const forbiddenWeb = /router\.push|router\.replace|window\.location|location\.href|location\.hash|document\.|window\.|localStorage|sessionStorage|<img(?:\s|>)|<div(?:\s|>)|<section(?:\s|>)|<article(?:\s|>)|<span(?:\s|>)|<details(?:\s|>)|<summary(?:\s|>)/;
const exists = async file => { try { await fs.access(file); return true; } catch { return false; } };
const read = file => fs.readFile(path.join(root, file), 'utf8');
const readJson = async file => JSON.parse(await read(file));

async function walk(dir) {
  const result = [];
  if (!await exists(dir)) return result;
  for (const entry of await fs.readdir(dir, { withFileTypes: true })) {
    const full = path.join(dir, entry.name);
    if (entry.isDirectory()) result.push(...await walk(full));
    else result.push(full);
  }
  return result;
}
function assert(condition, message) { if (!condition) throw new Error(message); }

const manifest = await readJson('manifest.json');
const pagesConfig = await readJson('pages.json');
const sourceProject = await readJson('project.config.json');
const sourcePrivate = await readJson('project.private.config.json');
assert(manifest['mp-weixin']?.appid === appId, 'manifest.json AppID 不正确');
for (const [file, config] of [['project.config.json', sourceProject], ['project.private.config.json', sourcePrivate]]) {
  assert(config.appid === appId, `${file} AppID 不正确`);
  assert(JSON.stringify(config).includes(appId), `${file} 缺少 AppID`);
  assert(!JSON.stringify(config).includes('touristappid'), `${file} 残留 touristappid`);
}
assert(JSON.stringify(manifest).includes(appId), 'manifest.json 缺少 AppID');
assert(!JSON.stringify(manifest).includes('touristappid'), 'manifest.json 残留 touristappid');
assert(JSON.stringify(pagesConfig.pages.map(page => page.path)) === JSON.stringify(expectedPagePaths), 'pages.json 页面顺序或路径不完整');

for (const page of pages) {
  const sourceFile = path.join(root, 'pages', page, `${page}.vue`);
  assert(await exists(sourceFile), `页面源文件缺失：pages/${page}/${page}.vue`);
  const source = await fs.readFile(sourceFile, 'utf8');
  assert(!forbiddenWeb.test(source), `页面包含 Web 专用 API 或标签：${page}`);
  assert(/<(?:Button|button)\b/.test(source), `页面缺少按钮：${page}`);
  assert(/@(?:click|tap)=/.test(source), `页面按钮缺少点击事件：${page}`);
}
for (const pagePath of expectedPagePaths) {
  const page = pagePath.split('/')[1];
  for (const ext of ['.js', '.json', '.wxml']) assert(await exists(path.join(out, `${pagePath}${ext}`)), `缺少页面编译产物：${pagePath}${ext}`);
}

const navigation = await read('src/platform/navigation.ts');
for (const pagePath of expectedPagePaths) assert(navigation.includes(`'/${pagePath}'`), `导航缺少路径：/${pagePath}`);
for (const api of ['uni.navigateTo', 'uni.redirectTo', 'uni.navigateBack']) assert(navigation.includes(api), `导航缺少 API：${api}`);
assert(navigation.includes('fail: error =>'), '导航缺少 fail 回调');
assert(navigation.includes('console.error'), '导航缺少 console.error');
assert(!forbiddenWeb.test(navigation), '导航适配器包含 Web 路由或 DOM API');

const sourceFiles = await walk(path.join(root, 'src')).then(files => files.filter(file => /\.(ts|vue|css)$/.test(file)));
sourceFiles.push(...await walk(path.join(root, 'pages')).then(files => files.filter(file => file.endsWith('.vue'))));
for (const file of sourceFiles) {
  const source = await fs.readFile(file, 'utf8');
  assert(!forbiddenWeb.test(source), `源码包含不兼容 Web API/标签：${path.relative(root, file)}`);
  assert(!source.includes("'/src/assets/") && !source.includes('"/src/assets/'), `源码引用 /src/assets：${path.relative(root, file)}`);
}
const assetMap = await read('src/assets/assetMap.ts');
const assetManifest = await read('src/assets/assetManifest.ts');
assert(assetMap.includes('/static/assets/'), 'assetMap 未使用 /static/assets 路径');
assert(assetManifest.includes('/static/assets/'), 'assetManifest 未使用 /static/assets 路径');

const sourcePngs = (await walk(path.join(root, 'static', 'assets'))).filter(file => file.toLowerCase().endsWith('.png')).map(file => path.relative(path.join(root, 'static', 'assets'), file).replaceAll(path.sep, '/')).sort();
const buildPngs = (await walk(path.join(out, 'static', 'assets'))).filter(file => file.toLowerCase().endsWith('.png')).map(file => path.relative(path.join(out, 'static', 'assets'), file).replaceAll(path.sep, '/')).sort();
assert(sourcePngs.length === 58, `源素材 PNG 数量异常：${sourcePngs.length}`);
assert(JSON.stringify(sourcePngs) === JSON.stringify(buildPngs), '微信编译产物素材与 static/assets 不一致');

for (const file of ['app.json', 'app.js', 'app.wxss', 'project.config.json', 'project.private.config.json']) assert(await exists(path.join(out, file)), `缺少微信产物：${file}`);
const app = await readJson(path.join('dist', 'build', 'mp-weixin', 'app.json'));
const buildProject = await readJson(path.join('dist', 'build', 'mp-weixin', 'project.config.json'));
const buildPrivate = await readJson(path.join('dist', 'build', 'mp-weixin', 'project.private.config.json'));
assert(JSON.stringify(app.pages) === JSON.stringify(expectedPagePaths), 'app.json 页面路径不一致');
for (const [file, config] of [['dist project.config.json', buildProject], ['dist project.private.config.json', buildPrivate]]) {
  assert(config.appid === appId, `${file} AppID 不正确`);
  assert(!JSON.stringify(config).includes('touristappid'), `${file} 残留 touristappid`);
}

console.log(`微信产物完整：${pages.length} pages, ${sourcePngs.length} PNG assets, AppID ${appId}`);
