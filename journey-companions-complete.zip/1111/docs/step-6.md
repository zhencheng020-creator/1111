# Step 6：页面与 store 绑定交付

本轮按最新要求暂停真实 Image2 / Figma 视觉资产接入，只完成页面数据绑定、运行入口和资源接口占位。使用现有 Vue 3 组件、Pinia store 和设计令牌，没有修改组件架构，没有生成图片，没有新增任务、史料或徽章定义。

## 页面 store 调用代码及关系

保留原来的八个页面目录和 `index.ts` 元信息，各目录增加 `View.ts` 作为真实 Vue 页面。`src/router/appRouter.ts` 把既有路径接入 Vue Router hash history；`src/main.ts` 创建一个 Pinia 实例并注册路由，`src/App.ts` 渲染 RouterView。

| 页面源码 | 读取的 store | 事件与状态变化 |
| --- | --- | --- |
| [Home](../src/pages/Home/View.ts) | 无选择状态 | Button 开始同行 → Identity |
| [Identity](../src/pages/Identity/View.ts) | userStore | onSelect → selectIdentity(id)，selected 由 identity 控制 |
| [Partner](../src/pages/Partner/View.ts) | partnerStore、userStore | userStore.selectPartner(id) 同步初始化伙伴；卡片显示实时 energy/comfort/trust |
| [Route](../src/pages/Route/View.ts) | routeStore、userStore | userStore.selectRoute(id) 同步初始化地图；selected 由 routeId 控制 |
| [Map](../src/pages/Map/View.ts) | routeStore | 读取 nodes/status；current 点击 → Mission；locked 不可点击 |
| [Mission](../src/pages/Mission/View.ts) | missionStore | openMission(id)；onChoice → selectChoice(choice.id) → applyEffect()；显示结果 |
| [Status](../src/pages/Status/View.ts) | resourceStore、partnerStore | 展示人物体力、粮食、医疗资源、徽章数量和伙伴状态 |
| [Archive](../src/pages/Archive/View.ts) | archiveStore | 自动展示身份、伙伴、路线、任务、故事、徽章；重新同行重置状态并返回 Home |

所有响应式状态使用 `storeToRefs`，选择及任务效果通过 action 更新。页面负责事件协调和导航，组件继续只接收 Props、回传已有回调。

选择伙伴和路线使用 userStore 的选择 action，因为它们需要同时维护用户选择 ID 与伙伴/地图状态。未选择时下一步按钮禁用；运行时路由也检查选择是否完整，直接访问或刷新受保护页面会引导重新选择。

### 任务页实际接线

```ts
const mission = useMissionStore();
const { currentMission, result } = storeToRefs(mission);

function onChoice(choice: MissionChoice) {
  mission.selectChoice(choice.id);
  mission.applyEffect();
}
```

页面将 currentMission 的 title/description/choices 及 onChoice 传给 MissionCard。实际代码还处理任务参数变化、错误反馈及已完成任务的只读结果。

状态页展示真实数值，不拿初始 5 当作未定义的状态上限。StatusBar 用于地图节点进度，最大值为已定义的 6 个节点。伙伴舒适度增至 7、信任增至 6 时，状态页显示 7、6。

## assetMap 和资源接口

代码见 [assetMap.ts](../src/assets/assetMap.ts)，保留五条 placeholder 路径：

```ts
xiaowei: '/assets/characters/xiaowei.png'
chifeng: '/assets/characters/chifeng.png'
feiyu: '/assets/characters/feiyu.png'
xiaotuo: '/assets/characters/xiaotuo.png'
aniu: '/assets/characters/aniu.png'
```

```text
public/assets/
├── characters/
├── backgrounds/
├── icons/
├── badges/
└── stories/

src/assets/
├── assetMap.ts
└── assetManifest.ts
```

backgrounds/icons/badges/stories 保留未来映射接口。目录只有占位文件，没有假 PNG。`realAssetLoadingEnabled=false`，页面不会发起图片请求。`assetProp` 在图片不可用时省略 icon/avatar Props，保持现有组件类型和架构。

`scripts/sync-assets.mjs` 只扫描实际图片文件名并维护存在清单，不读取或修改图片内容。以后按新的指示导入已有 Image2 文件、核对 Figma 对应关系并更新映射后，再开启真实加载。本轮不进行这些操作。

## 运行与 Step 6 检查

需要 Node.js 24 或以上版本。

```sh
cd /workspace/1111
npm ci --cache /tmp/journey-npm-cache
npm run dev
```

开发服务使用 5173 端口和 hash 路由。已有服务运行时无需重复启动。独立检查在另一终端执行：

```sh
npm run test:step6  # 10 项页面/运行时路由/资源接口绑定检查
npm run build      # 类型检查与生产构建，输出 dist/
```

`npm test` 包含先前的数据、路由、组件、store 测试及本轮页面检查。它不是 Step 7 的完整体验验收。生产构建可用 `npm run preview` 在 4173 端口检查。

### 已执行的检查

- 原有 43 项测试和新增 10 项页面绑定检查通过；修正可选图片 Props 后，10 项页面检查再次通过。
- 类型检查与 Vite 生产构建通过；开发入口、任务页模块和样式返回 HTTP 200，构建的 JS/CSS 可正常取得。
- 组件、数据和 store 文件与本轮开始时的基线一致。
- 页面测试实际挂载 Vue、Pinia 和运行时路由，验证真实组件回调；没有执行完整同行端到端流程。
- 原生 Chromium 启动检查未完成：应用地址及空白页均在当前云环境中超时；未将原生浏览器渲染或视觉效果描述为已验证。页面绑定检查使用模拟 DOM。

### 验收时查看的行为

1. Home 点击“开始同行”进入 Identity；选择身份后选中状态变化，下一步可用。
2. Partner 选择同步当前伙伴；Route 选择同步当前路线，并可进入 Map。
3. Map 显示六个节点及状态，locked 不跳转；current 进入对应 Mission 入口。
4. Status 显示当前资源和伙伴状态；Archive 显示中文选择及现有完成记录，进行中时不标记最终完成。
5. “重新同行”清空本次状态并返回 Home。当前状态保存在应用内存中，刷新恢复初始状态。

目前正式任务仅有草地补给站，启程站及其余任务内容未提供，因此正常首个节点入口展示“本站任务内容尚未提供”，不会自动跳过或虚构完成记录。草地任务的页面绑定已通过独立测试：测试使用明确的 store fixture 解锁草地，再由真实 MissionCard 点击“伙伴休息”，验证舒适度 7、信任 6、节点与进度同步。

本轮没有补齐剩余任务、真实史料和徽章，没有进行真实视觉资产接入或 Figma 视觉比对。停留在 Step 6，等待验收，不进入 Step 7。
