# Phase 9.2 · uni-app 迁移适配层

本阶段只准备平台边界，不迁移页面、不引入 uni-app 依赖，也不改变 Web 业务行为。

## 已完成

- 组件和页面的动态样式注入统一经过 `src/platform/style.ts` 的 `injectStyle()`。
- Web 端继续使用 `document` 注入并去重；非 DOM 运行时安全跳过，后续 uni-app 使用静态 CSS 导入。
- `assetMap.ts` 增加 `toUniStaticPath()`，把 `/assets/...` 映射为 `/static/assets/...`，不移动当前文件。
- `src/platform/storage.ts` 提供版本化 storage key、Web adapter 和 `JourneyStorageV1` 契约；当前未自动接入 store，因此刷新行为不变。

## DOM 到 uni-app

| Web | uni-app | 处理方式 |
| --- | --- | --- |
| `div` / `section` / `header` / `article` | `view` | 保留 class 和层级 |
| `span` / `p` / `h1` / `h2` / `label` | `text` | 需要拆分可点击文本和容器 |
| `img` | `image` | `src` 使用 `toUniStaticPath()`，保留 `@error` fallback |
| `button` | `button` | `onClick` 改为 `@tap`，保留 disabled |
| `progress` | `progress` | 映射 value、max、aria label |
| `details` / `summary` | `view` | 由 `ref` 管理 open/close |

当前 Web 只剩 `src/platform/style.ts` 持有 DOM API；组件和页面不再直接访问 `document`。

## Storage 接入顺序

先按 `JourneyStorageV1` 白名单组装快照，再接入 Pinia `$subscribe`。uni-app 端替换为：

```ts
get: key => uni.getStorageSync(key) || null
set: (key, value) => uni.setStorageSync(key, value)
remove: key => uni.removeStorageSync(key)
```

`archiveStore` 保持派生，不单独写入；`resetJourney()` 同步清除 `journey-companions:state:v1`。

## 尚未迁移

- Vue Router 到 `uni.navigateTo` / `uni.redirectTo`
- Render function 到 uni-app 模板
- `<details>` 交互实现
- 微信开发者工具真机验收

这些留到 Phase 9.3，避免在 Web 版本中混入平台分支。
