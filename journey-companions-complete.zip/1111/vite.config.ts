import { defineConfig } from 'vite';

export default defineConfig({
  // 本项目使用 TS 渲染函数，无 SFC 插件；显式提供 Vue 的构建标志。
  define: {
    __VUE_OPTIONS_API__: true,
    __VUE_PROD_DEVTOOLS__: false,
    __VUE_PROD_HYDRATION_MISMATCH_DETAILS__: false,
  },
  publicDir: 'public',
  server: { host: true, port: 5173, strictPort: true },
  preview: { host: true, port: 4173, strictPort: true },
  build: { target: 'es2022' },
});
