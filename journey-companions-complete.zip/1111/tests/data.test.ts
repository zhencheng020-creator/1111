import assert from 'node:assert/strict';
import test from 'node:test';
import {
  identities, partners, routes, mapNodes, missions, stories, badges,
  initialResources, partnerCareTrustThreshold,
  createInitialUser, createInitialResources, createInitialPartnerStatus,
} from '../src/data/index.ts';

test('基础目录包含需求指定的身份、伙伴、路线和节点，ID 唯一', () => {
  assert.deepEqual(identities.map(item => item.id), ['support', 'scout', 'medical', 'record']);
  assert.deepEqual(partners.map(item => item.id), ['xiaowei', 'chifeng', 'feiyu', 'xiaotuo', 'aniu']);
  assert.deepEqual(routes.map(item => item.id), ['easy', 'normal', 'challenge']);
  assert.deepEqual(mapNodes.map(item => item.name), [
    '同行启程站', '草地补给站', '雪山挑战站', '桥梁协作站', '无声伙伴故事站', '同行终点站',
  ]);
  for (const collection of [identities, partners, routes, mapNodes, missions, stories, badges]) {
    assert.equal(new Set(collection.map(item => item.id)).size, collection.length);
  }
});

test('路线时长正确且节点引用有效', () => {
  assert.deepEqual(routes.map(item => item.durationMinutes), [
    { min: 40, max: 50 }, { min: 60, max: 75 }, { min: 75, max: 90 },
  ]);
  const nodeIds = new Set(mapNodes.map(node => node.id));
  for (const route of routes) {
    assert.equal(route.nodeIds.length, 6);
    assert.equal(new Set(route.nodeIds).size, route.nodeIds.length);
    for (const id of route.nodeIds) assert.ok(nodeIds.has(id));
  }
  assert.equal(mapNodes.filter(node => node.initialStatus === 'current').length, 1);
  assert.equal(mapNodes[0]?.initialStatus, 'current');
  assert.ok(mapNodes.slice(1).every(node => node.initialStatus === 'locked'));
});

test('任务和节点双向引用一致，奖励及故事引用有效', () => {
  for (const node of mapNodes) {
    if (node.missionId !== null) {
      assert.ok(missions.some(mission => mission.id === node.missionId && mission.nodeId === node.id));
    }
    if (node.storyId !== null) assert.ok(stories.some(story => story.id === node.storyId));
  }
  for (const mission of missions) {
    assert.ok(mapNodes.some(node => node.id === mission.nodeId && node.missionId === mission.id));
    assert.ok(mission.choices.length >= 2);
    assert.equal(new Set(mission.choices.map(choice => choice.id)).size, mission.choices.length);
    for (const choice of mission.choices) {
      for (const id of choice.effect.unlockStoryIds ?? []) assert.ok(stories.some(story => story.id === id));
      for (const id of choice.effect.awardBadgeIds ?? []) assert.ok(badges.some(badge => badge.id === id));
      for (const delta of Object.values(choice.effect.resources ?? {})) assert.ok(Number.isFinite(delta));
      for (const delta of Object.values(choice.effect.partner ?? {})) assert.ok(Number.isFinite(delta));
    }
  }
});

test('草地任务准确区分人物资源变化与伙伴变化', () => {
  const mission = missions.find(item => item.id === 'grassland-supply');
  assert.ok(mission);
  assert.deepEqual(mission.choices.find(choice => choice.id === 'supply-food')?.effect,
    { resources: { food: 3, energy: -1 } });
  assert.deepEqual(mission.choices.find(choice => choice.id === 'rest-partner')?.effect,
    { partner: { comfort: 2, trust: 1 } });
});

test('初始用户、资源及伙伴状态互相独立，不会修改目录默认值', () => {
  const user = createInitialUser('demo-user');
  const anotherUser = createInitialUser('another-user');
  assert.deepEqual({ ...user }, { id: 'demo-user', identity: null, partner: null, route: null, progress: 0 });
  user.identity = 'scout';
  assert.equal(anotherUser.identity, null);
  const resources = createInitialResources();
  assert.deepEqual(resources, { energy: 5, food: 10, medical: 3, badge: 0 });
  resources.food = 0;
  assert.equal(createInitialResources().food, 10);
  assert.equal(initialResources.food, 10);
  for (const partner of partners) {
    const status = createInitialPartnerStatus(partner.id);
    assert.deepEqual(status, { energy: partner.energy, comfort: partner.comfort, trust: partner.trust });
    status.trust = 0;
    assert.equal(createInitialPartnerStatus(partner.id).trust, partner.trust);
    assert.ok(partner.assetPath.startsWith('characters/'));
  }
  assert.equal(partnerCareTrustThreshold, 2);
});

test('非法初始 ID 报错，未提供的史料和徽章不填入虚构内容', () => {
  assert.throws(() => createInitialUser('  '), /用户 ID 不能为空/);
  // @ts-expect-error 验证运行时对来自外部数据的未知 ID 也能拒绝。
  assert.throws(() => createInitialPartnerStatus('unknown'), /未知伙伴 ID/);
  assert.equal(stories.length, 0);
  assert.equal(badges.length, 0);
});
