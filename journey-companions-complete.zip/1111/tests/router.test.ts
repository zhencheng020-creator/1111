import assert from 'node:assert/strict';
import test from 'node:test';
import { missions } from '../src/data/index.ts';
import { buildPath, createPageRouter, InvalidRouteError, resolveRoute, routes } from '../src/router/index.ts';
import type { PageName } from '../src/router/index.ts';

test('八个页面路径均能解析到各自页面入口', () => {
  assert.equal(Object.keys(routes).length, 8);
  const paths: Record<PageName, string> = {
    Home: '/home', Identity: '/identity', Partner: '/partner', Route: '/route',
    Map: '/map', Mission: '/mission/grassland-supply', Status: '/status', Archive: '/archive',
  };
  for (const [name, path] of Object.entries(paths)) {
    const router = createPageRouter(path);
    assert.equal(router.current.route.name, name);
    assert.equal(router.current.route.path, path);
    assert.equal(router.current.page.name, name);
    assert.ok(router.current.page.title);
  }
  assert.deepEqual(resolveRoute('/'), { name: 'Home', path: '/home' });
  assert.deepEqual(resolveRoute('/map/'), { name: 'Map', path: '/map' });
});

test('页面入口可按 Home → Identity → Partner → Route → Map 顺序导航', () => {
  const router = createPageRouter();
  for (const name of ['Identity', 'Partner', 'Route', 'Map'] as const) {
    assert.equal(router.navigateTo({ name }).page.name, name);
  }
  assert.deepEqual(router.history.map(location => location.page.name), ['Home', 'Identity', 'Partner', 'Route', 'Map']);
  assert.equal(router.current.page.name, 'Map');
});

test('地图可进入现有任务并携带 ID，返回恢复地图', () => {
  const mission = missions[0];
  assert.ok(mission);
  const router = createPageRouter('/map');
  const location = router.navigateTo({ name: 'Mission', params: { missionId: mission.id } });
  assert.equal(location.page.name, 'Mission');
  assert.deepEqual(location.route, {
    name: 'Mission', path: '/mission/grassland-supply', params: { missionId: mission.id },
  });
  assert.equal(router.navigateBack().page.name, 'Map');
  assert.equal(router.history.length, 1);
});

test('状态页可返回地图，替换为档案页不会增加历史', () => {
  const router = createPageRouter('/map');
  router.navigateTo('/status');
  assert.equal(router.navigateBack().page.name, 'Map');
  router.navigateTo('/status');
  router.redirectTo({ name: 'Archive' });
  assert.deepEqual(router.history.map(location => location.page.name), ['Map', 'Archive']);
  assert.equal(router.navigateBack().page.name, 'Map');
});

test('任务 ID 的空格、中文及特殊字符可编码并还原', () => {
  const missionId = '任务 / A?x=1#节点';
  const target = { name: 'Mission', params: { missionId } } as const;
  const path = buildPath(target);
  assert.equal(path, `/mission/${encodeURIComponent(missionId)}`);
  assert.deepEqual(resolveRoute(path), { ...target, path });
});

test('非法路径、缺失参数和错误编码被拒绝且不破坏导航历史', () => {
  const router = createPageRouter('/map');
  const before = router.history;
  for (const path of ['/missing', '/mission', '/mission/', '/mission/%20', '/mission/%ZZ', '/mission/a/b', 'https://example.com/map']) {
    assert.throws(() => router.navigateTo(path), InvalidRouteError);
    assert.throws(() => router.redirectTo(path), InvalidRouteError);
  }
  // @ts-expect-error 缺少 missionId 既应被类型检查拒绝，也应在运行时拒绝。
  assert.throws(() => router.navigateTo({ name: 'Mission' }), InvalidRouteError);
  // @ts-expect-error 未注册页面来自外部输入时仍应被拒绝。
  assert.throws(() => router.navigateTo({ name: 'Unknown' }), InvalidRouteError);
  assert.deepEqual(router.history, before);
  assert.equal(router.current.page.name, 'Map');
});

test('根页面及越界返回保留根页面，非法返回层数被拒绝', () => {
  const router = createPageRouter();
  assert.equal(router.navigateBack().page.name, 'Home');
  router.navigateTo('/identity');
  router.navigateTo('/partner');
  assert.equal(router.navigateBack(10).page.name, 'Home');
  assert.equal(router.history.length, 1);
  for (const delta of [0, -1, 1.5, NaN, Infinity]) {
    assert.throws(() => router.navigateBack(delta), RangeError);
  }
});

test('历史及任务参数快照不可被调用方改写，各路由实例互相独立', () => {
  const router = createPageRouter('/map');
  const other = createPageRouter();
  const target = { name: 'Mission', params: { missionId: 'grassland-supply' } } as const;
  router.navigateTo(target);
  const history = router.history;
  assert.ok(Object.isFrozen(history));
  assert.ok(Object.isFrozen(router.current));
  assert.ok(Object.isFrozen(router.current.route));
  if (router.current.route.name === 'Mission') assert.ok(Object.isFrozen(router.current.route.params));
  router.navigateBack();
  assert.equal(history.length, 2);
  assert.equal(router.history.length, 1);
  assert.equal(other.current.page.name, 'Home');
});
