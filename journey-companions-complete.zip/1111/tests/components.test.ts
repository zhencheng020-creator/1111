import assert from 'node:assert/strict';
import { after, afterEach, test } from 'node:test';
import { Window } from 'happy-dom';
import { missions } from '../src/data/index.ts';
import type { MissionChoice } from '../src/data/index.ts';

// Vue DOM 渲染器首次加载前设置测试 DOM，避免捕获空 document。
const window = new Window();
for (const [name, value] of Object.entries({
  window, document: window.document, navigator: window.navigator,
  Element: window.Element, HTMLElement: window.HTMLElement,
  SVGElement: window.SVGElement, Node: window.Node,
})) Object.defineProperty(globalThis, name, { value, configurable: true, writable: true });

const { mount, enableAutoUnmount } = await import('@vue/test-utils');
const { h } = await import('vue');
const { Button, Card, IdentityCard, PartnerCard, RouteCard, MissionCard, StatusBar, MapNode, Badge, AchievementBadge } =
  await import('../src/components/index.ts');
const { default: ComponentExamples } = await import('../src/components/examples/ComponentExamples.ts');

enableAutoUnmount(hook => { afterEach(hook); });
after(() => { window.close(); });

test('Button 的三种变体及 disabled 属性正确控制点击，Props 更新即时生效', async () => {
  for (const variant of ['Primary', 'Secondary', 'Disabled'] as const) {
    let clicks = 0;
    const wrapper = mount(Button, { props: { text: '开始同行', variant, onClick: () => clicks++ } });
    assert.equal(wrapper.text(), '开始同行');
    assert.equal(wrapper.attributes('data-figma'), 'Button');
    assert.equal(wrapper.attributes('data-variant'), variant);
    assert.equal(wrapper.element.tagName, 'BUTTON');
    await wrapper.trigger('click');
    assert.equal(clicks, variant === 'Disabled' ? 0 : 1);
  }
  let clicks = 0;
  const wrapper = mount(Button, { props: { text: '确认', onClick: () => clicks++ } });
  await wrapper.setProps({ disabled: true });
  assert.equal(wrapper.attributes('data-variant'), 'Disabled');
  assert.notEqual(wrapper.attributes('disabled'), undefined);
  await wrapper.trigger('click');
  assert.equal(clicks, 0);
  await wrapper.setProps({ disabled: false });
  await wrapper.trigger('click');
  assert.equal(clicks, 1);
});

test('Card 渲染插槽、选中状态及可点击的原生按钮模式', async () => {
  const passive = mount(Card, { slots: { default: () => h('span', '内容') } });
  assert.equal(passive.text(), '内容');
  assert.equal(passive.attributes('data-figma'), 'Card');
  let clicks = 0;
  const selectable = mount(Card, { props: { as: 'button', selected: true, onClick: () => clicks++ } });
  assert.equal(selectable.element.tagName, 'BUTTON');
  assert.equal(selectable.attributes('type'), 'button');
  assert.ok(selectable.classes().includes('zt-card--selected'));
  await selectable.trigger('click');
  assert.equal(clicks, 1);
});

test('IdentityCard 展示所有字段并回传 ID，selected 由外部控制', async () => {
  const selections: string[] = [];
  const wrapper = mount(IdentityCard, { props: {
    id: 'support', name: '后勤员', description: '资源管理', skill: '资源管理',
    icon: '/existing-icon.png', selected: false, onSelect: id => selections.push(id),
  } });
  assert.equal(wrapper.attributes('data-figma'), 'Card/Identity');
  assert.ok(wrapper.text().includes('后勤员'));
  assert.ok(wrapper.text().includes('资源管理'));
  assert.equal(wrapper.find('img').attributes('src'), '/existing-icon.png');
  await wrapper.trigger('click');
  assert.deepEqual(selections, ['support']);
  assert.equal(wrapper.attributes('aria-pressed'), 'false');
  await wrapper.setProps({ id: 'scout', selected: true });
  assert.equal(wrapper.attributes('aria-pressed'), 'true');
  await wrapper.trigger('click');
  assert.deepEqual(selections, ['support', 'scout']);
});

test('PartnerCard 展示头像及三项状态，更新和选择不会修改输入', async () => {
  let selected = '';
  const wrapper = mount(PartnerCard, { props: {
    id: 'xiaowei', name: '小卫', type: '探索型', avatar: '/xiaowei.png',
    energy: 5, comfort: 4, trust: 3, selected: true, onSelect: id => { selected = id; },
  } });
  assert.equal(wrapper.attributes('data-figma'), 'Card/Partner');
  assert.equal(wrapper.find('img').attributes('src'), '/xiaowei.png');
  assert.ok(wrapper.text().includes('探索型'));
  assert.ok(wrapper.text().includes('体力'));
  assert.ok(wrapper.text().includes('安心'));
  assert.ok(wrapper.text().includes('信任'));
  await wrapper.trigger('click');
  assert.equal(selected, 'xiaowei');
  assert.equal(wrapper.props('energy'), 5);
  await wrapper.setProps({ energy: 2 });
  assert.equal(wrapper.find('[data-status="energy"] .zt-partner-card__metric-value').text(), '2');
});

test('RouteCard 展示时长、难度及说明并回传路线 ID', async () => {
  let selected = '';
  const wrapper = mount(RouteCard, { props: {
    id: 'easy', name: '轻体验线', time: '40–50分钟', difficulty: '难度待补充',
    description: '同行路线', selected: true, onSelect: id => { selected = id; },
  } });
  assert.equal(wrapper.attributes('data-figma'), 'Card/Route');
  for (const text of ['轻体验线', '40–50分钟', '难度待补充', '同行路线']) assert.ok(wrapper.text().includes(text));
  await wrapper.trigger('click');
  assert.equal(selected, 'easy');
  assert.equal(wrapper.attributes('aria-pressed'), 'true');
});

test('MissionCard 回传对应的完整方案，不自行执行任务效果', async () => {
  const mission = missions[0]!;
  const before = JSON.stringify(mission);
  const selections: MissionChoice[] = [];
  const wrapper = mount(MissionCard, { props: {
    title: mission.title, description: mission.description, choices: mission.choices,
    onChoice: choice => { selections.push(choice); },
  } });
  assert.equal(wrapper.attributes('data-figma'), 'Card/Mission');
  assert.ok(wrapper.text().includes(mission.title));
  const buttons = wrapper.findAll('button');
  assert.equal(buttons.length, 2);
  await buttons[0]!.trigger('click');
  await buttons[1]!.trigger('click');
  // Vue 会代理嵌套 Props，对比完整数据而非原始对象引用。
  assert.deepEqual(selections, [...mission.choices]);
  assert.deepEqual(selections.map(choice => choice.id), ['supply-food', 'rest-partner']);
  assert.equal(JSON.stringify(mission), before);
});

test('StatusBar 提供带标签的进度条，超范围和无效数值安全显示', async () => {
  const wrapper = mount(StatusBar, { props: { label: '信任', value: 3, max: 5, icon: '/trust.png' } });
  assert.equal(wrapper.attributes('data-figma'), 'StatusBar');
  assert.equal(wrapper.find('progress').attributes('aria-label'), '信任');
  assert.equal(wrapper.find('progress').attributes('value'), '3');
  assert.equal(wrapper.find('img').attributes('src'), '/trust.png');
  for (const [value, expected] of [[12, 5], [-3, 0], [NaN, 0], [Infinity, 0]] as const) {
    await wrapper.setProps({ value });
    assert.equal(wrapper.find('progress').attributes('value'), String(expected));
    assert.equal(wrapper.find('progress').attributes('max'), '5');
  }
  await wrapper.setProps({ value: 3, max: 0 });
  assert.equal(wrapper.find('progress').attributes('max'), '1');
  assert.equal(wrapper.find('progress').attributes('value'), '1');
});

test('MapNode 四种变体标识正确，locked 不允许点击，其余状态回传点击', async () => {
  for (const status of ['locked', 'current', 'complete', 'story'] as const) {
    let clicks = 0;
    const wrapper = mount(MapNode, { props: { name: '草地补给站', status, onClick: () => clicks++ } });
    assert.equal(wrapper.attributes('data-figma'), 'MapNode');
    assert.equal(wrapper.attributes('data-variant'), status);
    assert.ok(wrapper.attributes('aria-label')?.includes('草地补给站'));
    assert.equal(wrapper.attributes('disabled') !== undefined, status === 'locked');
    await wrapper.trigger('click');
    assert.equal(clicks, status === 'locked' ? 0 : 1);
  }
});

test('Badge 展示解锁状态及已有图标，AchievementBadge 是同一组件别名', async () => {
  assert.equal(AchievementBadge, Badge);
  const wrapper = mount(Badge, { props: { name: '徽章示例', icon: '/badge.png', unlocked: false } });
  assert.equal(wrapper.attributes('data-figma'), 'Badge');
  assert.ok(wrapper.text().includes('未解锁'));
  assert.equal(wrapper.find('img').attributes('src'), '/badge.png');
  await wrapper.setProps({ unlocked: true });
  assert.equal(wrapper.attributes('data-unlocked'), 'true');
  assert.ok(wrapper.text().includes('已解锁'));
});

test('缺少图标或头像时不创建假素材，字符串按文本转义', () => {
  const wrapper = mount(IdentityCard, { props: { id: 'demo', name: '<script>danger</script>', description: '', skill: '' } });
  assert.equal(wrapper.findAll('img').length, 0);
  assert.equal(wrapper.findAll('script').length, 0);
  assert.ok(wrapper.text().includes('<script>danger</script>'));
});

test('全部组件使用示例可实际挂载，回调和禁用示例有效', async () => {
  const actions: string[] = [];
  const wrapper = mount(ComponentExamples, { props: { onAction: message => actions.push(message) } });
  assert.equal(wrapper.findAll('[data-figma="MapNode"]').length, 4);
  assert.equal(wrapper.findAll('[data-figma="Badge"]').length, 2);
  for (const figma of ['Button', 'Card', 'Card/Identity', 'Card/Partner', 'Card/Route', 'Card/Mission', 'StatusBar']) {
    assert.ok(wrapper.find(`[data-figma="${figma}"]`).exists());
  }
  await wrapper.find('[data-figma="Button"][data-variant="Primary"]').trigger('click');
  await wrapper.find('[data-figma="Button"][data-variant="Disabled"]').trigger('click');
  assert.deepEqual(actions, ['开始同行']);
  // 路线场景、任务卷轴和两个行动图标来自当前真实素材系统。
  assert.equal(wrapper.findAll('img').length, 5);
  for (const image of wrapper.findAll('img')) assert.ok(image.attributes('src'));
});
