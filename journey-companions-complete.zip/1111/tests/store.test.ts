import assert from 'node:assert/strict';
import { afterEach, test } from 'node:test';
import { createPinia, setActivePinia } from 'pinia';
import { watchEffect } from 'vue';
import { badges, stories, missions, partners } from '../src/data/index.ts';
import type { AchievementBadge, Mission, Story } from '../src/data/models.ts';
import { useUserStore, usePartnerStore, useResourceStore, useRouteStore, useMissionStore, useArchiveStore, resetJourney, JourneyError } from '../src/store/index.ts';
import { useJourneyPageExample } from '../src/store/examples/useJourneyPageExample.ts';

// 奖励测试使用进程内 fixture，执行后恢复；不改动产品目录或真实史料文件。
const originalBadges = [...badges];
const originalStories = [...stories];
const originalMissions = [...missions];
afterEach(() => {
  (badges as AchievementBadge[]).splice(0, badges.length, ...originalBadges);
  (stories as Story[]).splice(0, stories.length, ...originalStories);
  (missions as Mission[]).splice(0, missions.length, ...originalMissions);
});

function fresh() {
  const pinia = createPinia();
  setActivePinia(pinia);
  return {
    pinia, user: useUserStore(pinia), partner: usePartnerStore(pinia),
    resource: useResourceStore(pinia), route: useRouteStore(pinia),
    mission: useMissionStore(pinia), archive: useArchiveStore(pinia),
  };
}

function ready() {
  const stores = fresh();
  stores.user.selectIdentity('support');
  stores.user.selectPartner('xiaowei');
  stores.user.selectRoute('easy');
  // 启程站尚无任务数据，仅为 store 测试准备已解锁的草地节点。
  stores.route.completeNode('departure');
  stores.route.unlockNode('grassland');
  stores.mission.openMission('grassland-supply');
  return stores;
}

function hasCode(code: string) {
  return (error: unknown): boolean => error instanceof JourneyError && error.code === code;
}

function snapshot(stores: ReturnType<typeof fresh>) {
  return JSON.stringify({
    user: { identity: stores.user.identity, partner: stores.user.partner, route: stores.user.route, progress: stores.user.progress },
    partner: stores.partner.partner, resource: stores.resource.getSnapshot(),
    statuses: stores.route.nodeStatuses, current: stores.route.currentNodeId,
    stories: stores.route.unlockedStoryIds, badges: stores.resource.earnedBadgeIds,
    records: stores.mission.records, result: stores.mission.result,
  });
}

test('初始选择、进度、资源、伙伴、任务与档案状态符合需求', () => {
  const s = fresh();
  assert.deepEqual([s.user.identity, s.user.partner, s.user.route, s.user.progress], [null, null, null, 0]);
  assert.deepEqual(s.resource.getSnapshot(), { energy: 5, food: 10, medical: 3, badge: 0 });
  assert.equal(s.partner.partner, null);
  assert.equal(s.partner.needsCare, false);
  assert.equal(s.mission.currentMission, null);
  assert.equal(s.mission.selectedChoice, null);
  assert.equal(s.mission.result, null);
  assert.equal(s.archive.archive, null);
  assert.equal(s.archive.canGenerate, false);
  assert.equal(s.archive.isComplete, false);
  assert.throws(() => s.archive.generateArchive(), hasCode('SELECTION_INCOMPLETE'));
});

test('选择初始化关联状态，同项重选保留伙伴状态和节点进度', () => {
  const s = fresh();
  s.user.selectIdentity('scout');
  s.user.selectPartner('chifeng');
  s.user.selectRoute('normal');
  assert.deepEqual(s.partner.partner, { id: 'chifeng', name: '赤风', energy: 5, comfort: 4, trust: 5 });
  s.partner.increaseComfort(2);
  s.user.selectPartner('chifeng');
  assert.equal(s.partner.partner?.comfort, 6);
  s.route.completeNode('departure');
  s.route.unlockNode('grassland');
  s.user.selectRoute('normal');
  assert.equal(s.route.routeId, 'normal');
  assert.equal(s.route.nodeStatuses.departure, 'complete');
  assert.equal(s.route.currentNodeId, 'grassland');
  assert.equal(s.archive.canGenerate, true);
});

test('未知身份、伙伴、路线及无效进度被拒绝，合法状态保留', () => {
  const s = fresh();
  const before = snapshot(s);
  // @ts-expect-error 检查外部字符串输入的运行时拒绝行为。
  assert.throws(() => s.user.selectIdentity('unknown'), hasCode('UNKNOWN_IDENTITY'));
  // @ts-expect-error 检查外部字符串输入的运行时拒绝行为。
  assert.throws(() => s.user.selectPartner('unknown'), hasCode('UNKNOWN_PARTNER'));
  // @ts-expect-error 检查外部字符串输入的运行时拒绝行为。
  assert.throws(() => s.user.selectRoute('unknown'), hasCode('UNKNOWN_ROUTE'));
  for (const amount of [-1, 0.5, NaN, Infinity]) assert.throws(() => s.user.updateProgress(amount), hasCode('INVALID_PROGRESS'));
  assert.equal(snapshot(s), before);
});

test('伙伴照顾提示随信任变化，数值可超过初始值且与静态目录隔离', () => {
  const s = fresh();
  assert.throws(() => s.partner.updateEnergy(-1), hasCode('PARTNER_NOT_SELECTED'));
  s.user.selectPartner('xiaowei');
  s.partner.applyDelta({ trust: -4 });
  assert.equal(s.partner.needsCare, true);
  s.partner.increaseTrust();
  assert.equal(s.partner.needsCare, false);
  s.partner.increaseComfort(2);
  assert.equal(s.partner.partner?.comfort, 7);
  assert.equal(partners.find(item => item.id === 'xiaowei')?.comfort, 5);
  const before = JSON.stringify(s.partner.partner);
  assert.throws(() => s.partner.applyDelta({ comfort: 3, energy: -6 }), hasCode('INSUFFICIENT_RESOURCE'));
  assert.throws(() => s.partner.increaseTrust(-1), hasCode('INVALID_AMOUNT'));
  assert.equal(JSON.stringify(s.partner.partner), before);
});

test('物资增减、人物恢复及医疗增量正确，失败不造成部分资源更新', () => {
  const s = fresh();
  s.resource.consumeFood(3);
  s.resource.addFood(2);
  s.resource.recoverEnergy(2);
  s.resource.applyDelta({ medical: -1 });
  assert.deepEqual(s.resource.getSnapshot(), { energy: 7, food: 9, medical: 2, badge: 0 });
  const before = s.resource.getSnapshot();
  assert.throws(() => s.resource.consumeFood(10), hasCode('INSUFFICIENT_RESOURCE'));
  assert.throws(() => s.resource.applyDelta({ food: 4, energy: -8 }), hasCode('INSUFFICIENT_RESOURCE'));
  assert.throws(() => s.resource.addFood(NaN), hasCode('INVALID_AMOUNT'));
  assert.throws(() => s.resource.recoverEnergy(-1), hasCode('INVALID_AMOUNT'));
  assert.throws(() => s.resource.applyDelta({ badge: 1 }), hasCode('BADGE_ID_REQUIRED'));
  assert.deepEqual(s.resource.getSnapshot(), before);
});

test('地图禁止跨越未完成节点、完成锁定节点或重置完成状态', () => {
  const s = fresh();
  s.user.selectRoute('easy');
  assert.throws(() => s.route.unlockNode('grassland'), hasCode('PREVIOUS_NODE_PENDING'));
  assert.throws(() => s.route.setCurrentNode('grassland'), hasCode('NODE_LOCKED'));
  assert.throws(() => s.route.completeNode('grassland'), hasCode('NODE_NOT_CURRENT'));
  s.route.completeNode('departure');
  assert.equal(s.route.completeNode('departure'), false);
  assert.throws(() => s.route.setCurrentNode('departure'), hasCode('NODE_COMPLETE'));
  s.route.unlockNode('grassland');
  s.route.setCurrentNode('grassland');
  assert.equal(s.route.currentNodeId, 'grassland');
  assert.equal(s.route.nodes.filter(node => node.status === 'current').length, 1);
});

test('伙伴休息效果只更新伙伴，任务完成同步节点、进度和档案', () => {
  const s = ready();
  s.mission.selectChoice('rest-partner');
  const result = s.mission.applyEffect();
  assert.deepEqual(result.partnerAfter, { energy: 5, comfort: 7, trust: 6 });
  assert.deepEqual(s.resource.getSnapshot(), { energy: 5, food: 10, medical: 3, badge: 0 });
  assert.equal(s.user.progress, 1);
  assert.deepEqual(s.mission.completedTasks, ['grassland-supply']);
  assert.equal(s.route.nodeStatuses.grassland, 'complete');
  assert.equal(s.route.nodeStatuses['snow-mountain'], 'current');
  assert.equal(s.route.currentNodeId, 'snow-mountain');
  assert.deepEqual(s.archive.archive, {
    identity: 'support', partner: 'xiaowei', route: 'easy',
    completedTasks: ['grassland-supply'], stories: [], badges: [],
  });
  assert.equal(s.archive.isComplete, false);
  assert.ok(Object.isFrozen(result));
  assert.ok(Object.isFrozen(result.partnerAfter));
  s.partner.increaseComfort(1);
  assert.equal(result.partnerAfter.comfort, 7);
});

test('补充粮食增加食物并消耗人物体力，不改变伙伴体力', () => {
  const s = ready();
  s.mission.selectChoice('supply-food');
  s.mission.applyEffect();
  assert.deepEqual(s.resource.getSnapshot(), { energy: 4, food: 13, medical: 3, badge: 0 });
  assert.equal(s.partner.partner?.energy, 5);
  assert.equal(s.user.progress, 1);
});

test('重复 applyEffect 和重开已完成任务均不重复发放效果', () => {
  const s = ready();
  s.mission.selectChoice('rest-partner');
  const first = s.mission.applyEffect();
  const before = snapshot(s);
  assert.equal(s.mission.applyEffect(), first);
  assert.equal(snapshot(s), before);
  s.mission.openMission('grassland-supply');
  assert.equal(s.mission.applyEffect(), first);
  assert.throws(() => s.mission.selectChoice('supply-food'), hasCode('MISSION_COMPLETE'));
  assert.equal(snapshot(s), before);
});

test('任务缺少选择或资源不足时，全部关联状态保持不变', () => {
  const s = ready();
  assert.throws(() => s.mission.selectChoice('missing'), hasCode('UNKNOWN_CHOICE'));
  assert.throws(() => s.mission.applyEffect(), hasCode('CHOICE_NOT_SELECTED'));
  s.mission.selectChoice('supply-food');
  s.resource.applyDelta({ energy: -5 });
  const before = snapshot(s);
  assert.throws(() => s.mission.applyEffect(), hasCode('INSUFFICIENT_RESOURCE'));
  assert.equal(snapshot(s), before);
  s.resource.recoverEnergy();
  s.mission.applyEffect();
  assert.equal(s.resource.energy, 0);
  assert.equal(s.user.progress, 1);
});

test('进度溢出在效果提交前被拒绝，不出现半完成任务', () => {
  const s = ready();
  s.mission.selectChoice('rest-partner');
  s.user.updateProgress(Number.MAX_SAFE_INTEGER);
  const before = snapshot(s);
  assert.throws(() => s.mission.applyEffect(), hasCode('INVALID_PROGRESS'));
  assert.equal(snapshot(s), before);
});

test('未知、未解锁任务及未完成选择不会开启任务', () => {
  const s = fresh();
  assert.throws(() => s.mission.openMission('missing'), hasCode('UNKNOWN_MISSION'));
  assert.throws(() => s.mission.openMission('grassland-supply'), hasCode('SELECTION_INCOMPLETE'));
  s.user.selectIdentity('support'); s.user.selectPartner('xiaowei'); s.user.selectRoute('easy');
  assert.throws(() => s.mission.openMission('grassland-supply'), hasCode('NODE_NOT_CURRENT'));
  assert.equal(s.mission.currentMission, null);
});

test('新增故事和徽章 fixture 按唯一 ID 发放，数量及档案列表一致', () => {
  (badges as AchievementBadge[]).push({ id: 'fixture-badge', name: '测试徽章', description: '仅测试', assetPath: 'fixture.png' });
  (stories as Story[]).push({ id: 'fixture-story', title: '测试故事', content: '仅测试，不是史料', sources: [{ title: '测试 fixture', citation: '不属于真实史料' }] });
  const original = originalMissions[0]!;
  (missions as Mission[])[0] = {
    ...original, choices: [{ id: 'fixture-choice', label: '测试方案', effect: {
      partner: { comfort: 2 }, awardBadgeIds: ['fixture-badge', 'fixture-badge'], unlockStoryIds: ['fixture-story', 'fixture-story'],
    } }],
  };
  const s = ready();
  s.mission.selectChoice('fixture-choice');
  s.mission.applyEffect();
  assert.equal(s.resource.badge, 1);
  assert.equal(s.resource.addBadge('fixture-badge'), false);
  assert.equal(s.route.unlockStory('fixture-story'), false);
  assert.deepEqual(s.archive.archive?.badges, ['fixture-badge']);
  assert.deepEqual(s.archive.archive?.stories, ['fixture-story']);
});

test('未定义奖励在提交前被拒绝，不凭空生成故事或徽章', () => {
  const original = originalMissions[0]!;
  (missions as Mission[])[0] = {
    ...original, choices: [{ id: 'fixture-invalid', label: '测试无效奖励', effect: {
      resources: { food: 3 }, awardBadgeIds: ['missing-badge'],
    } }],
  };
  const s = ready();
  s.mission.selectChoice('fixture-invalid');
  const before = snapshot(s);
  assert.throws(() => s.mission.applyEffect(), hasCode('UNKNOWN_BADGE'));
  assert.equal(snapshot(s), before);
  assert.throws(() => s.route.unlockStory('missing-story'), hasCode('UNKNOWN_STORY'));
});

test('档案自动响应、导出副本隔离，最终完成标志与节点状态一致', () => {
  const s = ready();
  const exports = s.archive.generateArchive();
  exports.completedTasks.push('local-edit');
  assert.deepEqual(s.archive.archive?.completedTasks, []);
  let taskCount = 0;
  const stop = watchEffect(() => { taskCount = s.archive.archive?.completedTasks.length ?? 0; }, { flush: 'sync' });
  s.mission.selectChoice('rest-partner'); s.mission.applyEffect();
  assert.equal(taskCount, 1);
  stop();
  // 验证节点状态契约，未假设这些待补充节点已有任务或史料。
  for (const id of ['snow-mountain', 'bridge', 'silent-partner', 'finish'] as const) {
    assert.equal(s.route.currentNodeId, id);
    if (id === 'silent-partner') assert.equal(s.route.nodeStatuses[id], 'story');
    s.route.completeNode(id);
    const next = s.route.nextNodeId(id);
    if (next) s.route.unlockNode(next);
  }
  assert.equal(s.archive.isComplete, true);
  assert.equal(s.route.currentNodeId, null);
});

test('完成任务后改选被拒绝，完整重置清除记录、资源、地图与档案', () => {
  const s = ready();
  s.mission.selectChoice('rest-partner'); s.mission.applyEffect();
  assert.throws(() => s.user.selectPartner('chifeng'), hasCode('SELECTION_LOCKED'));
  assert.throws(() => s.user.selectRoute('challenge'), hasCode('SELECTION_LOCKED'));
  assert.throws(() => s.user.selectIdentity('medical'), hasCode('SELECTION_LOCKED'));
  s.user.selectPartner('xiaowei');
  assert.equal(s.partner.partner?.comfort, 7);
  resetJourney(s.pinia);
  assert.equal(s.user.progress, 0);
  assert.equal(s.user.identity, null);
  assert.equal(s.partner.$state.partner, null);
  assert.equal(s.archive.archive, null);
  assert.equal(s.mission.records.length, 0);
  assert.equal(s.mission.selectedChoice, null);
  assert.deepEqual(s.resource.getSnapshot(), { energy: 5, food: 10, medical: 3, badge: 0 });
  assert.equal(s.route.nodeStatuses.departure, 'current');
  assert.equal(s.route.nodeStatuses.grassland, 'locked');
  assert.equal(s.route.routeId, null);
  s.user.selectPartner('chifeng');
  assert.equal(s.partner.partner?.name, '赤风');
});

test('不同 Pinia 实例之间状态隔离，旧实例 action 不依赖当前 activePinia', () => {
  const first = ready();
  const second = fresh();
  first.mission.selectChoice('rest-partner'); first.mission.applyEffect();
  assert.equal(first.user.progress, 1);
  assert.equal(second.user.progress, 0);
  assert.equal(second.partner.partner, null);
  assert.equal(second.resource.food, 10);
  resetJourney(first.pinia);
  assert.equal(second.user.identity, null);
});

test('页面调用示例保持 ref 响应，回调效果在 store 层完成', () => {
  const s = fresh();
  const page = useJourneyPageExample();
  page.onIdentitySelect('support'); page.onPartnerSelect('xiaowei'); page.onRouteSelect('easy');
  assert.equal(page.identity.value, 'support');
  assert.equal(page.activePartner.value?.comfort, 5);
  s.route.completeNode('departure'); s.route.unlockNode('grassland');
  page.openMission('grassland-supply');
  page.onChoice(missions[0]!.choices[1]!);
  assert.equal(page.activePartner.value?.comfort, 7);
  assert.equal(page.progress.value, 1);
  assert.equal(page.journeyArchive.value?.completedTasks.length, 1);
  assert.throws(() => page.onIdentitySelect('unknown'), hasCode('UNKNOWN_IDENTITY'));
});
