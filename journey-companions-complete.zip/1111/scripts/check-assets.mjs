import { writeFile } from 'node:fs/promises';
import { fileURLToPath } from 'node:url';
import { assetDirectories, getAssetDiagnostics } from '../src/assets/assetMap.ts';

const diagnostics = getAssetDiagnostics();
const report = {
  status: diagnostics.missing.length ? 'missing' : 'available',
  ...diagnostics,
  categories: Object.fromEntries(Object.entries(assetDirectories).map(([category, prefix]) => [category, {
    available: diagnostics.available.filter(url => url.startsWith(prefix)).length,
    missing: diagnostics.missing.filter(url => url.startsWith(prefix)).length,
  }])),
};
await writeFile(fileURLToPath(new URL('../src/assets/asset-check.json', import.meta.url)), JSON.stringify(report, null, 2) + '\n');
console.log(JSON.stringify(report, null, 2));
if (diagnostics.missing.length) process.exitCode = 1;
