import { mkdir, readdir, readFile, writeFile, copyFile, unlink } from 'node:fs/promises';
import { createHash } from 'node:crypto';
import { fileURLToPath } from 'node:url';
import path from 'node:path';

const defaultRoot = fileURLToPath(new URL('../', import.meta.url));
const categories = ['characters', 'identity', 'backgrounds', 'icons', 'badges', 'scenes', 'stories'];
const extensions = new Set(['.png', '.jpg', '.jpeg', '.webp', '.gif', '.svg', '.avif']);
const digest = bytes => createHash('sha256').update(bytes).digest('hex');

async function readOptional(filename) {
  try { return await readFile(filename); }
  catch (error) { if (error.code === 'ENOENT') return null; throw error; }
}
async function imageFiles(root, directory = root) {
  const files = [];
  for (const entry of await readdir(directory, { withFileTypes: true })) {
    const filename = path.join(directory, entry.name);
    if (entry.isSymbolicLink()) throw new Error('素材目录请使用实际文件，不能使用符号链接');
    if (entry.isDirectory()) files.push(...await imageFiles(root, filename));
    else if (entry.isFile() && extensions.has(path.extname(entry.name).toLowerCase())) {
      files.push({ filename, relative: path.relative(root, filename).split(path.sep).join('/') });
    }
  }
  return files;
}

/** 逐字节复制已有素材，不生成或加工图片；保护非本脚本管理的 public 文件。 */
export async function syncAssets(projectRoot = defaultRoot) {
  const sourceRoot = path.join(projectRoot, 'src/assets');
  const publicRoot = path.join(projectRoot, 'public/assets');
  for (const category of categories) {
    await mkdir(path.join(sourceRoot, category), { recursive: true });
    await mkdir(path.join(publicRoot, category), { recursive: true });
  }
  // 写入前检查 public 目录，避免通过符号链接覆盖其他文件。
  await imageFiles(publicRoot);
  const ownershipPath = path.join(publicRoot, '.source-sync.json');
  const previous = JSON.parse((await readOptional(ownershipPath))?.toString() ?? '{}');
  const source = (await Promise.all(categories.map(category => imageFiles(sourceRoot, path.join(sourceRoot, category))))).flat();
  const next = {};
  const operations = [];
  for (const { filename, relative } of source) {
    const target = path.join(publicRoot, relative);
    const sourceBytes = await readFile(filename);
    const targetBytes = await readOptional(target);
    const checksum = digest(sourceBytes);
    if (targetBytes && digest(targetBytes) !== checksum && previous[relative] !== digest(targetBytes)) {
      throw new Error(`同名素材冲突，请保留一个明确版本：${relative}`);
    }
    next[relative] = checksum;
    if (!targetBytes || digest(targetBytes) !== checksum) operations.push(async () => {
      await mkdir(path.dirname(target), { recursive: true });
      await copyFile(filename, target);
    });
  }
  for (const [relative, checksum] of Object.entries(previous)) {
    if (relative.includes('\\') || !categories.includes(relative.split('/')[0]) || relative.split('/').some(part => part === '..' || part === '.' || !part) || !extensions.has(path.extname(relative).toLowerCase())) {
      throw new Error('素材同步记录包含无效路径');
    }
    if (next[relative]) continue;
    const target = path.join(publicRoot, relative);
    const bytes = await readOptional(target);
    if (bytes && digest(bytes) === checksum) operations.push(() => unlink(target));
  }
  for (const operation of operations) await operation();
  const state = JSON.stringify(next, null, 2) + '\n';
  if ((await readOptional(ownershipPath))?.toString() !== state) await writeFile(ownershipPath, state);
  const files = (await imageFiles(publicRoot)).map(({ relative }) => '/assets/' + relative.split('/').map(encodeURIComponent).join('/')).sort();
  const output = '// 由 scripts/sync-assets.mjs 生成；列表仅说明实际文件存在。\n' +
    `export const availableAssets: readonly string[] = Object.freeze(${JSON.stringify(files, null, 2)});\n`;
  const destination = path.join(sourceRoot, 'assetManifest.ts');
  if ((await readOptional(destination))?.toString() !== output) await writeFile(destination, output);
  return { sourceCount: source.length, availableCount: files.length, files };
}

if (process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  const result = await syncAssets();
  console.log(`素材清单：${result.availableCount} 个现有文件；同步 ${result.sourceCount} 个源素材，未生成或加工图片。`);
}
