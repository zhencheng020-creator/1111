import { defineComponent, h } from 'vue';
import { RouterView } from 'vue-router';

export default defineComponent({
  name: 'JourneyApp',
  setup() { return () => h('main', { id: 'journey-app' }, [h(RouterView)]); },
});
