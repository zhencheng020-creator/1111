import { createApp } from 'vue';
import { createPinia } from 'pinia';
import App from './App.ts';
import { createAppRouter } from './router/appRouter.ts';
import './components/design-system/components.css';
import './styles/app.css';

const pinia = createPinia();
const router = createAppRouter(pinia);
const app = createApp(App);
app.use(pinia);
app.use(router);
void router.isReady().then(() => app.mount('#app'));
