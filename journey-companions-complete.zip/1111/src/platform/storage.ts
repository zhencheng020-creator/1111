export const journeyStorageKey = 'journey-companions:state:v1';

export interface JourneyStorageAdapter {
  get<T>(key: string): T | null;
  set<T>(key: string, value: T): void;
  remove(key: string): void;
}

/** Web adapter; uni-app Phase 9.2 can provide the same shape through uni storage. */
export const webStorageAdapter: JourneyStorageAdapter = {
  get<T>(key: string): T | null {
    if (typeof localStorage === 'undefined') return null;
    const raw = localStorage.getItem(key);
    if (!raw) return null;
    try { return JSON.parse(raw) as T; } catch { return null; }
  },
  set<T>(key: string, value: T): void {
    if (typeof localStorage !== 'undefined') localStorage.setItem(key, JSON.stringify(value));
  },
  remove(key: string): void { if (typeof localStorage !== 'undefined') localStorage.removeItem(key); },
};

export interface JourneyStorageV1 {
  version: 1;
  updatedAt: number;
  user: { identity: string | null; partner: string | null; route: string | null; progress: number };
  partner: { partner: { id: string; name: string; energy: number; comfort: number; trust: number } | null };
  route: { routeId: string | null; nodeStatuses: Record<string, string>; currentNodeId: string | null; unlockedStoryIds: string[] };
  mission: { records: readonly unknown[]; activeMissionId: string | null; selectedChoiceId: string | null };
  resource: { energy: number; food: number; medical: number; earnedBadgeIds: string[] };
}
