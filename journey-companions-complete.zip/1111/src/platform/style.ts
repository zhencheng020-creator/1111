/**
 * Web uses a deduplicated style element; uni-app can replace this adapter with
 * an empty implementation because component CSS is imported statically there.
 */
export function injectStyle(id: string, cssText: string): void {
  if (typeof document === 'undefined') return;
  if (document.getElementById(id)) return;
  const style = document.createElement('style');
  style.id = id;
  style.textContent = cssText;
  document.head.appendChild(style);
}
