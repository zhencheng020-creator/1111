# 视觉资产接入

Phase 7.6 已完成真实视觉素材导入：上传包中的 50 张原始透明 PNG 已逐字节保存在 `src/assets`，并同步到 `public/assets`。另有 8 个 identity 入口是现有素材的逐字节复用，未修改图像内容。

## 目录

```text
src/assets/
  characters/          # xiaowei、chifeng、feiyu、xiaotuo、aniu
  identity/            # support、scout、medical、record
  backgrounds/         # 页面背景入口；当前使用 scenes 中的真实场景图
  icons/               # mission、mission-complete、选项 ID、地图节点 ID
  badges/              # 对应已有徽章 ID；未添加任何徽章业务定义
  scenes/              # camp、mountain、river、monument、sunset 路线场景
  stories/             # 保留原有故事素材接口
  scenes/              # 保留原有目录
  assetMap.ts          # 统一映射及缺失诊断
  assetManifest.ts     # 同步脚本生成的实际文件清单
  AssetImage.ts        # 图片加载/解码失败时渲染 fallback
  asset-check.json     # 当前缺图检查结果
```

## 导入已有素材

将已有原图放入对应目录，文件名使用上述 ID。支持 PNG、JPG、JPEG、WebP、GIF、SVG、AVIF；映射优先使用实际存在的文件，未提供文件时仅保留预期路径，不创建破图请求。

运行 `npm run assets:sync`，会将 `src/assets` 中已有图片按原目录逐字节复制到 `public/assets`，供开发和生产构建使用。`npm run dev`、`npm run build`、`npm test` 已有的前置脚本都会执行同步。开发服务运行期间导入新素材后，应重新运行同步。

同步记录位于 `public/assets/.source-sync.json`。不会覆盖与源文件不同且未由本脚本管理的 public 文件；此时报告同名冲突。移除源图片时，只清理内容未被修改的旧同步副本，保留手工修改的 public 图片。

同步不生成图片，不缩放、不重编码原图。业务目录、伙伴状态、任务效果和徽章发放机制均不改变。

## 统一映射

```ts
assetMap.characters.xiaowei
assetMap.identity.support
assetMap.backgrounds.Map
assetMap.icons.mission
assetMap.badges[badgeId]
```

保留 `assetMap.xiaowei` 等原调用键。组件 Props/回调接口未改变；页面使用 `assetProp()` 提供确实存在的 icon/avatar，普通图片使用 `resolveAssetUrl()` 和 `AssetImage`。

## fallback

- 缺文件：清单检查后不创建 img，保留角色文字占位、任务图标文字、选项编号、徽章占位或 Paper 背景。
- 404、网络错误、解码失败：原生 img 的 error 事件切换到已有 fallback；业务状态不受影响。
- 图片加载错误后替换成新的 URL：重新尝试加载新 URL。

## 检查

```bash
npm run assets:sync
node scripts/check-assets.mjs
npm run build
```

检查脚本生成 `asset-check.json`，有已登记资源缺失时退出码为 1。当前检查结果为 `available`：58 个静态文件可用（伙伴及变体 24、身份入口 8、图标 12、徽章 4、场景 6、故事 4），无缺失或未映射文件。背景入口复用场景目录中的真实 PNG，因为素材包没有独立 backgrounds 目录。

已通过构建、原图 SHA-256 校验、透明通道检查、资源同步和加载失败回退检查。`imported-assets.json` 记录每张原图及复用入口的校验值。
