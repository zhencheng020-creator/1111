import { defineComponent, h, ref } from 'vue';

/** 内部图片渲染助手；404 或解码失败后渲染 fallback，不影响业务状态。 */
export default defineComponent({
  name: 'AssetImage',
  inheritAttrs: false,
  props: { src: { type: String, default: '' }, alt: { type: String, default: '' } },
  setup(props, { slots, attrs }) {
    const failedUrl = ref<string | null>(null);
    return () => props.src && failedUrl.value !== props.src
      ? h('img', { ...attrs, src: props.src, alt: props.alt, onError: () => { failedUrl.value = props.src ?? null; } })
      : slots.fallback?.() ?? null;
  },
});
