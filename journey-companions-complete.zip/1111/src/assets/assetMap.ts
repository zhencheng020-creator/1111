import type { IdentityId, PartnerId, RouteId, MapNodeId } from '../data/models.ts';
import type { PageName } from '../router/types.ts';
import { availableAssets } from './assetManifest.ts';

export type AssetCategory = 'characters' | 'identity' | 'backgrounds' | 'icons' | 'badges' | 'scenes' | 'stories';
export const assetDirectories: Record<AssetCategory, string> = {
  characters: '/assets/characters/', identity: '/assets/identity/',
  backgrounds: '/assets/backgrounds/', icons: '/assets/icons/',
  badges: '/assets/badges/', scenes: '/assets/scenes/', stories: '/assets/stories/',
};

/** 文件名对应业务 ID，自动识别已有 PNG/JPG/WebP 等素材。 */
function categoryAssets(category: AssetCategory): Record<string, string> {
  const result: Record<string, string> = {};
  for (const url of availableAssets) {
    if (!url.startsWith(assetDirectories[category])) continue;
    const relative = decodeURIComponent(url.slice(assetDirectories[category].length));
    if (relative.includes('/')) continue;
    const id = relative.replace(/\.[^.]+$/, '');
    if (!result[id] || url.endsWith('.png')) result[id] = url;
  }
  return result;
}

export function assetPath(category: AssetCategory, id: string): string {
  return categoryAssets(category)[id] ?? `${assetDirectories[category]}${encodeURIComponent(id)}.png`;
}
export function catalogAssetPath(relative: string): string {
  return '/assets/' + relative.split('/').map(encodeURIComponent).join('/');
}

/** Phase 9.2 migration helper; it does not move files or change Web URLs. */
export function toUniStaticPath(path: string | undefined): string | undefined {
  return path?.startsWith('/assets/') ? `/static/assets/${path.slice('/assets/'.length)}` : path;
}

export type VisualCharacterId = PartnerId | 'juzi';
const characters: Record<VisualCharacterId, string> & Record<string, string> = {
  ...categoryAssets('characters'),
  xiaowei: assetPath('characters', 'xiaowei'), chifeng: assetPath('characters', 'chifeng'),
  feiyu: assetPath('characters', 'feiyu'), xiaotuo: assetPath('characters', 'xiaotuo'),
  aniu: assetPath('characters', 'aniu'), juzi: assetPath('characters', 'juzi'),
};
export interface CharacterVisual {
  portrait: string;
  avatar: string;
  rest?: string;
  hurt?: string;
  mission?: string;
  fly?: string;
  mini?: string;
  happy?: string;
}
const characterVisuals: Record<string, CharacterVisual> = {
  xiaowei: { portrait: characters.xiaowei, avatar: characters.xiaowei_mini_standing!, rest: characters.xiaowei_rest!, mini: characters.xiaowei_mini_standing!, happy: characters.xiaowei_mini_happy! },
  chifeng: { portrait: characters.chifeng, avatar: characters.chifeng_head!, rest: characters.chifeng_rest!, mini: characters.chifeng_mini! },
  xiaotuo: { portrait: characters.xiaotuo, avatar: characters.xiaotuo_head!, mission: characters.xiaotuo_mission! },
  aniu: { portrait: characters.aniu, avatar: characters.aniu_head!, hurt: characters.aniu_hurt!, mini: characters.aniu_mini! },
  feiyu: { portrait: characters.feiyu, avatar: characters.feiyu_head!, rest: characters.feiyu_rest!, fly: characters.feiyu_fly!, mini: characters.feiyu_mini_mail! },
  juzi: { portrait: characters.juzi, avatar: characters.juzi_head!, rest: characters.juzi_rest!, mini: characters.juzi_mini! },
};
const identity: Record<IdentityId, string> = {
  support: assetPath('identity', 'support'), scout: assetPath('identity', 'scout'),
  medical: assetPath('identity', 'medical'), record: assetPath('identity', 'record'),
};
const identityIllustrations: Record<IdentityId, string> = {
  support: assetPath('identity', 'support_illustration'), scout: assetPath('identity', 'scout_illustration'),
  medical: assetPath('identity', 'medical_illustration'), record: assetPath('identity', 'record_illustration'),
};
const scenes = {
  ...categoryAssets('scenes'),
  camp: assetPath('scenes', 'camp_tent'), supply: assetPath('scenes', 'camp_supply'),
  mountain: assetPath('scenes', 'scene_snow_mountain'), river: assetPath('scenes', 'scene_bridge_river'),
  monument: assetPath('scenes', 'scene_monument'), sunset: assetPath('scenes', 'scene_sunset_valley'),
};
const backgrounds: Record<PageName, string> = {
  Home: scenes.camp, Identity: scenes.supply, Partner: scenes.camp, Route: scenes.sunset,
  Map: scenes.sunset, Mission: scenes.supply, Status: scenes.camp, Archive: scenes.monument,
};
const badgeAssets = categoryAssets('badges');
const icons: Record<string, string> = {
  ...categoryAssets('icons'),
  mission: assetPath('icons', 'mission_scroll'), 'mission-complete': assetPath('badges', 'badge_star'),
  'supply-food': assetPath('icons', 'food'), 'rest-partner': assetPath('icons', 'partner_paw'),
  departure: assetPath('icons', 'flag'), grassland: assetPath('icons', 'food'),
  'snow-mountain': assetPath('icons', 'compass'), bridge: assetPath('icons', 'map'),
  'silent-partner': assetPath('icons', 'mission_scroll'), finish: assetPath('badges', 'badge_star'),
  comfort: assetPath('icons', 'leaf'), badge: assetPath('badges', 'badge_star'),
};
const routeScenes: Record<RouteId, string> = { easy: scenes.camp, normal: scenes.river, challenge: scenes.mountain };
const nodeScenes: Record<MapNodeId, string> = {
  departure: scenes.camp, grassland: scenes.supply, 'snow-mountain': scenes.mountain,
  bridge: scenes.river, 'silent-partner': scenes.sunset, finish: scenes.monument,
};
const missionScenes: Record<string, string> = { grassland: scenes.supply };
const badgeGallery = [
  { id: 'badge_star', label: '星星徽章' }, { id: 'badge_paw', label: '爪印徽章' },
  { id: 'badge_friendship', label: '友谊徽章' }, { id: 'badge_mountain', label: '山峰徽章' },
].map(item => ({ ...item, src: assetPath('badges', item.id) }));

/** 保留旧角色键；新调用统一按类别访问。 */
export const assetMap = {
  ...characters, characters, characterVisuals, identity, identityIllustrations, backgrounds, icons,
  scenes, routeScenes, nodeScenes, missionScenes, badgeGallery,
  badges: badgeAssets, stories: categoryAssets('stories'),
};

/** 只加载清单中确实存在的文件，不再使用人工暂停开关。 */
export const realAssetLoadingEnabled: boolean = availableAssets.length > 0;
export function resolveAssetUrl(path: string | undefined): string | undefined {
  return path && availableAssets.includes(path) ? path : undefined;
}

/** 可选图片 Prop 应省略，不传入显式 undefined，兼容严格类型检查。 */
export function assetProp<K extends 'icon' | 'avatar'>(key: K, path: string | undefined): Partial<Record<K, string>> {
  const url = resolveAssetUrl(path);
  return url ? { [key]: url } as Record<K, string> : {};
}

export function getAssetDiagnostics() {
  const registered = [...new Set([
    ...Object.values(characters), ...Object.values(identity), ...Object.values(backgrounds),
    ...Object.values(icons), ...Object.values(assetMap.badges), ...Object.values(assetMap.stories),
    ...Object.values(identityIllustrations), ...Object.values(scenes),
  ])];
  return {
    available: [...availableAssets],
    missing: registered.filter(path => !resolveAssetUrl(path)),
    unmapped: availableAssets.filter(path => !registered.includes(path)),
  };
}
