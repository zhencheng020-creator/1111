import { defineComponent, h } from 'vue';
import type { PropType } from 'vue';
import type { CardProps } from '../props.ts';

export default defineComponent({
  name: 'Card',
  props: {
    as: { type: String as PropType<'div' | 'button'>, default: 'div' },
    selected: { type: Boolean, default: false },
    onClick: Function as PropType<CardProps['onClick']>,
  },
  setup(props, { slots }) {
    return () => h(props.as, {
      class: ['zt-card', { 'zt-card--selected': props.selected }],
      ...(props.as === 'button' ? { type: 'button' } : {}),
      'data-figma': 'Card',
      'data-selected': props.selected,
      onClick: () => props.onClick?.(),
    }, slots.default?.());
  },
});
