import { defineComponent, h } from 'vue';
import type { PropType } from 'vue';
import { identities, partners, routes, missions } from '../../data/index.ts';
import { Button, Card, IdentityCard, PartnerCard, RouteCard, MissionCard, StatusBar, MapNode, Badge } from '../index.ts';

/** 开发者使用示例，未挂载到任何业务页面，也不写入 store。 */
export default defineComponent({
  name: 'ComponentExamples',
  props: { onAction: Function as PropType<(message: string) => void> },
  setup(props) {
    const identity = identities[0]!;
    const partner = partners[0]!;
    const route = routes[0]!;
    const mission = missions[0]!;
    return () => h('div', [
      h(Button, { text: '开始同行', variant: 'Primary', onClick: () => props.onAction?.('开始同行') }),
      h(Button, { text: '返回', variant: 'Secondary', onClick: () => props.onAction?.('返回') }),
      h(Button, { text: '暂不可用', variant: 'Disabled', disabled: true }),
      h(Card, {}, { default: () => h('span', '基础卡片内容') }),
      h(IdentityCard, {
        id: identity.id, name: identity.name, description: identity.ability,
        skill: identity.ability, selected: false,
        onSelect: id => props.onAction?.(`身份：${id}`),
      }),
      h(PartnerCard, {
        id: partner.id, name: partner.name, type: partner.type,
        energy: partner.energy, comfort: partner.comfort, trust: partner.trust,
        selected: false, onSelect: id => props.onAction?.(`伙伴：${id}`),
        // 提供真实素材后传入 avatar；此处不引用尚不存在的图片。
      }),
      h(RouteCard, {
        id: route.id, name: route.name,
        time: `${route.durationMinutes.min}–${route.durationMinutes.max}分钟`,
        difficulty: '难度待补充', description: '同行路线', selected: false,
        onSelect: id => props.onAction?.(`路线：${id}`),
      }),
      h(MissionCard, {
        title: mission.title, description: mission.description, choices: mission.choices,
        onChoice: choice => props.onAction?.(`方案：${choice.id}`),
      }),
      h(StatusBar, { label: '伙伴信任', value: partner.trust, max: 5 }),
      ...(['locked', 'current', 'complete', 'story'] as const).map(status => h(MapNode, {
        key: status, name: '节点示例', status,
        onClick: () => props.onAction?.(`节点：${status}`),
      })),
      // 仅为展示 Badge 的两种状态，不属于正式徽章目录。
      h(Badge, { name: '徽章示例', unlocked: false }),
      h(Badge, { name: '徽章示例', unlocked: true }),
    ]);
  },
});
