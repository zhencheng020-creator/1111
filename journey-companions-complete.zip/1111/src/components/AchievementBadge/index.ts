// 保留最初需求中的代码名称，对应同一个 Figma Badge 组件。
export { default } from '../Badge/index.ts';
