import { defineComponent, h } from 'vue';
import AssetImage from '../../assets/AssetImage.ts';

export default defineComponent({
  name: 'Badge',
  props: {
    name: { type: String, required: true },
    icon: String,
    unlocked: { type: Boolean, required: true },
  },
  setup(props) {
    return () => h('div', {
      class: ['zt-badge', { 'zt-badge--unlocked': props.unlocked }],
      'data-figma': 'Badge', 'data-unlocked': props.unlocked,
    }, [
      props.icon ? h(AssetImage, { src: props.icon, alt: '', class: 'zt-icon' }, {
        fallback: () => h('span', { class: 'zt-badge__icon-fallback', 'aria-hidden': 'true' }, '徽'),
      }) : null,
      h('span', { class: 'zt-badge__name' }, props.name),
      h('span', { class: 'zt-caption' }, props.unlocked ? '已解锁' : '未解锁'),
    ]);
  },
});
