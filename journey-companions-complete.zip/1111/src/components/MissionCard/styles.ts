/** 只负责 MissionCard 的展示，沿用现有 Design Token。 */
export const missionCardStyles = `
.zt-card.zt-mission-card {
  --mission-orange: var(--zt-journey-orange, #E86B2A);
  --mission-green: var(--zt-field-green, #739B56);
  --mission-blue: var(--zt-sky-blue, #5B8FB9);
  --mission-paper: var(--zt-paper, #F8EEDB);
  --mission-ink: var(--zt-ink, #3B2920);
  box-sizing: border-box;
  display: flex;
  flex-direction: column;
  gap: 20px;
  padding: 20px;
  border: 2px solid rgba(59, 41, 32, .16);
  border-radius: 20px;
  background: var(--mission-paper);
  color: var(--mission-ink);
  box-shadow: 0 3px 0 rgba(59, 41, 32, .06);
  border-top: 6px solid var(--mission-orange);
  animation: zt-card-in 360ms ease both;
}
.zt-mission-card__header { display: flex; align-items: center; gap: 14px; }
.zt-mission-card__icon {
  box-sizing: border-box;
  display: grid;
  place-items: center;
  flex-shrink: 0;
  width: 56px;
  height: 56px;
  border: 1px dashed var(--mission-blue);
  border-radius: 16px;
  background: rgba(91, 143, 185, .1);
  color: var(--mission-ink);
  font-size: 16px;
  font-weight: 700;
}
.zt-mission-card__heading { min-width: 0; display: flex; flex-direction: column; gap: 4px; }
.zt-mission-card__caption { font-size: 12px; line-height: 1.5; opacity: .7; }
.zt-mission-card .zt-mission-card__title {
  margin: 0;
  font-size: 24px;
  font-weight: 700;
  line-height: 1.4;
  color: var(--mission-ink);
  overflow-wrap: anywhere;
}
.zt-mission-card__description {
  position: relative;
  padding: 14px 16px;
  border-left: 3px solid var(--mission-blue);
  border-radius: 0 12px 12px 0;
  background: rgba(91, 143, 185, .06);
  font-size: 16px;
  line-height: 1.7;
  overflow-wrap: anywhere;
  padding-right: 108px;
}
.zt-mission-card__description-copy { position: relative; z-index: 1; }
.zt-mission-card__scene {
  position: absolute;
  z-index: 0;
  top: 50%;
  right: 10px;
  width: 88px;
  height: 72px;
  object-fit: cover;
  border-radius: 10px;
  opacity: .8;
  transform: translateY(-50%);
}
.zt-mission-card__actions { display: flex; flex-direction: column; gap: 12px; }
.zt-mission-card__actions-label { font-size: 16px; font-weight: 700; line-height: 1.5; }
.zt-mission-card .zt-mission__choices { display: grid; gap: 12px; counter-reset: mission-choice; }
.zt-mission-card .zt-mission-card__choice {
  box-sizing: border-box;
  position: relative;
  width: 100%;
  min-height: 68px;
  padding: 16px 44px 16px 64px;
  border: 2px solid rgba(115, 155, 86, .4);
  border-radius: 16px;
  background: var(--mission-paper);
  color: var(--mission-ink);
  font-family: inherit;
  font-size: 16px;
  font-weight: 700;
  line-height: 1.5;
  text-align: left;
  overflow-wrap: anywhere;
  cursor: pointer;
  touch-action: manipulation;
  -webkit-tap-highlight-color: transparent;
  counter-increment: mission-choice;
  transition: border-color 160ms ease, box-shadow 160ms ease, transform 160ms ease;
}
.zt-mission-card__choice::before {
  content: counter(mission-choice);
  box-sizing: border-box;
  position: absolute;
  top: 50%;
  left: 16px;
  display: grid;
  place-items: center;
  width: 32px;
  height: 32px;
  border: 1px dashed var(--mission-green);
  border-radius: 10px;
  background: rgba(115, 155, 86, .12);
  transform: translateY(-50%);
}
.zt-mission-card__choice::after {
  content: '→';
  position: absolute;
  top: 50%;
  right: 16px;
  transform: translateY(-50%);
  font-size: 20px;
}
.zt-mission-card .zt-mission-card__choice--selected {
  border-color: var(--mission-orange);
  background: rgba(232, 107, 42, .08);
  box-shadow: 0 3px 12px rgba(232, 107, 42, .1);
}
.zt-mission-card__choice--selected::before { border-color: var(--mission-orange); background: rgba(232, 107, 42, .12); }
.zt-mission-card__choice--selected::after { content: '✓'; }
.zt-mission-card__selection {
  padding-top: 16px;
  border-top: 1px solid rgba(59, 41, 32, .12);
  font-size: 16px;
  line-height: 1.6;
  overflow-wrap: anywhere;
}
.zt-mission-card__selection--chosen { font-weight: 700; }
@media (hover: hover) {
  .zt-mission-card .zt-mission-card__choice:hover { border-color: var(--mission-orange); transform: translateY(-2px); }
}
.zt-mission-card .zt-mission-card__choice:active { transform: scale(.985); box-shadow: none; }
.zt-mission-card .zt-mission-card__choice:focus-visible { outline: 3px solid var(--mission-green); outline-offset: 4px; }
@media (max-width: 359px) {
  .zt-card.zt-mission-card { padding: 16px; }
  .zt-mission-card__header { gap: 10px; }
  .zt-mission-card__icon { width: 48px; height: 48px; }
  .zt-mission-card__description { padding-right: 16px; }
  .zt-mission-card__scene { display: none; }
}
@media (prefers-reduced-motion: reduce) {
  .zt-mission-card .zt-mission-card__choice { transition: none; }
  .zt-mission-card .zt-mission-card__choice:hover,
  .zt-mission-card .zt-mission-card__choice:active { transform: none; }
}
`;
