import { defineComponent, h, onMounted } from 'vue';
import { injectStyle } from '../../platform/style.ts';
import type { PropType } from 'vue';
import type { MissionChoice } from '../../data/models.ts';
import Card from '../Card/index.ts';
import Button from '../Button/index.ts';
import type { MissionCardProps } from '../props.ts';
import { missionCardStyles } from './styles.ts';
import { assetMap, assetPath, resolveAssetUrl } from '../../assets/assetMap.ts';
import AssetImage from '../../assets/AssetImage.ts';

export default defineComponent({
  name: 'MissionCard',
  props: {
    title: { type: String, required: true },
    description: { type: String, required: true },
    choices: { type: Array as PropType<readonly MissionChoice[]>, required: true },
    // 可选展示 Prop，选中状态由页面提供；不在组件内执行选择或任务效果。
    selectedChoiceId: { type: String as PropType<string | null>, default: null },
    onChoice: Function as PropType<MissionCardProps['onChoice']>,
  },
  setup(props) {
    onMounted(() => {
      injectStyle('zt-mission-card-styles', missionCardStyles);
    });
    return () => {
      const selection = props.choices.find(choice => choice.id === props.selectedChoiceId);
      return h(Card, { class: 'zt-mission-card', 'data-figma': 'Card/Mission' }, { default: () => [
        h('div', { class: 'zt-mission-card__header' }, [
          h('span', {
            class: 'zt-mission-card__icon', 'aria-hidden': 'true',
            'data-asset-src': assetMap.icons.mission,
          }, [h(AssetImage, {
            src: resolveAssetUrl(assetMap.icons.mission) ?? '', alt: '',
            style: { width: '100%', height: '100%', objectFit: 'contain' },
          }, { fallback: () => '任务' })]),
          h('div', { class: 'zt-mission-card__heading' }, [
            h('span', { class: 'zt-mission-card__caption' }, '当前任务'),
            h('h2', { class: 'zt-card__title zt-mission-card__title' }, props.title),
          ]),
        ]),
        h('span', { class: 'zt-card__body zt-mission-card__description' }, [
          h('span', { class: 'zt-mission-card__description-copy' }, props.description),
          h(AssetImage, {
            src: resolveAssetUrl(assetMap.scenes.supply) ?? '', alt: '任务场景', class: 'zt-mission-card__scene',
          }),
        ]),
        h('div', { class: 'zt-mission-card__actions' }, [
          h('span', { class: 'zt-mission-card__actions-label' }, '选择你的行动'),
          h('div', { class: 'zt-mission__choices' }, props.choices.map(choice => h('div', {
            key: choice.id, style: { position: 'relative' },
          }, [h(Button, {
            text: choice.label,
            variant: choice.id === selection?.id ? 'Primary' : 'Secondary',
            class: ['zt-mission-card__choice', { 'zt-mission-card__choice--selected': choice.id === selection?.id }],
            'aria-pressed': choice.id === selection?.id,
            'data-choice-id': choice.id,
            'data-asset-src': assetMap.icons[choice.id] ?? assetPath('icons', choice.id),
            onClick: () => props.onChoice?.(choice),
          }), h(AssetImage, {
            src: resolveAssetUrl(assetMap.icons[choice.id] ?? assetPath('icons', choice.id)) ?? '', alt: '',
            'aria-hidden': 'true',
            style: {
              position: 'absolute', left: '16px', top: '50%', transform: 'translateY(-50%)',
              width: '32px', height: '32px', objectFit: 'contain', pointerEvents: 'none',
              background: 'var(--zt-paper, #F8EEDB)', borderRadius: '10px',
            },
          })]))),
        ]),
        h('div', {
          class: ['zt-mission-card__selection', { 'zt-mission-card__selection--chosen': !!selection }],
          role: 'status', 'aria-live': 'polite',
        }, selection ? `当前选择：${selection.label}` : '请选择一个行动。'),
      ] });
    };
  },
});
