import { defineComponent, h, onMounted } from 'vue';
import { injectStyle } from '../../platform/style.ts';
import type { PropType } from 'vue';
import Card from '../Card/index.ts';
import type { RouteCardProps } from '../props.ts';
import { routeCardStyles } from './styles.ts';
import { assetMap, resolveAssetUrl } from '../../assets/assetMap.ts';
import AssetImage from '../../assets/AssetImage.ts';
import type { RouteId } from '../../data/models.ts';

export default defineComponent({
  name: 'RouteCard',
  props: {
    id: { type: String, required: true },
    name: { type: String, required: true },
    time: { type: String, required: true },
    difficulty: { type: String, required: true },
    description: { type: String, required: true },
    selected: { type: Boolean, default: false },
    onSelect: Function as PropType<RouteCardProps['onSelect']>,
  },
  setup(props) {
    onMounted(() => {
      injectStyle('zt-route-card-styles', routeCardStyles);
    });
    return () => h(Card, {
      as: 'button', selected: props.selected,
      class: ['zt-route-card', { 'zt-route-card--selected': props.selected }],
      'data-figma': 'Card/Route',
      'aria-pressed': props.selected,
      onClick: () => props.onSelect?.(props.id),
    }, { default: () => [
      h('span', { class: 'zt-route-card__header' }, [
        h('span', { class: 'zt-card__title zt-route-card__name' }, props.name),
        h('span', { class: 'zt-route-card__check', 'aria-hidden': 'true' }, props.selected ? '✓' : ''),
      ]),
      h(AssetImage, {
        src: resolveAssetUrl(assetMap.routeScenes[props.id as RouteId]) ?? '',
        alt: `${props.name}路线场景`, class: 'zt-route-card__scene',
      }),
      h('span', { class: 'zt-route-card__meta' }, [
        h('span', { class: 'zt-route-card__field zt-route-card__field--time' }, [
          h('span', { class: 'zt-route-card__label' }, '时间'),
          h('span', { class: 'zt-card__caption zt-route-card__value' }, props.time || '待补充'),
        ]),
        h('span', { class: 'zt-route-card__field zt-route-card__field--difficulty' }, [
          h('span', { class: 'zt-route-card__label' }, '难度'),
          h('span', { class: 'zt-card__caption zt-route-card__value' }, props.difficulty || '待补充'),
        ]),
      ]),
      h('span', { class: 'zt-card__body zt-route-card__description' }, props.description || '路线介绍待补充。'),
      h('span', { class: 'zt-route-card__footer' }, [
        h('span', { class: 'zt-route-card__hint' }, '同行路线'),
        h('span', { class: 'zt-route-card__state' }, props.selected ? '已选择' : '点击选择'),
      ]),
    ] });
  },
});
