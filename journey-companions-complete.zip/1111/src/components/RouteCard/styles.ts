/** 仅作用于 RouteCard，复用现有 Design Token。 */
export const routeCardStyles = `
button.zt-card.zt-route-card {
  --route-orange: var(--zt-journey-orange, #E86B2A);
  --route-green: var(--zt-field-green, #739B56);
  --route-blue: var(--zt-sky-blue, #5B8FB9);
  --route-paper: var(--zt-paper, #F8EEDB);
  --route-ink: var(--zt-ink, #3B2920);
  box-sizing: border-box;
  display: flex;
  flex-direction: column;
  gap: 16px;
  width: 100%;
  padding: 20px;
  border: 2px solid rgba(59, 41, 32, .16);
  border-radius: 20px;
  background: var(--route-paper);
  color: var(--route-ink);
  font-family: inherit;
  text-align: left;
  cursor: pointer;
  touch-action: manipulation;
  -webkit-tap-highlight-color: transparent;
  box-shadow: 0 3px 0 rgba(59, 41, 32, .06);
  transition: border-color 180ms ease, box-shadow 180ms ease, transform 180ms ease;
  animation: zt-card-in 360ms ease both;
}
button.zt-card.zt-route-card--selected {
  border-color: var(--route-orange);
  box-shadow: 0 4px 16px rgba(232, 107, 42, .12);
}
.zt-route-card__header {
  display: flex;
  justify-content: space-between;
  align-items: start;
  gap: 16px;
}
.zt-route-card .zt-route-card__name {
  min-width: 0;
  color: var(--route-ink);
  font-size: 24px;
  font-weight: 700;
  line-height: 1.3;
  overflow-wrap: anywhere;
}
.zt-route-card__check {
  box-sizing: border-box;
  display: grid;
  place-items: center;
  flex-shrink: 0;
  width: 24px;
  height: 24px;
  border: 2px solid rgba(59, 41, 32, .25);
  border-radius: 50%;
  color: var(--route-ink);
  font-size: 16px;
  font-weight: 700;
  line-height: 1;
}
.zt-route-card--selected .zt-route-card__check {
  border-color: var(--route-orange);
  background: var(--route-orange);
}
.zt-route-card__meta {
  display: grid;
  grid-template-columns: repeat(2, minmax(0, 1fr));
  gap: 10px;
}
.zt-route-card__field {
  display: flex;
  flex-direction: column;
  gap: 4px;
  min-width: 0;
  padding: 10px 12px;
  border-radius: 12px;
  overflow-wrap: anywhere;
}
.zt-route-card__field--time { background: rgba(91, 143, 185, .1); }
.zt-route-card__field--difficulty { background: rgba(115, 155, 86, .12); }
.zt-route-card__label { font-size: 12px; line-height: 1.5; opacity: .75; }
.zt-route-card__value { font-size: 16px; line-height: 1.5; font-weight: 700; }
.zt-route-card__description { font-size: 16px; line-height: 1.6; }
.zt-route-card__scene {
  display: block;
  width: 100%;
  height: 142px;
  border-radius: 14px;
  object-fit: cover;
  border: 1px solid rgba(59, 41, 32, .12);
}
.zt-route-card__footer {
  display: flex;
  justify-content: space-between;
  align-items: center;
  gap: 12px;
  padding-top: 12px;
  border-top: 1px solid rgba(59, 41, 32, .12);
  font-size: 12px;
  line-height: 1.5;
}
.zt-route-card__hint { opacity: .65; }
.zt-route-card__state { font-weight: 700; white-space: nowrap; }
@media (hover: hover) {
  button.zt-card.zt-route-card:hover {
    border-color: var(--route-orange);
    transform: translateY(-2px);
  }
}
button.zt-card.zt-route-card:active { transform: scale(.985); box-shadow: none; }
button.zt-card.zt-route-card:focus-visible {
  outline: 3px solid var(--route-green);
  outline-offset: 4px;
}
@media (max-width: 359px) {
  button.zt-card.zt-route-card { padding: 16px; }
  .zt-route-card__field { padding-inline: 8px; }
}
@media (prefers-reduced-motion: reduce) {
  button.zt-card.zt-route-card { transition: none; }
  button.zt-card.zt-route-card:hover,
  button.zt-card.zt-route-card:active { transform: none; }
}
`;
