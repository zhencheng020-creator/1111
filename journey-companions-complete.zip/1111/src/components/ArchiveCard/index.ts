import { defineComponent, h, onMounted } from 'vue';
import { injectStyle } from '../../platform/style.ts';
import Card from '../Card/index.ts';
import { archiveCardStyles } from './styles.ts';
import { assetDirectories } from '../../assets/assetMap.ts';

/** 仅接收页面解析后的展示 Props 和记录插槽；不访问或更新 store。 */
export default defineComponent({
  name: 'ArchiveCard',
  props: {
    identityName: { type: String, required: true },
    identityAbility: { type: String, default: '' },
    partnerName: { type: String, required: true },
    partnerType: { type: String, default: '' },
    routeName: { type: String, required: true },
    routeTime: { type: String, default: '' },
    nodeCount: { type: Number, default: 0 },
    missionCount: { type: Number, default: 0 },
    storyCount: { type: Number, default: 0 },
    badgeCount: { type: Number, default: 0 },
    isComplete: { type: Boolean, default: false },
  },
  setup(props, { slots }) {
    onMounted(() => {
      injectStyle('zt-archive-card-styles', archiveCardStyles);
    });
    return () => h(Card, {
      class: ['zt-archive-card', { 'zt-archive-card--complete': props.isComplete }],
      'data-figma': 'Card/Archive', 'data-complete': props.isComplete,
      'data-badges-path': `${assetDirectories.badges}*.png`,
    }, { default: () => [
      h('header', { class: 'zt-archive-card__hero' }, [
        h('div', { class: 'zt-archive-card__heading' }, [
          h('span', { class: 'zt-archive-card__eyebrow' }, '征途生灵 · 同行计划'),
          h('h2', { class: 'zt-archive-card__title' }, props.isComplete ? '同行纪念档案' : '同行档案预览'),
          h('p', { class: 'zt-archive-card__subtitle' }, props.isComplete ? '留存这一程的陪伴。' : '记录正在发生的同行。'),
        ]),
        h('span', { class: 'zt-archive-card__seal', 'aria-hidden': 'true' }, '同行'),
      ]),
      h('div', { class: 'zt-archive-card__companions' }, [
        h('section', { class: 'zt-archive-card__identity', 'data-archive-section': 'identity' }, [
          h('h3', { class: 'zt-archive-card__label' }, '同行身份'),
          h('p', { class: 'zt-archive-card__name' }, props.identityName),
          props.identityAbility ? h('span', { class: 'zt-archive-card__caption' }, props.identityAbility) : null,
        ]),
        h('section', { class: 'zt-archive-card__partner', 'data-archive-section': 'partner' }, [
          h('h3', { class: 'zt-archive-card__label' }, '伙伴信息'),
          h('p', { class: 'zt-archive-card__name' }, props.partnerName),
          props.partnerType ? h('span', { class: 'zt-archive-card__type' }, props.partnerType) : null,
        ]),
      ]),
      h('section', { class: 'zt-archive-card__route', 'data-archive-section': 'route' }, [
        h('h3', { class: 'zt-archive-card__label' }, '路线回顾'),
        h('p', { class: 'zt-archive-card__name' }, props.routeName),
        h('div', { class: 'zt-archive-card__route-meta' }, [
          props.routeTime ? h('span', `预计时长 ${props.routeTime}`) : null,
          h('span', `${props.nodeCount} 个同行节点`),
        ]),
      ]),
      ...([
        { key: 'missions', title: '任务记录', count: props.missionCount, empty: '暂无完成任务' },
        { key: 'stories', title: '故事收集', count: props.storyCount, empty: '暂无解锁故事' },
        { key: 'badges', title: '同行徽章', count: props.badgeCount, empty: '暂无徽章' },
      ] as const).map(section => h('details', {
        key: section.key, open: true,
        class: ['zt-archive-card__records', `zt-archive-card__records--${section.key}`],
        'data-archive-section': section.key,
      }, [
        h('summary', { class: 'zt-archive-card__summary' }, [
          h('h3', section.title),
          h('span', { class: 'zt-archive-card__count' }, String(section.count)),
        ]),
        h('div', { class: 'zt-archive-card__content' }, slots[section.key]?.() ?? [
          h('p', { class: 'zt-archive-card__empty' }, section.empty),
        ]),
      ])),
      h('p', { class: 'zt-archive-card__closing' }, props.isComplete ? '这一程，因同行而留下记忆。' : '同行记录会随你的探索持续更新。'),
    ] });
  },
});
