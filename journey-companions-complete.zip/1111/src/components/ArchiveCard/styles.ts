/** ArchiveCard 及其内容插槽的局部展示样式。 */
export const archiveCardStyles = `
.zt-card.zt-archive-card {
  --archive-orange: var(--zt-journey-orange, #E86B2A);
  --archive-green: var(--zt-field-green, #739B56);
  --archive-blue: var(--zt-sky-blue, #5B8FB9);
  --archive-paper: var(--zt-paper, #F8EEDB);
  --archive-ink: var(--zt-ink, #3B2920);
  box-sizing: border-box;
  display: flex;
  flex-direction: column;
  gap: 20px;
  padding: 24px;
  border: 2px solid rgba(59, 41, 32, .2);
  border-top: 5px solid var(--archive-orange);
  border-radius: 20px;
  background: var(--archive-paper);
  color: var(--archive-ink);
  box-shadow: 0 4px 0 rgba(59, 41, 32, .08), 0 12px 28px rgba(59, 41, 32, .06);
  animation: zt-card-in 420ms ease both;
}
.zt-archive-card__hero {
  display: grid;
  grid-template-columns: minmax(0, 1fr) 64px;
  align-items: center;
  gap: 16px;
  padding-bottom: 20px;
  border-bottom: 1px solid rgba(59, 41, 32, .2);
}
.zt-archive-card__heading { min-width: 0; }
.zt-archive-card__eyebrow { font-size: 12px; line-height: 1.5; letter-spacing: .06em; }
.zt-archive-card .zt-archive-card__title {
  margin: 8px 0;
  color: var(--archive-ink);
  font-size: 24px;
  font-weight: 700;
  line-height: 1.4;
  overflow-wrap: anywhere;
}
.zt-archive-card__subtitle { margin: 0; font-size: 12px; line-height: 1.6; opacity: .75; }
.zt-archive-card__seal {
  box-sizing: border-box;
  display: grid;
  place-items: center;
  width: 64px;
  height: 64px;
  border: 2px solid var(--archive-blue);
  border-radius: 50%;
  outline: 1px solid rgba(91, 143, 185, .4);
  outline-offset: 4px;
  background: rgba(91, 143, 185, .08);
  font-size: 20px;
  font-weight: 700;
}
.zt-archive-card--complete .zt-archive-card__seal {
  border-color: var(--archive-orange);
  outline-color: rgba(232, 107, 42, .4);
  background: rgba(232, 107, 42, .08);
}
.zt-archive-card__companions { display: grid; grid-template-columns: repeat(2, minmax(0, 1fr)); gap: 12px; }
.zt-archive-card__identity,
.zt-archive-card__partner {
  min-width: 0;
  padding: 14px 12px;
  border: 1px solid rgba(59, 41, 32, .12);
  border-radius: 14px;
}
.zt-archive-card__identity { background: rgba(232, 107, 42, .06); }
.zt-archive-card__partner { background: rgba(115, 155, 86, .1); }
.zt-archive-card__label { margin: 0 0 8px; font-size: 12px; line-height: 1.5; font-weight: 700; }
.zt-archive-card__name { margin: 0 0 8px; font-size: 24px; line-height: 1.4; font-weight: 700; overflow-wrap: anywhere; }
.zt-archive-card__caption { font-size: 12px; line-height: 1.6; }
.zt-archive-card__type {
  display: inline-block;
  padding: 3px 8px;
  border: 1px solid rgba(115, 155, 86, .4);
  border-radius: 6px;
  font-size: 12px;
  line-height: 1.5;
}
.zt-archive-card__route {
  padding: 16px;
  border: 1px solid rgba(91, 143, 185, .4);
  border-radius: 14px;
  background: rgba(91, 143, 185, .08);
}
.zt-archive-card__route-meta { display: flex; flex-wrap: wrap; gap: 8px 16px; font-size: 12px; line-height: 1.6; }
.zt-archive-card__records { min-width: 0; border: 1px solid rgba(59, 41, 32, .16); border-radius: 14px; }
.zt-archive-card__summary {
  display: flex;
  align-items: center;
  gap: 10px;
  min-height: 48px;
  padding: 12px 14px;
  border-radius: 14px;
  list-style: none;
  cursor: pointer;
  touch-action: manipulation;
  -webkit-tap-highlight-color: transparent;
  transition: background-color 160ms ease, transform 160ms ease;
}
.zt-archive-card__summary::-webkit-details-marker { display: none; }
.zt-archive-card__summary h3 { flex: 1; min-width: 0; margin: 0; font-size: 16px; line-height: 1.5; }
.zt-archive-card__summary::after { content: '⌄'; flex-shrink: 0; font-size: 20px; font-weight: 700; }
.zt-archive-card__records[open] > .zt-archive-card__summary { border-bottom: 1px solid rgba(59, 41, 32, .12); border-radius: 14px 14px 0 0; }
.zt-archive-card__records[open] > .zt-archive-card__summary::after { transform: rotate(180deg); }
.zt-archive-card__count {
  display: grid;
  place-items: center;
  min-width: 28px;
  min-height: 28px;
  padding-inline: 4px;
  border-radius: 8px;
  background: rgba(232, 107, 42, .1);
  font-size: 12px;
  font-weight: 700;
  font-variant-numeric: tabular-nums;
}
.zt-archive-card__records--stories .zt-archive-card__count { background: rgba(91, 143, 185, .12); }
.zt-archive-card__records--badges .zt-archive-card__count { background: rgba(115, 155, 86, .12); }
.zt-archive-card__content { padding: 16px 14px; font-size: 16px; line-height: 1.6; overflow-wrap: anywhere; }
.zt-archive-card__content ul { margin: 0; padding-left: 20px; }
.zt-archive-card__content li + li { margin-top: 10px; }
.zt-archive-card__content article + article { padding-top: 16px; margin-top: 16px; border-top: 1px solid rgba(59, 41, 32, .12); }
.zt-archive-card__content article h3 { margin: 0 0 10px; font-size: 16px; }
.zt-archive-card__content article p { margin: 8px 0 0; }
.zt-archive-card__visual { margin: 0; padding: 10px 0; }
.zt-archive-card__visual + .zt-archive-card__visual { border-top: 1px solid rgba(59, 41, 32, .12); }
.zt-archive-card__visual img { display: block; width: 100%; max-height: 150px; object-fit: contain; border-radius: 10px; }
.zt-archive-card__visual figcaption { margin-top: 6px; font-size: 12px; opacity: .7; }
.zt-archive-card__empty {
  margin: 0;
  padding: 14px;
  border: 1px dashed rgba(59, 41, 32, .25);
  border-radius: 10px;
  font-size: 12px;
  line-height: 1.6;
}
.zt-archive-card__badge-placeholder {
  display: grid;
  place-items: center;
  width: 48px;
  height: 48px;
  margin-bottom: 10px;
  border: 1px dashed var(--archive-green);
  border-radius: 14px;
  background: rgba(115, 155, 86, .1);
  font-size: 20px;
  font-weight: 700;
}
.zt-archive-card__badge + .zt-archive-card__badge { margin-top: 16px; }
.zt-archive-card .zt-badge__name { font-weight: 700; }
.zt-archive-card .zt-badge .zt-caption { margin-top: 4px; }
.zt-archive-card__closing { margin: 0; padding-top: 16px; border-top: 1px solid rgba(59, 41, 32, .2); text-align: center; font-size: 12px; line-height: 1.6; }
@media (hover: hover) {
  .zt-archive-card__summary:hover { background: rgba(232, 107, 42, .06); }
}
.zt-archive-card__summary:active { background: rgba(232, 107, 42, .1); transform: scale(.985); }
.zt-archive-card__summary:focus-visible { outline: 3px solid var(--archive-green); outline-offset: 4px; }
@media (max-width: 359px) {
  .zt-card.zt-archive-card { padding: 16px; }
  .zt-archive-card__hero { grid-template-columns: minmax(0, 1fr) 56px; gap: 12px; }
  .zt-archive-card__seal { width: 56px; height: 56px; }
}
@media (prefers-reduced-motion: reduce) {
  .zt-archive-card__summary { transition: none; }
  .zt-archive-card__summary:active { transform: none; }
}
`;
