import { defineComponent, h } from 'vue';
import type { PropType } from 'vue';
import type { ButtonProps, ButtonVariant } from '../props.ts';

export default defineComponent({
  name: 'Button',
  props: {
    text: { type: String, required: true },
    variant: { type: String as PropType<ButtonVariant>, default: 'Primary' },
    disabled: { type: Boolean, default: false },
    onClick: Function as PropType<ButtonProps['onClick']>,
  },
  setup(props) {
    return () => {
      const disabled = props.disabled || props.variant === 'Disabled';
      const variant = disabled ? 'Disabled' : props.variant;
      return h('button', {
        type: 'button',
        class: ['zt-button', `zt-button--${variant.toLowerCase()}`],
        disabled,
        'data-figma': 'Button',
        'data-variant': variant,
        onClick: () => { if (!props.disabled && props.variant !== 'Disabled') props.onClick?.(); },
      }, props.text);
    };
  },
});
