import type { MapNodeStatus, MissionChoice } from '../data/models.ts';

/** 图标及头像为已有素材 URL；未提供时不生成替代图片。 */
export type AssetUrl = string;
export type ButtonVariant = 'Primary' | 'Secondary' | 'Disabled';

export interface ButtonProps {
  text: string;
  variant?: ButtonVariant;
  disabled?: boolean;
  onClick?: () => void;
}

export interface CardProps {
  as?: 'div' | 'button';
  selected?: boolean;
  onClick?: () => void;
}

export interface IdentityCardProps {
  id: string;
  name: string;
  description: string;
  skill: string;
  icon?: AssetUrl;
  selected?: boolean;
  onSelect?: (id: string) => void;
}

export interface PartnerCardProps {
  id: string;
  name: string;
  type: string;
  avatar?: AssetUrl;
  energy: number;
  comfort: number;
  trust: number;
  selected?: boolean;
  onSelect?: (id: string) => void;
}

export interface RouteCardProps {
  id: string;
  name: string;
  time: string;
  difficulty: string;
  description: string;
  selected?: boolean;
  onSelect?: (id: string) => void;
}

export interface MissionCardProps {
  title: string;
  description: string;
  choices: readonly MissionChoice[];
  onChoice?: (choice: MissionChoice) => void;
}

export interface StatusBarProps {
  label: string;
  value: number;
  max: number;
  icon?: AssetUrl;
}

export interface MapNodeProps {
  name: string;
  status: MapNodeStatus;
  icon?: AssetUrl;
  onClick?: () => void;
}

export interface BadgeProps {
  name: string;
  icon?: AssetUrl;
  unlocked: boolean;
}
