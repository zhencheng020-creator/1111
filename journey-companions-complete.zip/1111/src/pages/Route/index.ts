import type { PageDefinition } from '../../router/types.ts';

export default Object.freeze({
  name: 'Route',
  title: '选择同行路线',
  description: '选择轻体验线、标准探索线或伙伴挑战线。',
} satisfies PageDefinition);
