import { h, ref } from 'vue';
import type { VNodeChild } from 'vue';
import { assetMap, resolveAssetUrl } from '../assets/assetMap.ts';
import AssetImage from '../assets/AssetImage.ts';
import { routes } from '../router/routes.ts';
import type { PageName } from '../router/types.ts';

export function pageFrame(name: PageName, children: VNodeChild[]) {
  const background = resolveAssetUrl(assetMap.backgrounds[name]);
  return h('section', { class: 'zt-page', 'data-page': name, 'data-background-src': assetMap.backgrounds[name] }, [
    background ? h(AssetImage, { src: background, alt: '', class: 'zt-page__background' }) : null,
    h('h1', { class: 'zt-page__title' }, routes[name].page.title),
    ...children,
  ]);
}

export function usePageFeedback() {
  const feedback = ref('');
  function run(action: () => void): boolean {
    feedback.value = '';
    try { action(); return true; }
    catch (error) { feedback.value = error instanceof Error ? error.message : '操作未完成，请重试。'; return false; }
  }
  return { feedback, run };
}

export function feedbackMessage(message: string) {
  return message ? h('p', { role: 'alert' }, message) : null;
}

export function detailList(items: readonly (readonly [string, string | number])[]) {
  return h('dl', items.flatMap(([label, value]) => [h('dt', label), h('dd', String(value))]));
}
