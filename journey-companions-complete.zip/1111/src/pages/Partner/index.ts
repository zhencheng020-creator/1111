import type { PageDefinition } from '../../router/types.ts';

export default Object.freeze({
  name: 'Partner',
  title: '选择动物伙伴',
  description: '选择小卫、赤风、飞羽、小驮或阿牛。',
} satisfies PageDefinition);
