import { defineComponent, h, onMounted } from 'vue';
import { injectStyle } from '../../platform/style.ts';
import { storeToRefs } from 'pinia';
import { useRouter } from 'vue-router';
import { partners } from '../../data/index.ts';
import { Button, PartnerCard } from '../../components/index.ts';
import { usePartnerStore, useUserStore } from '../../store/index.ts';
import { assetMap, assetProp } from '../../assets/assetMap.ts';
import { feedbackMessage, pageFrame, usePageFeedback } from '../shared.ts';

// 页面样式仅限定 Partner，保持原有 pageFrame 和路由按钮结构。
const partnerPageStyles = `
.zt-page[data-page="Partner"] {
  box-sizing: border-box;
  width: 100%;
  max-width: 480px;
  margin: 0 auto;
  padding: 28px 20px max(28px, env(safe-area-inset-bottom));
  background: #F8EEDB;
  color: #3B2920;
}
.zt-page[data-page="Partner"] > .zt-page__title {
  margin: 0 0 24px;
  padding-left: 14px;
  border-left: 4px solid #E86B2A;
  font-size: 32px;
  line-height: 1.3;
}
.zt-page[data-page="Partner"] > .zt-page__choices {
  display: grid;
  gap: 16px;
  margin: 0 0 24px;
}
.zt-page[data-page="Partner"] > .zt-button {
  box-sizing: border-box;
  width: 100%;
  min-height: 48px;
  padding: 12px 16px;
  border: 2px solid #E86B2A;
  border-radius: 14px;
  font-weight: 700;
  font-size: 20px;
  line-height: 1.5;
  touch-action: manipulation;
}
.zt-page[data-page="Partner"] > .zt-button--secondary {
  margin-bottom: 12px;
  border-color: #739B56;
  background: #F8EEDB;
  color: #3B2920;
}
.zt-page[data-page="Partner"] > .zt-button--primary {
  background: #E86B2A;
  color: #3B2920;
}
.zt-page[data-page="Partner"] > .zt-button--disabled {
  border-color: rgba(59, 41, 32, .16);
  background: rgba(59, 41, 32, .06);
  color: #3B2920;
  opacity: .55;
}
.zt-page[data-page="Partner"] > .zt-button:focus-visible {
  outline: 3px solid #739B56;
  outline-offset: 4px;
}
.zt-page[data-page="Partner"] > .zt-button:active:not(:disabled) {
  filter: brightness(.95);
}
.zt-page[data-page="Partner"] > [role="alert"] {
  margin: 0 0 16px;
  color: #3B2920;
  line-height: 1.5;
}
@media (max-width: 359px) {
  .zt-page[data-page="Partner"] { padding-inline: 12px; }
}
`;

export default defineComponent({
  name: 'PartnerPage',
  setup() {
    const user = useUserStore();
    const { partner } = storeToRefs(usePartnerStore());
    const router = useRouter();
    const { feedback, run } = usePageFeedback();
    onMounted(() => {
      injectStyle('zt-partner-page-styles', partnerPageStyles);
    });
    function onSelect(id: string): void {
      const item = partners.find(item => item.id === id);
      if (item) run(() => user.selectPartner(item.id));
    }
    return () => pageFrame('Partner', [
      h('ul', { class: 'zt-page__choices' }, partners.map(item => {
        const status = partner.value?.id === item.id ? partner.value : item;
        const visual = assetMap.characterVisuals[item.id];
        const conditionAsset = status.trust < 2 ? visual?.hurt : status.energy < 3 || status.comfort < 5 ? visual?.rest : visual?.avatar;
        return h('li', { key: item.id }, [h(PartnerCard, {
          id: item.id, name: item.name, type: item.type,
          ...assetProp('avatar', conditionAsset ?? assetMap.characters[item.id]),
          energy: status.energy, comfort: status.comfort, trust: status.trust,
          selected: partner.value?.id === item.id, onSelect,
        })]);
      })),
      feedbackMessage(feedback.value),
      h(Button, { text: '返回身份选择', variant: 'Secondary', onClick: () => { void router.push({ name: 'Identity' }); } }),
      h(Button, { text: '下一步', disabled: partner.value === null, onClick: () => { void router.push({ name: 'Route' }); } }),
    ]);
  },
});
