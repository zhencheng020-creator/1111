import type { PageDefinition } from '../../router/types.ts';

export default Object.freeze({
  name: 'Identity',
  title: '选择同行身份',
  description: '选择后勤员、侦察员、医护员或记录员。',
} satisfies PageDefinition);
