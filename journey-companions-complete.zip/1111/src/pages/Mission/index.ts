import type { PageDefinition } from '../../router/types.ts';

export default Object.freeze({
  name: 'Mission',
  title: '同行任务',
  description: '根据路由中的 missionId 展示对应任务；任务交互在后续步骤实现。',
} satisfies PageDefinition);
