import type { PageDefinition } from '../../router/types.ts';

export default Object.freeze({
  name: 'Map',
  title: '探索地图',
  description: '查看六个同行节点，进入任务、伙伴状态或同行档案。',
} satisfies PageDefinition);
