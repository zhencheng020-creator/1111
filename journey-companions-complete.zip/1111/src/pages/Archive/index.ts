import type { PageDefinition } from '../../router/types.ts';

export default Object.freeze({
  name: 'Archive',
  title: '同行档案',
  description: '展示身份、伙伴、路线、任务、故事与徽章的最终纪念档案。',
} satisfies PageDefinition);
