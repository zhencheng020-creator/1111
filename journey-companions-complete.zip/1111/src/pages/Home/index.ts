import type { PageDefinition } from '../../router/types.ts';

export default Object.freeze({
  name: 'Home',
  title: '征途生灵·同行计划',
  description: '活动入口，开始同行后进入身份选择。',
} satisfies PageDefinition);
