import { defineComponent, h } from 'vue';
import { storeToRefs } from 'pinia';
import { useRouter } from 'vue-router';
import { Badge, Button, Card } from '../../components/index.ts';
import { useResourceStore, usePartnerStore } from '../../store/index.ts';
import { badges } from '../../data/index.ts';
import { assetMap, assetProp, catalogAssetPath, resolveAssetUrl } from '../../assets/assetMap.ts';
import AssetImage from '../../assets/AssetImage.ts';
import { detailList, pageFrame } from '../shared.ts';

export default defineComponent({
  name: 'StatusPage',
  setup() {
    const resources = useResourceStore();
    const { energy, food, medical, badge, earnedBadgeIds } = storeToRefs(resources);
    const { partner, needsCare } = storeToRefs(usePartnerStore());
    const router = useRouter();
    const icon = (path: string, alt: string) => h(AssetImage, {
      src: resolveAssetUrl(path) ?? '', alt, class: 'zt-status-asset-icon',
    });
    return () => pageFrame('Status', [
      h(Card, {}, { default: () => [h('h2', '人物与团队'), detailList([
        ['人物体力', energy.value], ['粮食', food.value], ['医疗资源', medical.value], ['徽章数量', badge.value],
      ]), h('div', { class: 'zt-status-asset-strip', 'aria-label': '团队资源图标' }, [
        icon(assetMap.icons.energy ?? '', '人物体力'), icon(assetMap.icons.food ?? '', '粮食'),
        icon(assetMap.icons.medical ?? '', '医疗资源'), icon(assetMap.icons.badge ?? '', '徽章'),
      ])] }),
      partner.value ? h(Card, {}, { default: () => [
        h('h2', partner.value!.name),
        h(AssetImage, { src: resolveAssetUrl(assetMap.characters[partner.value!.id]) ?? '', alt: partner.value!.name }),
        detailList([['伙伴体力', partner.value!.energy], ['舒适度', partner.value!.comfort], ['信任', partner.value!.trust]]),
        h('div', { class: 'zt-status-asset-strip', 'aria-label': '伙伴状态图标' }, [
          icon(assetMap.icons.energy ?? '', '伙伴体力'), icon(assetMap.icons.comfort ?? '', '舒适度'), icon(assetMap.icons.trust ?? '', '信任'),
        ]),
        needsCare.value ? h('p', { role: 'status' }, '伙伴需要照顾。') : null,
      ] }) : null,
      ...earnedBadgeIds.value.map(id => {
        const definition = badges.find(item => item.id === id);
        return definition ? h(Badge, { key: id, name: definition.name,
          ...assetProp('icon', assetMap.badges[id] ?? catalogAssetPath(definition.assetPath)), unlocked: true }) : null;
      }),
      h(Button, { text: '返回地图', variant: 'Secondary', onClick: () => { void router.push({ name: 'Map' }); } }),
    ]);
  },
});
