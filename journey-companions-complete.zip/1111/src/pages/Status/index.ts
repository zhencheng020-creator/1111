import type { PageDefinition } from '../../router/types.ts';

export default Object.freeze({
  name: 'Status',
  title: '同行状态',
  description: '查看人物体力、团队资源、伙伴状态与徽章。',
} satisfies PageDefinition);
