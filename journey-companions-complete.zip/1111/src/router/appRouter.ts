import { createRouter, createWebHashHistory } from 'vue-router';
import type { RouterHistory } from 'vue-router';
import type { Pinia } from 'pinia';
import { routes } from './routes.ts';
import type { PageName } from './types.ts';
import { useUserStore } from '../store/index.ts';
import Home from '../pages/Home/View.ts';
import Identity from '../pages/Identity/View.ts';
import Partner from '../pages/Partner/View.ts';
import Route from '../pages/Route/View.ts';
import Map from '../pages/Map/View.ts';
import Mission from '../pages/Mission/View.ts';
import Status from '../pages/Status/View.ts';
import Archive from '../pages/Archive/View.ts';

const views = { Home, Identity, Partner, Route, Map, Mission, Status, Archive };

/** 保留原路由路径与元信息，为浏览器原型添加 Vue Router 运行时。 */
export function createAppRouter(pinia: Pinia, history: RouterHistory = createWebHashHistory()) {
  const router = createRouter({
    history,
    routes: [
      { path: '/', redirect: { name: 'Home' } },
      ...Object.values(routes).map(route => ({ path: route.path, name: route.name, component: views[route.name], meta: { title: route.page.title } })),
      { path: '/:pathMatch(.*)*', redirect: { name: 'Home' } },
    ],
  });
  const user = useUserStore(pinia);
  router.beforeEach(to => {
    const name = to.name as PageName;
    if (name === 'Home' || name === 'Identity') return true;
    if (!user.identity) return { name: 'Identity' };
    if (name === 'Partner') return true;
    if (!user.partner) return { name: 'Partner' };
    if (name === 'Route') return true;
    if (!user.route) return { name: 'Route' };
    return true;
  });
  return router;
}
