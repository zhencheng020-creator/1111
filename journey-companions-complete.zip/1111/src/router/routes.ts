import Home from '../pages/Home/index.ts';
import Identity from '../pages/Identity/index.ts';
import Partner from '../pages/Partner/index.ts';
import Route from '../pages/Route/index.ts';
import Map from '../pages/Map/index.ts';
import Mission from '../pages/Mission/index.ts';
import Status from '../pages/Status/index.ts';
import Archive from '../pages/Archive/index.ts';
import type { PageName, ResolvedRoute, RouteDefinition, RouteTarget } from './types.ts';

/** 唯一页面注册表；页面入口与路径在此关联。 */
export const routes: Readonly<Record<PageName, RouteDefinition>> = Object.freeze({
  Home: Object.freeze({ name: 'Home', path: '/home', page: Home }),
  Identity: Object.freeze({ name: 'Identity', path: '/identity', page: Identity }),
  Partner: Object.freeze({ name: 'Partner', path: '/partner', page: Partner }),
  Route: Object.freeze({ name: 'Route', path: '/route', page: Route }),
  Map: Object.freeze({ name: 'Map', path: '/map', page: Map }),
  Mission: Object.freeze({ name: 'Mission', path: '/mission/:missionId', page: Mission }),
  Status: Object.freeze({ name: 'Status', path: '/status', page: Status }),
  Archive: Object.freeze({ name: 'Archive', path: '/archive', page: Archive }),
});

export class InvalidRouteError extends Error {
  constructor(message: string) {
    super(message);
    this.name = 'InvalidRouteError';
  }
}

/** 根据类型安全的目标生成路径；任务 ID 作为单个路径段编码。 */
export function buildPath(target: RouteTarget): string {
  if (!Object.hasOwn(routes, target.name)) throw new InvalidRouteError('未知页面');
  if (target.name === 'Mission') {
    const id = target.params?.missionId;
    if (typeof id !== 'string' || !id.trim()) throw new InvalidRouteError('任务页面需要非空 missionId');
    try {
      return `/mission/${encodeURIComponent(id)}`;
    } catch {
      throw new InvalidRouteError('任务 ID 无法编码');
    }
  }
  return routes[target.name].path;
}

/** 只接受应用内路径，不隐式跳转到外部 URL 或未知页面。 */
export function resolveRoute(path: string): ResolvedRoute {
  const normalized = path.replace(/\/+$/, '') || '/';
  if (normalized === '/') return Object.freeze({ name: 'Home', path: routes.Home.path });

  for (const definition of Object.values(routes)) {
    if (definition.name !== 'Mission' && definition.path === normalized) {
      return Object.freeze({ name: definition.name, path: definition.path });
    }
  }

  const missionMatch = /^\/mission\/([^/?#]+)$/.exec(normalized);
  if (missionMatch?.[1]) {
    let missionId: string;
    try {
      missionId = decodeURIComponent(missionMatch[1]);
    } catch {
      throw new InvalidRouteError('任务 ID 编码无效');
    }
    const target = { name: 'Mission', params: Object.freeze({ missionId }) } as const;
    return Object.freeze({ ...target, path: buildPath(target) });
  }
  throw new InvalidRouteError(`未知或不完整的页面路径：${path}`);
}
