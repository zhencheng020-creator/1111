import { buildPath, resolveRoute, routes } from './routes.ts';
import type { PageLocation, PageRouter, RouteTarget } from './types.ts';

function createLocation(destination: string | RouteTarget): PageLocation {
  const route = resolveRoute(typeof destination === 'string' ? destination : buildPath(destination));
  return Object.freeze({ route, page: routes[route.name].page });
}

/**
 * 框架无关的内存导航栈，实际解析路径并加载对应页面入口。
 * 不依赖浏览器、微信 API 或业务 store；平台适配与 UI 绑定尚未实现。
 */
export function createPageRouter(initialDestination: string | RouteTarget = '/'): PageRouter {
  const stack: PageLocation[] = [createLocation(initialDestination)];
  const current = (): PageLocation => stack[stack.length - 1]!;

  return {
    get current() { return current(); },
    get history() { return Object.freeze([...stack]); },
    navigateTo(destination) {
      // 先解析，错误目标不会修改已有历史。
      const location = createLocation(destination);
      stack.push(location);
      return location;
    },
    redirectTo(destination) {
      const location = createLocation(destination);
      stack[stack.length - 1] = location;
      return location;
    },
    navigateBack(delta = 1) {
      if (!Number.isInteger(delta) || delta < 1) throw new RangeError('返回层数必须是正整数');
      // 在根页面返回不退出，越界返回停留在根页面。
      stack.splice(Math.max(1, stack.length - delta));
      return current();
    },
  };
}
