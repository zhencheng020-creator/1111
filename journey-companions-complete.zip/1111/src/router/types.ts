export type PageName = 'Home' | 'Identity' | 'Partner' | 'Route' | 'Map' | 'Mission' | 'Status' | 'Archive';

/** 仅定义页面入口，不包含 UI、用户状态或任务交互。 */
export interface PageDefinition {
  readonly name: PageName;
  readonly title: string;
  readonly description: string;
}

/** Mission 必须携带任务 ID，其余页面无需参数。 */
export type RouteTarget =
  | Readonly<{ name: Exclude<PageName, 'Mission'> }>
  | Readonly<{ name: 'Mission'; params: Readonly<{ missionId: string }> }>;

export type ResolvedRoute = RouteTarget & Readonly<{ path: string }>;

export interface PageLocation {
  readonly route: ResolvedRoute;
  readonly page: PageDefinition;
}

export interface RouteDefinition {
  readonly name: PageName;
  readonly path: string;
  readonly page: PageDefinition;
}

export interface PageRouter {
  readonly current: PageLocation;
  /** 返回历史快照，调用方不能修改内部导航栈。 */
  readonly history: readonly PageLocation[];
  navigateTo(destination: string | RouteTarget): PageLocation;
  redirectTo(destination: string | RouteTarget): PageLocation;
  navigateBack(delta?: number): PageLocation;
}
