# 征途生灵·同行计划

MVP Demo V1.0 — 公共文化游戏化服务体验，课程展示用移动端小程序原型。

## 当前进度

已完成 Step 1–6、Phase 7 视觉卡片、Phase 8 真实素材与高保真 UI 整理。当前页面使用 58 个真实 PNG 资源并保留缺图 fallback；尚未补齐全部任务内容，未进入 Step 7 业务扩展。

原数据和内存路由层继续使用 TypeScript；组件使用 Vue 3 Composition API，状态层使用 Pinia setup store。已增加 Vue Router、Vite 和真实页面 View，形成可运行的浏览器移动端原型。尚未接入微信或 uni-app。

## 项目结构

```text
src/
├── pages/                 # 8 个核心页面，每页保留 index.ts 并增加 View.ts
│   ├── Home/              # 活动入口
│   ├── Identity/          # 身份选择
│   ├── Partner/           # 伙伴选择
│   ├── Route/             # 路线选择
│   ├── Map/               # 探索地图
│   ├── Mission/           # 任务与反馈
│   ├── Status/            # 人物、团队及伙伴状态
│   └── Archive/           # 同行档案
├── router/                # 框架无关的页面注册与内存导航
│   ├── types.ts           # 页面、路由参数及导航接口
│   ├── routes.ts          # 8 页注册表、路径构建与解析
│   ├── router.ts          # 前进、替换及返回的导航栈
│   ├── index.ts           # 路由层统一导出
│   └── appRouter.ts       # 浏览器运行时路由及选择完整性检查
├── components/            # 通用组件与业务组件
│   ├── Button/
│   ├── Card/
│   ├── IdentityCard/
│   ├── PartnerCard/
│   ├── RouteCard/
│   ├── MissionCard/
│   ├── ArchiveCard/
│   ├── StatusBar/          # Figma StatusBar 对应组件
│   ├── MapNode/
│   ├── Badge/              # Figma Badge 对应组件
│   ├── AchievementBadge/   # Badge 的兼容别名
│   ├── design-system/     # 设计令牌及组件样式
│   ├── examples/          # 各组件使用示例，不挂载到业务页面
│   ├── props.ts
│   ├── index.ts
│   └── README.md
├── assets/                # 真实 PNG、AssetImage fallback 与统一映射
│   ├── characters/
│   ├── backgrounds/
│   ├── icons/
│   ├── badges/
│   └── scenes/
├── data/                  # 已建立类型契约、静态目录及初始数据工厂
│   ├── models.ts          # 用户、资源、伙伴、任务、状态及档案等类型
│   ├── identities.ts      # 4 个身份
│   ├── partners.ts        # 5 个伙伴及素材路径
│   ├── routes.ts          # 3 条路线及预计时长
│   ├── mapNodes.ts        # 6 个地图节点
│   ├── missions.ts        # 草地补给示例及选择效果
│   ├── stories.ts         # 史料待补充，当前为空
│   ├── badges.ts          # 徽章待补充，当前为空
│   ├── defaults.ts        # 初始用户、资源、伙伴状态的独立副本
│   └── index.ts           # 数据层统一导出
├── store/                 # Pinia Composition API 状态管理
│   ├── userStore.ts
│   ├── partnerStore.ts
│   ├── routeStore.ts
│   ├── missionStore.ts
│   ├── resourceStore.ts
│   ├── archiveStore.ts
│   ├── validation.ts
│   ├── index.ts
│   ├── examples/useJourneyPageExample.ts
│   └── README.md
├── styles/app.css         # 复用既有设计令牌的页面基础样式
├── App.ts                 # RouterView 根组件
└── main.ts                # Pinia、路由与样式初始化
```

每页保留 `index.ts` 元信息，由同目录 `View.ts` 绑定组件和 store。图片源位于 `src/assets/`，同步到 `public/assets/`；背景入口复用真实 scenes 素材，缺图时由 AssetImage 和组件 fallback 处理。

## Step 6 页面绑定与运行

各页面源码、页面与 store 关系、assetMap、运行和验收流程见 [Step 6 交付说明](docs/step-6.md)。组件架构、数据及 store 实现保持不变。

```sh
cd /workspace/1111
npm ci --cache /tmp/journey-npm-cache
npm run dev
```

开发服务端口 5173；页面绑定检查用 `npm run test:step6`，构建用 `npm run build`。启程站尚无任务数据，点击进入 Mission 后显示内容待补充，不跳过节点；草地补给任务的页面绑定有独立测试验证。完整同行体验仍需要其余任务及故事内容。

## 组件系统

Step 4 创建 Button、Card、IdentityCard、PartnerCard、RouteCard、MissionCard、StatusBar、MapNode、Badge，保留 AchievementBadge 别名。Step 6 通过 Props 和回调绑定页面，不修改这些组件。

各组件源码、Figma 名称对应、公开 Props、设计令牌及逐项使用示例见 [组件说明](src/components/README.md)。完整可挂载示例见 [ComponentExamples.ts](src/components/examples/ComponentExamples.ts)。组件只展示数据和回传回调，不更新业务 store。

当前视觉使用 Design Token、真实场景／角色／图标／徽章／故事素材，已加入 375px 与 414px 响应式规则及 reduced-motion 支持。云环境 Chromium 截图启动超时，尚未完成微信小程序真机像素比对。

## 状态管理

6 个 Pinia store 已建立，任务效果由 missionStore 统一校验和应用，同步伙伴、人物资源、地图节点、进度与完成记录。重复任务提交不重复发放效果；档案由当前选择和记录自动派生。已有完成任务后改选需调用 `resetJourney()` 重新开始同行。

目录结构、各 store 代码、依赖关系及动作参数见 [状态管理说明](src/store/README.md)。Step 6 实际页面绑定见 [交付说明](docs/step-6.md)，store 和数据文件保持不变。

## 页面路由

| 页面 | 路径 | 用途 |
| --- | --- | --- |
| Home | `/home` | 活动入口，根路径 `/` 也解析到此页 |
| Identity | `/identity` | 身份选择 |
| Partner | `/partner` | 伙伴选择 |
| Route | `/route` | 路线选择 |
| Map | `/map` | 探索地图 |
| Mission | `/mission/:missionId` | 指定任务，必须携带非空任务 ID |
| Status | `/status` | 同行状态 |
| Archive | `/archive` | 同行档案 |

原内存路由接受路径或命名目标，元信息来自唯一注册表。浏览器运行时使用相同路径的 hash history，渲染 View.ts 页面。

```ts
import { createPageRouter } from './src/router/index.ts';

const router = createPageRouter(); // 初始 Home
router.navigateTo({ name: 'Identity' });
router.navigateTo({ name: 'Partner' });
router.navigateTo({ name: 'Route' });
router.navigateTo({ name: 'Map' });
router.navigateTo({ name: 'Mission', params: { missionId: 'grassland-supply' } });
router.navigateBack(); // 返回 Map
router.navigateTo({ name: 'Status' });
router.navigateBack(); // 返回 Map
router.navigateTo({ name: 'Archive' });
```

- `navigateTo` 增加一个历史条目，`redirectTo` 替换当前条目，`navigateBack` 默认返回一层；越界返回保留根页面。
- 未知路径、缺少任务参数或非法编码会抛出 `InvalidRouteError`，不修改历史；非法返回层数会抛出 `RangeError`。
- `current` 返回当前页面入口及解析后的参数，`history` 返回只读历史快照，各路由实例互相独立。
- 任务 ID 按单个路径段编码并还原；实际任务与当前节点由 store 校验，运行时路由检查选择是否完整。
- 原内存路由保持框架无关；appRouter.ts 接入浏览器 hash 地址。没有本地存储持久化；微信或 uni-app 平台导航尚待适配。

## 数据约定

- 用户的身份、伙伴、路线用 ID 引用静态目录，未选择时为 `null`，初始进度为 `0`。
- 人物体力存于 `Resource.energy`；伙伴体力存于 `PartnerStatus.energy`，任务效果分为 `resources` 与 `partner` 两类增量。
- 小卫、赤风、飞羽初始值遵循需求；小驮、阿牛的数值未指定，暂设为 `energy: 5, comfort: 5, trust: 5`。
- 三条路线暂共用六个节点，保留各自时长；差异机制尚待定义。
- 地图数据状态采用 `locked / current / complete / story`；组件规范中的 `Completed` 对应 `complete`。初始仅启程站为 `current`，其余为 `locked`。
- 仅录入需求提供的草地补给任务。其他任务、真实故事史料、徽章定义及获得条件待补充，相应内容引用为 `null` 或目录为空。
- `createInitialUser`、`createInitialResources` 和 `createInitialPartnerStatus` 返回独立数据副本，不更新全局状态。
- Pinia store 实现各状态的更新与档案派生：任务流程同步 progress 与 completedTasks，徽章数量由唯一徽章 ID 列表计算。Archive 存储目录 ID，中文内容通过静态目录查询。

## 类型及单元检查

需要 Node.js 24 或更高版本。首次安装依赖后执行：

```sh
cd /workspace/1111
npm ci --cache /tmp/journey-npm-cache
npm run typecheck
npm test
```

Vue、Pinia、Vue Router 为运行依赖；Vite 用于开发与构建，TypeScript、Vue Test Utils 和 Happy DOM 用于检查。测试验证数据、路由、组件、store 与页面绑定，未执行 Step 7 的完整体验流程测试。

## 后续开发约定

- 组件化、数据驱动，视觉与逻辑分离；UI 遵循《征途生灵 Design System》，不自行设计新视觉。
- 未来已有角色素材放入 `public/assets/characters/`：`xiaowei.png`、`chifeng.png`、`feiyu.png`、`xiaotuo.png`、`aniu.png`。本轮真实加载关闭，不创建假图片。
- 本轮停留在 Step 6，等待验收，不进入 Step 7；真实视觉素材接入按最新指示暂停。
- Demo 不开发登录、支付、数据库、GPS 或多人实时通信。
