import { defineComponent, h } from 'vue';
import { storeToRefs } from 'pinia';
import { useRouter } from 'vue-router';
import { partners } from '../../data/index.ts';
import { Button, PartnerCard } from '../../components/index.ts';
import { usePartnerStore, useUserStore } from '../../store/index.ts';
import { assetMap, assetProp } from '../../assets/assetMap.ts';
import { feedbackMessage, pageFrame, usePageFeedback } from '../shared.ts';

export default defineComponent({
  name: 'PartnerPage',
  setup() {
    const user = useUserStore();
    const { partner } = storeToRefs(usePartnerStore());
    const router = useRouter();
    const { feedback, run } = usePageFeedback();
    function onSelect(id: string): void {
      const item = partners.find(item => item.id === id);
      if (item) run(() => user.selectPartner(item.id));
    }
    return () => pageFrame('Partner', [
      h('ul', { class: 'zt-page__choices' }, partners.map(item => {
        const status = partner.value?.id === item.id ? partner.value : item;
        return h('li', { key: item.id }, [h(PartnerCard, {
          id: item.id, name: item.name, type: item.type,
          ...assetProp('avatar', assetMap[item.id]),
          energy: status.energy, comfort: status.comfort, trust: status.trust,
          selected: partner.value?.id === item.id, onSelect,
        })]);
      })),
      feedbackMessage(feedback.value),
      h(Button, { text: '返回身份选择', variant: 'Secondary', onClick: () => { void router.push({ name: 'Identity' }); } }),
      h(Button, { text: '下一步', disabled: partner.value === null, onClick: () => { void router.push({ name: 'Route' }); } }),
    ]);
  },
});
