import { defineComponent, h } from 'vue';
import { storeToRefs } from 'pinia';
import { useRouter } from 'vue-router';
import { Button, MapNode, StatusBar } from '../../components/index.ts';
import { useRouteStore } from '../../store/index.ts';
import { assetMap, assetProp } from '../../assets/assetMap.ts';
import type { MapNodeId } from '../../data/models.ts';
import { pageFrame } from '../shared.ts';

export default defineComponent({
  name: 'MapPage',
  setup() {
    const { nodes } = storeToRefs(useRouteStore());
    const router = useRouter();
    function onNodeClick(id: MapNodeId): void {
      const node = nodes.value.find(node => node.id === id);
      if (!node || node.status === 'locked') return;
      // 缺少任务数据时仍进入该站入口，由任务页明确展示待补充状态。
      void router.push({ name: 'Mission', params: { missionId: node.missionId ?? node.id } });
    }
    return () => pageFrame('Map', [
      h(StatusBar, { label: '已完成节点', value: nodes.value.filter(node => node.status === 'complete').length, max: nodes.value.length }),
      h('ul', { class: 'zt-page__choices' }, nodes.value.map(node => h('li', { key: node.id }, [h(MapNode, {
        name: node.name, status: node.status, ...assetProp('icon', assetMap.icons[node.id]), onClick: () => onNodeClick(node.id),
      })]))),
      h(Button, { text: '查看同行状态', variant: 'Secondary', onClick: () => { void router.push({ name: 'Status' }); } }),
      h(Button, { text: '查看同行档案', onClick: () => { void router.push({ name: 'Archive' }); } }),
    ]);
  },
});
