import { defineComponent, h } from 'vue';
import { storeToRefs } from 'pinia';
import { useRouter } from 'vue-router';
import { identities } from '../../data/index.ts';
import { Button, IdentityCard } from '../../components/index.ts';
import { useUserStore } from '../../store/index.ts';
import { assetMap, assetProp } from '../../assets/assetMap.ts';
import { feedbackMessage, pageFrame, usePageFeedback } from '../shared.ts';

export default defineComponent({
  name: 'IdentityPage',
  setup() {
    const user = useUserStore();
    const { identity } = storeToRefs(user);
    const router = useRouter();
    const { feedback, run } = usePageFeedback();
    function onSelect(id: string): void {
      const item = identities.find(item => item.id === id);
      if (item) run(() => user.selectIdentity(item.id));
    }
    return () => pageFrame('Identity', [
      h('ul', { class: 'zt-page__choices' }, identities.map(item => h('li', { key: item.id }, [h(IdentityCard, {
        id: item.id, name: item.name, description: item.ability, skill: item.ability,
        ...assetProp('icon', assetMap.icons[item.id]), selected: identity.value === item.id, onSelect,
      })]))),
      feedbackMessage(feedback.value),
      h(Button, { text: '返回首页', variant: 'Secondary', onClick: () => { void router.push({ name: 'Home' }); } }),
      h(Button, { text: '下一步', disabled: identity.value === null, onClick: () => { void router.push({ name: 'Partner' }); } }),
    ]);
  },
});
