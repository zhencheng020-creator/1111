import { defineComponent, h } from 'vue';
import { getActivePinia, storeToRefs } from 'pinia';
import { useRouter } from 'vue-router';
import { Badge, Button, Card } from '../../components/index.ts';
import { useArchiveStore, resetJourney } from '../../store/index.ts';
import { identities, partners, routes, missions, stories, badges } from '../../data/index.ts';
import { assetMap, assetProp, resolveAssetUrl } from '../../assets/assetMap.ts';
import { detailList, pageFrame } from '../shared.ts';

export default defineComponent({
  name: 'ArchivePage',
  setup() {
    const pinia = getActivePinia();
    const { archive, isComplete } = storeToRefs(useArchiveStore());
    const router = useRouter();
    return () => {
      const record = archive.value;
      return pageFrame('Archive', [
        h('p', isComplete.value ? '同行已完成' : '同行进行中'),
        record ? h(Card, {}, { default: () => [
          detailList([
            ['身份', identities.find(item => item.id === record.identity)?.name ?? '待选择'],
            ['伙伴', partners.find(item => item.id === record.partner)?.name ?? '待选择'],
            ['路线', routes.find(item => item.id === record.route)?.name ?? '待选择'],
          ]),
          h('h2', '完成任务'),
          record.completedTasks.length ? h('ul', record.completedTasks.map(id => h('li', { key: id }, missions.find(item => item.id === id)?.title ?? '任务资料待补充'))) : h('p', '暂无完成任务'),
          h('h2', '解锁故事'),
          record.stories.length ? record.stories.map(id => {
            const story = stories.find(item => item.id === id);
            const image = resolveAssetUrl(assetMap.stories[id]);
            return story ? h('article', { key: id }, [h('h3', story.title), image ? h('img', { src: image, alt: story.title }) : null,
              h('p', story.content), ...story.sources.map(source => h('p', { class: 'zt-page__caption' }, `${source.title}：${source.citation}`))]) : null;
          }) : h('p', '暂无解锁故事'),
          h('h2', '同行徽章'),
          record.badges.length ? record.badges.map(id => {
            const definition = badges.find(item => item.id === id);
            return definition ? h(Badge, { key: id, name: definition.name,
              ...assetProp('icon', assetMap.badges[id] ?? `/assets/${definition.assetPath}`), unlocked: true }) : null;
          }) : h('p', '暂无徽章'),
        ] }) : h('p', '请先完成身份、伙伴和路线选择。'),
        h(Button, { text: '返回地图', variant: 'Secondary', onClick: () => { void router.push({ name: 'Map' }); } }),
        h(Button, { text: '重新同行', onClick: () => { resetJourney(pinia); void router.replace({ name: 'Home' }); } }),
      ]);
    };
  },
});
