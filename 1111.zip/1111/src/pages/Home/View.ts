import { defineComponent, h } from 'vue';
import { useRouter } from 'vue-router';
import { Button } from '../../components/index.ts';
import { assetMap, resolveAssetUrl } from '../../assets/assetMap.ts';
import { pageFrame } from '../shared.ts';

export default defineComponent({
  name: 'HomePage',
  setup() {
    const router = useRouter();
    return () => pageFrame('Home', [
      h('p', '动物伙伴情感入口 × 长征真实史料 × 公共文化游戏化服务'),
      h('p', '选择身份、伙伴和路线，完成任务、照顾伙伴、解锁故事，生成同行档案。'),
      resolveAssetUrl(assetMap.xiaowei) ? h('img', { src: resolveAssetUrl(assetMap.xiaowei), alt: '小卫' }) : null,
      h(Button, { text: '开始同行', onClick: () => { void router.push({ name: 'Identity' }); } }),
    ]);
  },
});
