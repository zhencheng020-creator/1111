import { defineComponent, h } from 'vue';
import { storeToRefs } from 'pinia';
import { useRouter } from 'vue-router';
import { routes } from '../../data/index.ts';
import { Button, RouteCard } from '../../components/index.ts';
import { useRouteStore, useUserStore } from '../../store/index.ts';
import { feedbackMessage, pageFrame, usePageFeedback } from '../shared.ts';

export default defineComponent({
  name: 'RoutePage',
  setup() {
    const user = useUserStore();
    const { routeId } = storeToRefs(useRouteStore());
    const router = useRouter();
    const { feedback, run } = usePageFeedback();
    function onSelect(id: string): void {
      const item = routes.find(item => item.id === id);
      if (item) run(() => user.selectRoute(item.id));
    }
    return () => pageFrame('Route', [
      h('ul', { class: 'zt-page__choices' }, routes.map(item => h('li', { key: item.id }, [h(RouteCard, {
        id: item.id, name: item.name, time: `${item.durationMinutes.min}–${item.durationMinutes.max}分钟`,
        difficulty: '', description: '', selected: routeId.value === item.id, onSelect,
      })]))),
      feedbackMessage(feedback.value),
      h(Button, { text: '返回伙伴选择', variant: 'Secondary', onClick: () => { void router.push({ name: 'Partner' }); } }),
      h(Button, { text: '进入地图', disabled: routeId.value === null, onClick: () => { void router.push({ name: 'Map' }); } }),
    ]);
  },
});
