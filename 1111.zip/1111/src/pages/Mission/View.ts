import { defineComponent, h, ref, watch } from 'vue';
import { storeToRefs } from 'pinia';
import { useRoute, useRouter } from 'vue-router';
import { Button, Card, MissionCard } from '../../components/index.ts';
import { useMissionStore, JourneyError } from '../../store/index.ts';
import type { MissionChoice, MissionEffect } from '../../data/models.ts';
import { detailList, feedbackMessage, pageFrame, usePageFeedback } from '../shared.ts';

function effectText(effect: MissionEffect): string[] {
  const messages: string[] = [];
  const resources = { energy: '人物体力', food: '粮食', medical: '医疗资源', badge: '徽章' };
  const partner = { energy: '伙伴体力', comfort: '舒适度', trust: '信任' };
  for (const [field, label] of Object.entries(resources)) {
    const delta = effect.resources?.[field as keyof typeof resources];
    if (delta) messages.push(`${label} ${delta > 0 ? '+' : ''}${delta}`);
  }
  for (const [field, label] of Object.entries(partner)) {
    const delta = effect.partner?.[field as keyof typeof partner];
    if (delta) messages.push(`${label} ${delta > 0 ? '+' : ''}${delta}`);
  }
  return messages;
}

export default defineComponent({
  name: 'MissionPage',
  setup() {
    const route = useRoute();
    const router = useRouter();
    const mission = useMissionStore();
    const { currentMission, result } = storeToRefs(mission);
    const loadedId = ref<string | null>(null);
    const { feedback, run } = usePageFeedback();
    watch(() => route.params.missionId, parameter => {
      loadedId.value = null;
      feedback.value = '';
      const id = typeof parameter === 'string' ? parameter : '';
      try { mission.openMission(id); loadedId.value = id; }
      catch (error) {
        feedback.value = error instanceof JourneyError && error.code === 'UNKNOWN_MISSION'
          ? '本站任务内容尚未提供。' : error instanceof Error ? error.message : '任务暂时无法打开。';
      }
    }, { immediate: true });
    function onChoice(choice: MissionChoice): void {
      if (!loadedId.value || result.value?.missionId === loadedId.value) return;
      run(() => { mission.selectChoice(choice.id); mission.applyEffect(); });
    }
    return () => {
      const task = loadedId.value === currentMission.value?.id ? currentMission.value : null;
      const outcome = task && result.value?.missionId === task.id ? result.value : null;
      return pageFrame('Mission', [
        task && !outcome ? h(MissionCard, { title: task.title, description: task.description, choices: task.choices, onChoice }) : null,
        outcome ? h(Card, {}, { default: () => [
          h('h2', '任务已完成'),
          h('p', task?.choices.find(choice => choice.id === outcome.choiceId)?.label ?? ''),
          ...effectText(outcome.effect).map(text => h('p', text)),
          detailList([
            ['伙伴体力', outcome.partnerAfter.energy], ['舒适度', outcome.partnerAfter.comfort], ['信任', outcome.partnerAfter.trust],
          ]),
        ] }) : null,
        feedbackMessage(feedback.value),
        h(Button, { text: '返回地图', variant: 'Secondary', onClick: () => { void router.push({ name: 'Map' }); } }),
      ]);
    };
  },
});
