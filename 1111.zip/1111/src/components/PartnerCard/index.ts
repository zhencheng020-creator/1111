import { defineComponent, h } from 'vue';
import type { PropType } from 'vue';
import Card from '../Card/index.ts';
import type { PartnerCardProps } from '../props.ts';

export default defineComponent({
  name: 'PartnerCard',
  props: {
    id: { type: String, required: true },
    name: { type: String, required: true },
    type: { type: String, required: true },
    avatar: String,
    energy: { type: Number, required: true },
    comfort: { type: Number, required: true },
    trust: { type: Number, required: true },
    selected: { type: Boolean, default: false },
    onSelect: Function as PropType<PartnerCardProps['onSelect']>,
  },
  setup(props) {
    return () => h(Card, {
      as: 'button', selected: props.selected,
      'data-figma': 'Card/Partner',
      'aria-pressed': props.selected,
      onClick: () => props.onSelect?.(props.id),
    }, { default: () => [
      props.avatar ? h('img', { src: props.avatar, alt: props.name, class: 'zt-avatar' }) : null,
      h('span', { class: 'zt-card__title' }, props.name),
      h('span', { class: 'zt-card__body' }, props.type),
      h('span', { class: 'zt-card__caption' }, `体力 ${props.energy} · 舒适度 ${props.comfort} · 信任 ${props.trust}`),
    ] });
  },
});
