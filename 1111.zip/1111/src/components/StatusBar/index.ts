import { defineComponent, h } from 'vue';

export default defineComponent({
  name: 'StatusBar',
  props: {
    label: { type: String, required: true },
    value: { type: Number, required: true },
    max: { type: Number, required: true },
    icon: String,
  },
  setup(props) {
    return () => {
      // 仅保护显示范围，不修改传入的资源或伙伴数值。
      const max = Number.isFinite(props.max) && props.max > 0 ? props.max : 1;
      const value = Math.min(max, Math.max(0, Number.isFinite(props.value) ? props.value : 0));
      return h('div', { class: 'zt-status-bar', 'data-figma': 'StatusBar' }, [
        props.icon ? h('img', { src: props.icon, alt: '', class: 'zt-icon' }) : null,
        h('span', { class: 'zt-status-bar__label' }, props.label),
        h('span', { class: 'zt-caption' }, `${value} / ${max}`),
        h('progress', { class: 'zt-status-bar__progress', value, max, 'aria-label': props.label }),
      ]);
    };
  },
});
