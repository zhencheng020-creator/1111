import { defineComponent, h } from 'vue';
import type { PropType } from 'vue';
import Card from '../Card/index.ts';
import type { IdentityCardProps } from '../props.ts';

export default defineComponent({
  name: 'IdentityCard',
  props: {
    id: { type: String, required: true },
    name: { type: String, required: true },
    description: { type: String, required: true },
    skill: { type: String, required: true },
    icon: String,
    selected: { type: Boolean, default: false },
    onSelect: Function as PropType<IdentityCardProps['onSelect']>,
  },
  setup(props) {
    return () => h(Card, {
      as: 'button', selected: props.selected,
      'data-figma': 'Card/Identity',
      'aria-pressed': props.selected,
      onClick: () => props.onSelect?.(props.id),
    }, { default: () => [
      props.icon ? h('img', { src: props.icon, alt: '', class: 'zt-icon' }) : null,
      h('span', { class: 'zt-card__title' }, props.name),
      h('span', { class: 'zt-card__body' }, props.description),
      h('span', { class: 'zt-card__caption' }, props.skill),
    ] });
  },
});
