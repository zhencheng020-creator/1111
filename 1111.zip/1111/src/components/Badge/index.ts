import { defineComponent, h } from 'vue';

export default defineComponent({
  name: 'Badge',
  props: {
    name: { type: String, required: true },
    icon: String,
    unlocked: { type: Boolean, required: true },
  },
  setup(props) {
    return () => h('div', {
      class: ['zt-badge', { 'zt-badge--unlocked': props.unlocked }],
      'data-figma': 'Badge', 'data-unlocked': props.unlocked,
    }, [
      props.icon ? h('img', { src: props.icon, alt: '', class: 'zt-icon' }) : null,
      h('span', { class: 'zt-badge__name' }, props.name),
      h('span', { class: 'zt-caption' }, props.unlocked ? '已解锁' : '未解锁'),
    ]);
  },
});
