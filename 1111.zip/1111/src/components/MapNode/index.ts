import { defineComponent, h } from 'vue';
import type { PropType } from 'vue';
import type { MapNodeStatus } from '../../data/models.ts';
import type { MapNodeProps } from '../props.ts';

const statusLabels: Record<MapNodeStatus, string> = {
  locked: '未解锁', current: '当前节点', complete: '已完成', story: '故事节点',
};

export default defineComponent({
  name: 'MapNode',
  props: {
    name: { type: String, required: true },
    status: { type: String as PropType<MapNodeStatus>, required: true },
    icon: String,
    onClick: Function as PropType<MapNodeProps['onClick']>,
  },
  setup(props) {
    return () => h('button', {
      type: 'button', class: ['zt-map-node', `zt-map-node--${props.status}`],
      disabled: props.status === 'locked',
      'data-figma': 'MapNode', 'data-variant': props.status,
      'aria-label': `${props.name}，${statusLabels[props.status]}`,
      onClick: () => { if (props.status !== 'locked') props.onClick?.(); },
    }, [
      props.icon ? h('img', { src: props.icon, alt: '', class: 'zt-icon' }) : null,
      h('span', { class: 'zt-card__title' }, props.name),
      h('span', { class: 'zt-caption' }, statusLabels[props.status]),
    ]);
  },
});
