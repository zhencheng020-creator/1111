import { defineComponent, h } from 'vue';
import type { PropType } from 'vue';
import type { MissionChoice } from '../../data/models.ts';
import Card from '../Card/index.ts';
import Button from '../Button/index.ts';
import type { MissionCardProps } from '../props.ts';

export default defineComponent({
  name: 'MissionCard',
  props: {
    title: { type: String, required: true },
    description: { type: String, required: true },
    choices: { type: Array as PropType<readonly MissionChoice[]>, required: true },
    onChoice: Function as PropType<MissionCardProps['onChoice']>,
  },
  setup(props) {
    return () => h(Card, { 'data-figma': 'Card/Mission' }, { default: () => [
      h('span', { class: 'zt-card__title' }, props.title),
      h('span', { class: 'zt-card__body' }, props.description),
      h('div', { class: 'zt-mission__choices' }, props.choices.map(choice => h(Button, {
        key: choice.id, text: choice.label,
        onClick: () => props.onChoice?.(choice),
      }))),
    ] });
  },
});
