import { defineComponent, h } from 'vue';
import type { PropType } from 'vue';
import Card from '../Card/index.ts';
import type { RouteCardProps } from '../props.ts';

export default defineComponent({
  name: 'RouteCard',
  props: {
    id: { type: String, required: true },
    name: { type: String, required: true },
    time: { type: String, required: true },
    difficulty: { type: String, required: true },
    description: { type: String, required: true },
    selected: { type: Boolean, default: false },
    onSelect: Function as PropType<RouteCardProps['onSelect']>,
  },
  setup(props) {
    return () => h(Card, {
      as: 'button', selected: props.selected,
      'data-figma': 'Card/Route',
      'aria-pressed': props.selected,
      onClick: () => props.onSelect?.(props.id),
    }, { default: () => [
      h('span', { class: 'zt-card__title' }, props.name),
      h('span', { class: 'zt-card__caption' }, props.time),
      h('span', { class: 'zt-card__caption' }, props.difficulty),
      h('span', { class: 'zt-card__body' }, props.description),
    ] });
  },
});
