import type { PartnerId } from '../data/models.ts';
import type { PageName } from '../router/types.ts';
import { availableAssets } from './assetManifest.ts';

type AssetMap = Record<PartnerId, string> & {
  backgrounds: Partial<Record<PageName, string>>;
  icons: Record<string, string>;
  badges: Record<string, string>;
  stories: Record<string, string>;
};

/** 静态 URL 对应 public/assets；只使用已有素材，不生成图片。 */
export const assetMap: AssetMap = {
  xiaowei: '/assets/characters/xiaowei.png',
  chifeng: '/assets/characters/chifeng.png',
  feiyu: '/assets/characters/feiyu.png',
  xiaotuo: '/assets/characters/xiaotuo.png',
  aniu: '/assets/characters/aniu.png',
  // 未提供文件及角色用途对应关系，保留空映射而不猜测图片。
  backgrounds: {},
  icons: {},
  badges: {},
  stories: {},
};

/** 本轮明确暂停真实视觉资产接入；导入并核对素材后再开启。 */
export const realAssetLoadingEnabled: boolean = false;

/** 不将缺失文件作为 img src，避免假素材或破图。 */
export function resolveAssetUrl(path: string | undefined): string | undefined {
  if (!realAssetLoadingEnabled) return undefined;
  return path && availableAssets.includes(path) ? path : undefined;
}

/** 可选图片 Prop 应省略，不传入显式 undefined，兼容严格类型检查。 */
export function assetProp<K extends 'icon' | 'avatar'>(key: K, path: string | undefined): Partial<Record<K, string>> {
  const url = resolveAssetUrl(path);
  return url ? { [key]: url } as Record<K, string> : {};
}
