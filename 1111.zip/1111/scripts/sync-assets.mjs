import { mkdir, readdir, readFile, writeFile } from 'node:fs/promises';
import { fileURLToPath } from 'node:url';
import path from 'node:path';

const projectRoot = fileURLToPath(new URL('../', import.meta.url));
const assetRoot = path.join(projectRoot, 'public/assets');
const extensions = new Set(['.png', '.jpg', '.jpeg', '.webp', '.gif', '.svg', '.avif']);
for (const category of ['characters', 'backgrounds', 'icons', 'badges', 'stories']) {
  await mkdir(path.join(assetRoot, category), { recursive: true });
}
const files = [];
async function walk(directory) {
  for (const entry of await readdir(directory, { withFileTypes: true })) {
    const filename = path.join(directory, entry.name);
    if (entry.isSymbolicLink()) throw new Error('素材目录请使用实际文件，不能使用符号链接');
    if (entry.isDirectory()) await walk(filename);
    else if (entry.isFile() && extensions.has(path.extname(entry.name).toLowerCase())) {
      const relative = path.relative(assetRoot, filename).split(path.sep).map(encodeURIComponent).join('/');
      files.push(`/assets/${relative}`);
    }
  }
}
await walk(assetRoot);
files.sort();
const output = '// 由 scripts/sync-assets.mjs 生成；列表仅说明实际文件存在。\n' +
  `export const availableAssets: readonly string[] = Object.freeze(${JSON.stringify(files, null, 2)});\n`;
const destination = path.join(projectRoot, 'src/assets/assetManifest.ts');
let previous = '';
try { previous = await readFile(destination, 'utf8'); } catch (error) { if (error.code !== 'ENOENT') throw error; }
if (previous !== output) await writeFile(destination, output);
console.log(`素材清单：${files.length} 个现有文件；未生成或修改图片。`);
