import { defineComponent, h, onMounted } from 'vue';
import { getActivePinia, storeToRefs } from 'pinia';
import { useRouter } from 'vue-router';
import { Badge, Button } from '../../components/index.ts';
import ArchiveCard from '../../components/ArchiveCard/index.ts';
import { useArchiveStore, resetJourney } from '../../store/index.ts';
import { identities, partners, routes, missions, stories, badges } from '../../data/index.ts';
import { assetDirectories, assetMap, catalogAssetPath, resolveAssetUrl } from '../../assets/assetMap.ts';
import AssetImage from '../../assets/AssetImage.ts';
import { pageFrame } from '../shared.ts';

const archivePageStyles = `
.zt-page[data-page="Archive"] {
  box-sizing: border-box;
  width: 100%;
  max-width: 480px;
  margin: 0 auto;
  padding: 28px 20px max(28px, env(safe-area-inset-bottom));
  background: var(--zt-paper, #F8EEDB);
  color: var(--zt-ink, #3B2920);
}
.zt-page[data-page="Archive"] > .zt-page__title {
  margin: 0 0 16px;
  padding-left: 14px;
  border-left: 4px solid var(--zt-journey-orange, #E86B2A);
  font-size: 32px;
  line-height: 1.3;
}
.zt-page[data-page="Archive"] > .zt-archive-page-status {
  display: inline-block;
  margin: 0 0 24px;
  padding: 6px 12px;
  border: 1px solid rgba(91, 143, 185, .4);
  border-radius: 8px;
  background: rgba(91, 143, 185, .08);
  font-size: 12px;
  font-weight: 700;
  line-height: 1.5;
}
.zt-page[data-page="Archive"] > .zt-archive-page-status--complete {
  border-color: var(--zt-field-green, #739B56);
  background: rgba(115, 155, 86, .1);
}
.zt-page[data-page="Archive"] > .zt-archive-card { margin-bottom: 24px; }
.zt-page[data-page="Archive"] > .zt-archive-page-empty {
  margin: 0 0 24px;
  padding: 20px;
  border: 1px dashed var(--zt-sky-blue, #5B8FB9);
  border-radius: 16px;
  background: rgba(91, 143, 185, .08);
  line-height: 1.6;
}
.zt-page[data-page="Archive"] > .zt-button {
  box-sizing: border-box;
  width: 100%;
  min-height: 48px;
  padding: 12px 16px;
  border: 2px solid var(--zt-journey-orange, #E86B2A);
  border-radius: 14px;
  font-weight: 700;
  font-size: 20px;
  line-height: 1.5;
  touch-action: manipulation;
}
.zt-page[data-page="Archive"] > .zt-button--secondary {
  margin-bottom: 12px;
  border-color: var(--zt-field-green, #739B56);
  background: var(--zt-paper, #F8EEDB);
  color: var(--zt-ink, #3B2920);
}
.zt-page[data-page="Archive"] > .zt-button--primary {
  background: var(--zt-journey-orange, #E86B2A);
  color: var(--zt-ink, #3B2920);
}
.zt-page[data-page="Archive"] > .zt-button:focus-visible {
  outline: 3px solid var(--zt-field-green, #739B56);
  outline-offset: 4px;
}
.zt-page[data-page="Archive"] > .zt-button:active { filter: brightness(.95); }
@media (max-width: 359px) {
  .zt-page[data-page="Archive"] { padding-inline: 12px; }
}
`;

export default defineComponent({
  name: 'ArchivePage',
  setup() {
    const pinia = getActivePinia();
    const { archive, isComplete } = storeToRefs(useArchiveStore());
    const router = useRouter();
    onMounted(() => {
      if (document.getElementById('zt-archive-page-styles')) return;
      const style = document.createElement('style');
      style.id = 'zt-archive-page-styles';
      style.textContent = archivePageStyles;
      document.head.appendChild(style);
    });
    return () => {
      const record = archive.value;
      const identity = identities.find(item => item.id === record?.identity);
      const partner = partners.find(item => item.id === record?.partner);
      const journeyRoute = routes.find(item => item.id === record?.route);
      return pageFrame('Archive', [
        h('p', { class: ['zt-archive-page-status', { 'zt-archive-page-status--complete': isComplete.value }] }, isComplete.value ? '同行已完成' : '同行进行中'),
        record ? h(ArchiveCard, {
          identityName: identity?.name ?? '待选择', identityAbility: identity?.ability ?? '',
          partnerName: partner?.name ?? '待选择', partnerType: partner?.type ?? '',
          routeName: journeyRoute?.name ?? '待选择',
          routeTime: journeyRoute ? `${journeyRoute.durationMinutes.min}–${journeyRoute.durationMinutes.max}分钟` : '',
          nodeCount: journeyRoute?.nodeIds.length ?? 0,
          missionCount: record.completedTasks.length, storyCount: record.stories.length, badgeCount: record.badges.length,
          isComplete: isComplete.value,
        }, {
          missions: () => record.completedTasks.length
            ? h('ul', record.completedTasks.map(id => h('li', { key: id }, missions.find(item => item.id === id)?.title ?? '任务资料待补充')))
            : h('p', { class: 'zt-archive-card__empty' }, '暂无完成任务'),
          stories: () => record.stories.length ? record.stories.map(id => {
            const story = stories.find(item => item.id === id);
            const image = resolveAssetUrl(assetMap.stories[id]);
            return story ? h('article', { key: id }, [h('h3', story.title), image ? h(AssetImage, { src: image, alt: story.title }) : null,
              h('p', story.content), ...story.sources.map(source => h('p', { class: 'zt-page__caption' }, `${source.title}：${source.citation}`))]) : null;
          }) : h('p', { class: 'zt-archive-card__empty' }, '暂无解锁故事'),
          badges: () => record.badges.length ? record.badges.map(id => {
            const definition = badges.find(item => item.id === id);
            if (!definition) return null;
            const badgePath = assetMap.badges[id] ?? catalogAssetPath(definition.assetPath);
            return h('div', { key: id, class: 'zt-archive-card__badge', 'data-asset-src': badgePath }, [
              h(AssetImage, { src: resolveAssetUrl(badgePath) ?? '', alt: '', class: 'zt-archive-card__badge-placeholder', style: { objectFit: 'contain' } }, {
                fallback: () => h('span', { class: 'zt-archive-card__badge-placeholder', 'aria-hidden': 'true' }, '徽'),
              }),
              h(Badge, { name: definition.name, unlocked: true }),
            ]);
          }) : [
            h('span', { class: 'zt-archive-card__badge-placeholder', 'aria-hidden': 'true', 'data-asset-path': `${assetDirectories.badges}*.png` }, '徽'),
            h('p', { class: 'zt-archive-card__empty' }, '暂无徽章'),
          ],
        }) : h('p', { class: 'zt-archive-page-empty' }, '请先完成身份、伙伴和路线选择。'),
        h(Button, { text: '返回地图', variant: 'Secondary', onClick: () => { void router.push({ name: 'Map' }); } }),
        h(Button, { text: '重新同行', onClick: () => { resetJourney(pinia); void router.replace({ name: 'Home' }); } }),
      ]);
    };
  },
});
