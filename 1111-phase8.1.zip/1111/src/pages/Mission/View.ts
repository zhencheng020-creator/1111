import { defineComponent, h, onMounted, ref, watch } from 'vue';
import { storeToRefs } from 'pinia';
import { useRoute, useRouter } from 'vue-router';
import { Button, Card, MissionCard } from '../../components/index.ts';
import { useMissionStore, JourneyError } from '../../store/index.ts';
import type { MissionChoice, MissionEffect } from '../../data/models.ts';
import { assetMap, resolveAssetUrl } from '../../assets/assetMap.ts';
import AssetImage from '../../assets/AssetImage.ts';
import { detailList, feedbackMessage, pageFrame, usePageFeedback } from '../shared.ts';

const missionPageStyles = `
.zt-page[data-page="Mission"] {
  box-sizing: border-box;
  width: 100%;
  max-width: 480px;
  margin: 0 auto;
  padding: 28px 20px max(28px, env(safe-area-inset-bottom));
  background: var(--zt-paper, #F8EEDB);
  color: var(--zt-ink, #3B2920);
}
.zt-page[data-page="Mission"] > .zt-page__title {
  margin: 0 0 24px;
  padding-left: 14px;
  border-left: 4px solid var(--zt-journey-orange, #E86B2A);
  font-size: 32px;
  line-height: 1.3;
}
.zt-page[data-page="Mission"] > .zt-mission-card,
.zt-page[data-page="Mission"] > .zt-mission-result { margin-bottom: 24px; }
.zt-page[data-page="Mission"] .zt-mission-result {
  box-sizing: border-box;
  display: flex;
  flex-direction: column;
  gap: 16px;
  padding: 20px;
  border: 2px solid var(--zt-field-green, #739B56);
  border-radius: 20px;
  background: var(--zt-paper, #F8EEDB);
  color: var(--zt-ink, #3B2920);
  box-shadow: 0 3px 0 rgba(59, 41, 32, .06);
}
.zt-page[data-page="Mission"] .zt-mission-result__header { display: flex; align-items: center; gap: 12px; }
.zt-page[data-page="Mission"] .zt-mission-result__icon {
  display: grid;
  place-items: center;
  flex-shrink: 0;
  width: 48px;
  height: 48px;
  border: 1px dashed var(--zt-field-green, #739B56);
  border-radius: 14px;
  background: rgba(115, 155, 86, .12);
  font-size: 24px;
  font-weight: 700;
}
.zt-page[data-page="Mission"] .zt-mission-result h2 { margin: 0; font-size: 24px; line-height: 1.4; }
.zt-page[data-page="Mission"] .zt-mission-result__title { font-size: 12px; line-height: 1.5; opacity: .7; }
.zt-page[data-page="Mission"] .zt-mission-result__choice {
  margin: 0;
  padding: 12px 14px;
  border-left: 3px solid var(--zt-journey-orange, #E86B2A);
  border-radius: 0 12px 12px 0;
  background: rgba(232, 107, 42, .08);
  font-weight: 700;
  line-height: 1.6;
  overflow-wrap: anywhere;
}
.zt-page[data-page="Mission"] .zt-mission-result__effect {
  margin: 0;
  padding: 10px 12px;
  border-radius: 10px;
  background: rgba(115, 155, 86, .1);
  font-size: 16px;
  line-height: 1.5;
}
.zt-page[data-page="Mission"] .zt-mission-result dl {
  display: grid;
  grid-template-columns: minmax(0, 1fr) auto;
  gap: 10px 16px;
  margin: 0;
  padding-top: 16px;
  border-top: 1px solid rgba(59, 41, 32, .12);
  font-size: 16px;
  line-height: 1.5;
}
.zt-page[data-page="Mission"] .zt-mission-result dd { margin: 0; font-weight: 700; font-variant-numeric: tabular-nums; }
.zt-page[data-page="Mission"] > [role="alert"] {
  margin: 0 0 24px;
  padding: 20px;
  border: 1px dashed var(--zt-sky-blue, #5B8FB9);
  border-radius: 16px;
  background: rgba(91, 143, 185, .08);
  line-height: 1.6;
}
.zt-page[data-page="Mission"] > .zt-button {
  box-sizing: border-box;
  width: 100%;
  min-height: 48px;
  padding: 12px 16px;
  border: 2px solid var(--zt-field-green, #739B56);
  border-radius: 14px;
  background: var(--zt-paper, #F8EEDB);
  color: var(--zt-ink, #3B2920);
  font-size: 20px;
  font-weight: 700;
  line-height: 1.5;
  touch-action: manipulation;
}
.zt-page[data-page="Mission"] > .zt-button:focus-visible {
  outline: 3px solid var(--zt-field-green, #739B56);
  outline-offset: 4px;
}
.zt-page[data-page="Mission"] > .zt-button:active { filter: brightness(.95); }
@media (max-width: 359px) {
  .zt-page[data-page="Mission"] { padding-inline: 12px; }
  .zt-page[data-page="Mission"] .zt-mission-result { padding: 16px; }
}
`;

function effectText(effect: MissionEffect): string[] {
  const messages: string[] = [];
  const resources = { energy: '人物体力', food: '粮食', medical: '医疗资源', badge: '徽章' };
  const partner = { energy: '伙伴体力', comfort: '舒适度', trust: '信任' };
  for (const [field, label] of Object.entries(resources)) {
    const delta = effect.resources?.[field as keyof typeof resources];
    if (delta) messages.push(`${label} ${delta > 0 ? '+' : ''}${delta}`);
  }
  for (const [field, label] of Object.entries(partner)) {
    const delta = effect.partner?.[field as keyof typeof partner];
    if (delta) messages.push(`${label} ${delta > 0 ? '+' : ''}${delta}`);
  }
  return messages;
}

export default defineComponent({
  name: 'MissionPage',
  setup() {
    const route = useRoute();
    const router = useRouter();
    const mission = useMissionStore();
    const { currentMission, selectedChoice, result } = storeToRefs(mission);
    const loadedId = ref<string | null>(null);
    const { feedback, run } = usePageFeedback();
    onMounted(() => {
      if (document.getElementById('zt-mission-page-styles')) return;
      const style = document.createElement('style');
      style.id = 'zt-mission-page-styles';
      style.textContent = missionPageStyles;
      document.head.appendChild(style);
    });
    watch(() => route.params.missionId, parameter => {
      loadedId.value = null;
      feedback.value = '';
      const id = typeof parameter === 'string' ? parameter : '';
      try { mission.openMission(id); loadedId.value = id; }
      catch (error) {
        feedback.value = error instanceof JourneyError && error.code === 'UNKNOWN_MISSION'
          ? '本站任务内容尚未提供。' : error instanceof Error ? error.message : '任务暂时无法打开。';
      }
    }, { immediate: true });
    function onChoice(choice: MissionChoice): void {
      if (!loadedId.value || result.value?.missionId === loadedId.value) return;
      run(() => { mission.selectChoice(choice.id); mission.applyEffect(); });
    }
    return () => {
      const task = loadedId.value === currentMission.value?.id ? currentMission.value : null;
      const outcome = task && result.value?.missionId === task.id ? result.value : null;
      return pageFrame('Mission', [
        task && !outcome ? h(MissionCard, {
          title: task.title, description: task.description, choices: task.choices,
          selectedChoiceId: selectedChoice.value?.id ?? null, onChoice,
        }) : null,
        outcome ? h(Card, { class: 'zt-mission-result', role: 'status', 'aria-live': 'polite' }, { default: () => [
          h('div', { class: 'zt-mission-result__header' }, [
            h('span', {
              class: 'zt-mission-result__icon', 'aria-hidden': 'true',
              'data-asset-src': assetMap.icons['mission-complete'],
            }, [h(AssetImage, {
              src: resolveAssetUrl(assetMap.icons['mission-complete']) ?? '', alt: '',
              style: { width: '100%', height: '100%', objectFit: 'contain' },
            }, { fallback: () => '✓' })]),
            h('div', [
              h('span', { class: 'zt-mission-result__title' }, task?.title ?? ''),
              h('h2', '任务已完成'),
            ]),
          ]),
          h('p', { class: 'zt-mission-result__choice' }, `已选择：${task?.choices.find(choice => choice.id === outcome.choiceId)?.label ?? ''}`),
          ...effectText(outcome.effect).map(text => h('p', { class: 'zt-mission-result__effect' }, text)),
          detailList([
            ['伙伴体力', outcome.partnerAfter.energy], ['舒适度', outcome.partnerAfter.comfort], ['信任', outcome.partnerAfter.trust],
          ]),
        ] }) : null,
        feedbackMessage(feedback.value),
        h(Button, { text: '返回地图', variant: 'Secondary', onClick: () => { void router.push({ name: 'Map' }); } }),
      ]);
    };
  },
});
