import { defineComponent, h, onMounted } from 'vue';
import { storeToRefs } from 'pinia';
import { useRouter } from 'vue-router';
import { Button, MapNode, StatusBar } from '../../components/index.ts';
import { useRouteStore } from '../../store/index.ts';
import { assetMap, assetProp } from '../../assets/assetMap.ts';
import type { MapNodeId } from '../../data/models.ts';
import { pageFrame } from '../shared.ts';

const mapPageStyles = `
.zt-page[data-page="Map"] {
  box-sizing: border-box;
  width: 100%;
  max-width: 480px;
  margin: 0 auto;
  padding: 28px 20px max(28px, env(safe-area-inset-bottom));
  background: var(--zt-paper, #F8EEDB);
  color: var(--zt-ink, #3B2920);
}
.zt-page[data-page="Map"] > .zt-page__title {
  margin: 0 0 24px;
  padding-left: 14px;
  border-left: 4px solid var(--zt-journey-orange, #E86B2A);
  font-size: 32px;
  line-height: 1.3;
}
.zt-page[data-page="Map"] > .zt-status-bar {
  display: grid;
  grid-template-columns: minmax(0, 1fr) auto;
  gap: 8px 12px;
  margin-bottom: 24px;
  padding: 16px;
  border: 1px solid rgba(115, 155, 86, .4);
  border-radius: 16px;
  background: rgba(115, 155, 86, .08);
}
.zt-page[data-page="Map"] .zt-status-bar__label { font-weight: 700; }
.zt-page[data-page="Map"] .zt-status-bar__progress {
  grid-column: 1 / -1;
  width: 100%;
  height: 10px;
  accent-color: var(--zt-field-green, #739B56);
}
.zt-page[data-page="Map"] > .zt-page__choices {
  display: grid;
  gap: 20px;
  margin: 0 0 24px;
  counter-reset: map-step;
}
.zt-page[data-page="Map"] .zt-map-stop {
  position: relative;
  padding-left: 52px;
  counter-increment: map-step;
}
.zt-page[data-page="Map"] .zt-map-stop::before {
  content: counter(map-step);
  box-sizing: border-box;
  position: absolute;
  top: 22px;
  left: 0;
  display: grid;
  place-items: center;
  width: 36px;
  height: 36px;
  border: 2px solid rgba(59, 41, 32, .25);
  border-radius: 50%;
  background: var(--zt-paper, #F8EEDB);
  color: var(--zt-ink, #3B2920);
  font-size: 20px;
  font-weight: 700;
}
.zt-page[data-page="Map"] .zt-map-stop:not(:last-child)::after {
  content: '';
  position: absolute;
  top: 66px;
  bottom: -34px;
  left: 17px;
  border-left: 2px dashed rgba(59, 41, 32, .25);
}
.zt-page[data-page="Map"] .zt-map-stop--current::before {
  border-color: var(--zt-journey-orange, #E86B2A);
  background: var(--zt-journey-orange, #E86B2A);
}
.zt-page[data-page="Map"] .zt-map-stop--complete::before {
  border-color: var(--zt-field-green, #739B56);
  background: var(--zt-field-green, #739B56);
}
.zt-page[data-page="Map"] .zt-map-stop--complete::after {
  border-color: var(--zt-field-green, #739B56);
  border-left-style: solid;
}
.zt-page[data-page="Map"] .zt-map-stop--story::before {
  border-color: var(--zt-sky-blue, #5B8FB9);
  background: var(--zt-sky-blue, #5B8FB9);
}
.zt-page[data-page="Map"] > .zt-button {
  box-sizing: border-box;
  width: 100%;
  min-height: 48px;
  padding: 12px 16px;
  border: 2px solid var(--zt-journey-orange, #E86B2A);
  border-radius: 14px;
  font-weight: 700;
  font-size: 20px;
  line-height: 1.5;
  touch-action: manipulation;
}
.zt-page[data-page="Map"] > .zt-button--secondary {
  margin-bottom: 12px;
  border-color: var(--zt-field-green, #739B56);
  background: var(--zt-paper, #F8EEDB);
  color: var(--zt-ink, #3B2920);
}
.zt-page[data-page="Map"] > .zt-button--primary {
  background: var(--zt-journey-orange, #E86B2A);
  color: var(--zt-ink, #3B2920);
}
.zt-page[data-page="Map"] > .zt-button:focus-visible {
  outline: 3px solid var(--zt-field-green, #739B56);
  outline-offset: 4px;
}
.zt-page[data-page="Map"] > .zt-button:active { filter: brightness(.95); }
@media (max-width: 359px) {
  .zt-page[data-page="Map"] { padding-inline: 12px; }
  .zt-page[data-page="Map"] .zt-map-stop { padding-left: 44px; }
}
`;

export default defineComponent({
  name: 'MapPage',
  setup() {
    const { nodes } = storeToRefs(useRouteStore());
    const router = useRouter();
    onMounted(() => {
      if (document.getElementById('zt-map-page-styles')) return;
      const style = document.createElement('style');
      style.id = 'zt-map-page-styles';
      style.textContent = mapPageStyles;
      document.head.appendChild(style);
    });
    function onNodeClick(id: MapNodeId): void {
      const node = nodes.value.find(node => node.id === id);
      if (!node || node.status === 'locked') return;
      // 缺少任务数据时仍进入该站入口，由任务页明确展示待补充状态。
      void router.push({ name: 'Mission', params: { missionId: node.missionId ?? node.id } });
    }
    return () => pageFrame('Map', [
      h(StatusBar, { label: '已完成节点', value: nodes.value.filter(node => node.status === 'complete').length, max: nodes.value.length }),
      h('ul', { class: 'zt-page__choices' }, nodes.value.map(node => h('li', {
        key: node.id, class: ['zt-map-stop', `zt-map-stop--${node.status}`],
      }, [h(MapNode, {
        name: node.name, status: node.status, ...assetProp('icon', assetMap.icons[node.id]), onClick: () => onNodeClick(node.id),
      })]))),
      h(Button, { text: '查看同行状态', variant: 'Secondary', onClick: () => { void router.push({ name: 'Status' }); } }),
      h(Button, { text: '查看同行档案', onClick: () => { void router.push({ name: 'Archive' }); } }),
    ]);
  },
});
