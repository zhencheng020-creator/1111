import { defineComponent, h, onMounted } from 'vue';
import { storeToRefs } from 'pinia';
import { useRouter } from 'vue-router';
import { routes } from '../../data/index.ts';
import { Button, RouteCard } from '../../components/index.ts';
import { useRouteStore, useUserStore } from '../../store/index.ts';
import { feedbackMessage, pageFrame, usePageFeedback } from '../shared.ts';

const routePageStyles = `
.zt-page[data-page="Route"] {
  box-sizing: border-box;
  width: 100%;
  max-width: 480px;
  margin: 0 auto;
  padding: 28px 20px max(28px, env(safe-area-inset-bottom));
  background: var(--zt-paper, #F8EEDB);
  color: var(--zt-ink, #3B2920);
}
.zt-page[data-page="Route"] > .zt-page__title {
  margin: 0 0 24px;
  padding-left: 14px;
  border-left: 4px solid var(--zt-journey-orange, #E86B2A);
  font-size: 32px;
  line-height: 1.3;
}
.zt-page[data-page="Route"] > .zt-page__choices { display: grid; gap: 16px; margin: 0 0 24px; }
.zt-page[data-page="Route"] > .zt-button {
  box-sizing: border-box;
  width: 100%;
  min-height: 48px;
  padding: 12px 16px;
  border: 2px solid var(--zt-journey-orange, #E86B2A);
  border-radius: 14px;
  font-weight: 700;
  font-size: 20px;
  line-height: 1.5;
  touch-action: manipulation;
}
.zt-page[data-page="Route"] > .zt-button--secondary {
  margin-bottom: 12px;
  border-color: var(--zt-field-green, #739B56);
  background: var(--zt-paper, #F8EEDB);
  color: var(--zt-ink, #3B2920);
}
.zt-page[data-page="Route"] > .zt-button--primary {
  background: var(--zt-journey-orange, #E86B2A);
  color: var(--zt-ink, #3B2920);
}
.zt-page[data-page="Route"] > .zt-button--disabled {
  border-color: rgba(59, 41, 32, .16);
  background: rgba(59, 41, 32, .06);
  color: var(--zt-ink, #3B2920);
  opacity: .55;
}
.zt-page[data-page="Route"] > .zt-button:focus-visible {
  outline: 3px solid var(--zt-field-green, #739B56);
  outline-offset: 4px;
}
.zt-page[data-page="Route"] > .zt-button:active:not(:disabled) { filter: brightness(.95); }
.zt-page[data-page="Route"] > [role="alert"] { margin: 0 0 16px; line-height: 1.5; }
@media (max-width: 359px) {
  .zt-page[data-page="Route"] { padding-inline: 12px; }
}
`;

export default defineComponent({
  name: 'RoutePage',
  setup() {
    const user = useUserStore();
    const { routeId } = storeToRefs(useRouteStore());
    const router = useRouter();
    const { feedback, run } = usePageFeedback();
    onMounted(() => {
      if (document.getElementById('zt-route-page-styles')) return;
      const style = document.createElement('style');
      style.id = 'zt-route-page-styles';
      style.textContent = routePageStyles;
      document.head.appendChild(style);
    });
    function onSelect(id: string): void {
      const item = routes.find(item => item.id === id);
      if (item) run(() => user.selectRoute(item.id));
    }
    return () => pageFrame('Route', [
      h('ul', { class: 'zt-page__choices' }, routes.map(item => h('li', { key: item.id }, [h(RouteCard, {
        id: item.id, name: item.name, time: `${item.durationMinutes.min}–${item.durationMinutes.max}分钟`,
        // 模型尚未定义难度；只呈现现有节点数量，不推测难度等级。
        difficulty: '待补充', description: `包含 ${item.nodeIds.length} 个同行节点。`,
        selected: routeId.value === item.id, onSelect,
      })]))),
      feedbackMessage(feedback.value),
      h(Button, { text: '返回伙伴选择', variant: 'Secondary', onClick: () => { void router.push({ name: 'Partner' }); } }),
      h(Button, { text: '进入地图', disabled: routeId.value === null, onClick: () => { void router.push({ name: 'Map' }); } }),
    ]);
  },
});
