import { defineComponent, h } from 'vue';
import { storeToRefs } from 'pinia';
import { useRouter } from 'vue-router';
import { Badge, Button, Card } from '../../components/index.ts';
import { useResourceStore, usePartnerStore } from '../../store/index.ts';
import { badges } from '../../data/index.ts';
import { assetMap, assetProp, catalogAssetPath, resolveAssetUrl } from '../../assets/assetMap.ts';
import AssetImage from '../../assets/AssetImage.ts';
import { detailList, pageFrame } from '../shared.ts';

export default defineComponent({
  name: 'StatusPage',
  setup() {
    const resources = useResourceStore();
    const { energy, food, medical, badge, earnedBadgeIds } = storeToRefs(resources);
    const { partner, needsCare } = storeToRefs(usePartnerStore());
    const router = useRouter();
    return () => pageFrame('Status', [
      h(Card, {}, { default: () => [h('h2', '人物与团队'), detailList([
        ['人物体力', energy.value], ['粮食', food.value], ['医疗资源', medical.value], ['徽章数量', badge.value],
      ])] }),
      partner.value ? h(Card, {}, { default: () => [
        h('h2', partner.value!.name),
        h(AssetImage, { src: resolveAssetUrl(assetMap.characters[partner.value!.id]) ?? '', alt: partner.value!.name }),
        detailList([['伙伴体力', partner.value!.energy], ['舒适度', partner.value!.comfort], ['信任', partner.value!.trust]]),
        needsCare.value ? h('p', { role: 'status' }, '伙伴需要照顾。') : null,
      ] }) : null,
      ...earnedBadgeIds.value.map(id => {
        const definition = badges.find(item => item.id === id);
        return definition ? h(Badge, { key: id, name: definition.name,
          ...assetProp('icon', assetMap.badges[id] ?? catalogAssetPath(definition.assetPath)), unlocked: true }) : null;
      }),
      h(Button, { text: '返回地图', variant: 'Secondary', onClick: () => { void router.push({ name: 'Map' }); } }),
    ]);
  },
});
