import { defineComponent, h, onMounted } from 'vue';
import { storeToRefs } from 'pinia';
import { useRouter } from 'vue-router';
import { identities } from '../../data/index.ts';
import { Button, IdentityCard } from '../../components/index.ts';
import { useUserStore } from '../../store/index.ts';
import { assetMap, assetProp } from '../../assets/assetMap.ts';
import { feedbackMessage, pageFrame, usePageFeedback } from '../shared.ts';

// 仅限定 Identity 页，不改变 pageFrame、全局样式或其他页面。
const identityPageStyles = `
.zt-page[data-page="Identity"] {
  box-sizing: border-box;
  width: 100%;
  max-width: 480px;
  margin: 0 auto;
  padding: 28px 20px max(28px, env(safe-area-inset-bottom));
  background: #F8EEDB;
  color: #3B2920;
}
.zt-page[data-page="Identity"] > .zt-page__title {
  margin: 0 0 24px;
  padding-left: 14px;
  border-left: 4px solid #E86B2A;
  font-size: 32px;
  line-height: 1.3;
}
.zt-page[data-page="Identity"] > .zt-page__choices {
  display: grid;
  gap: 16px;
  margin: 0 0 24px;
}
.zt-page[data-page="Identity"] > .zt-button {
  box-sizing: border-box;
  width: calc(50% - 6px);
  min-height: 48px;
  padding: 12px 16px;
  border: 2px solid #E86B2A;
  border-radius: 14px;
  font-weight: 700;
  font-size: 20px;
  line-height: 1.5;
  touch-action: manipulation;
}
.zt-page[data-page="Identity"] > .zt-button--secondary {
  margin-right: 12px;
  border-color: #739B56;
  background: #F8EEDB;
  color: #3B2920;
}
.zt-page[data-page="Identity"] > .zt-button--primary {
  background: #E86B2A;
  color: #3B2920;
}
.zt-page[data-page="Identity"] > .zt-button--disabled {
  border-color: rgba(59, 41, 32, .16);
  background: rgba(59, 41, 32, .06);
  color: #3B2920;
  opacity: .55;
}
.zt-page[data-page="Identity"] > .zt-button:focus-visible {
  outline: 3px solid #739B56;
  outline-offset: 4px;
}
.zt-page[data-page="Identity"] > .zt-button:active:not(:disabled) {
  filter: brightness(.95);
}
.zt-page[data-page="Identity"] > [role="alert"] {
  margin: 0 0 16px;
  color: #3B2920;
  line-height: 1.5;
}
@media (max-width: 359px) {
  .zt-page[data-page="Identity"] { padding-inline: 12px; }
}
`;

export default defineComponent({
  name: 'IdentityPage',
  setup() {
    const user = useUserStore();
    const { identity } = storeToRefs(user);
    const router = useRouter();
    const { feedback, run } = usePageFeedback();
    onMounted(() => {
      if (document.getElementById('zt-identity-page-styles')) return;
      const style = document.createElement('style');
      style.id = 'zt-identity-page-styles';
      style.textContent = identityPageStyles;
      document.head.appendChild(style);
    });
    function onSelect(id: string): void {
      const item = identities.find(item => item.id === id);
      if (item) run(() => user.selectIdentity(item.id));
    }
    return () => pageFrame('Identity', [
      h('ul', { class: 'zt-page__choices' }, identities.map(item => h('li', { key: item.id }, [h(IdentityCard, {
        id: item.id, name: item.name, description: item.ability, skill: item.ability,
        ...assetProp('icon', assetMap.identity[item.id]), selected: identity.value === item.id, onSelect,
      })]))),
      feedbackMessage(feedback.value),
      h(Button, { text: '返回首页', variant: 'Secondary', onClick: () => { void router.push({ name: 'Home' }); } }),
      h(Button, { text: '下一步', disabled: identity.value === null, onClick: () => { void router.push({ name: 'Partner' }); } }),
    ]);
  },
});
