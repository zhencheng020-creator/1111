import { defineComponent, h, onMounted, ref } from 'vue';
import type { PropType } from 'vue';
import Card from '../Card/index.ts';
import type { PartnerCardProps } from '../props.ts';
import { partnerCardStyles } from './styles.ts';

export default defineComponent({
  name: 'PartnerCard',
  props: {
    id: { type: String, required: true },
    name: { type: String, required: true },
    type: { type: String, required: true },
    avatar: String,
    energy: { type: Number, required: true },
    comfort: { type: Number, required: true },
    trust: { type: Number, required: true },
    selected: { type: Boolean, default: false },
    onSelect: Function as PropType<PartnerCardProps['onSelect']>,
  },
  setup(props) {
    const failedAvatar = ref<string | null>(null);
    onMounted(() => {
      if (document.getElementById('zt-partner-card-styles')) return;
      const style = document.createElement('style');
      style.id = 'zt-partner-card-styles';
      style.textContent = partnerCardStyles;
      document.head.appendChild(style);
    });
    return () => {
      const placeholder = !props.avatar || failedAvatar.value === props.avatar;
      return h(Card, {
        as: 'button', selected: props.selected,
        class: ['zt-partner-card', { 'zt-partner-card--selected': props.selected }],
        'data-figma': 'Card/Partner',
        'aria-pressed': props.selected,
        onClick: () => props.onSelect?.(props.id),
      }, { default: () => [
        h('span', { class: 'zt-partner-card__main' }, [
          h('span', { class: 'zt-partner-card__illustration', 'data-asset-src': props.avatar, 'aria-hidden': 'true' },
            placeholder ? [
              h('span', { class: 'zt-partner-card__placeholder-name' }, props.name),
              h('span', { class: 'zt-partner-card__placeholder-label' }, '插画占位'),
            ] : [h('img', {
              src: props.avatar, alt: props.name, class: 'zt-avatar',
              onError: () => { failedAvatar.value = props.avatar ?? null; },
            })]),
          h('span', { class: 'zt-partner-card__content' }, [
            h('span', { class: 'zt-card__title zt-partner-card__name' }, props.name),
            h('span', { class: 'zt-card__body zt-partner-card__type' }, props.type),
          ]),
          h('span', { class: 'zt-partner-card__check', 'aria-hidden': 'true' }, props.selected ? '✓' : ''),
        ]),
        h('span', { class: 'zt-partner-card__status' }, [
          ['energy', '体力', props.energy],
          ['comfort', '安心', props.comfort],
          ['trust', '信任', props.trust],
        ].map(([key, label, value]) => h('span', {
          class: ['zt-partner-card__metric', `zt-partner-card__metric--${key}`], 'data-status': key,
        }, [
          h('span', { class: 'zt-partner-card__metric-label' }, label),
          h('span', { class: 'zt-partner-card__metric-value' }, String(value)),
        ]))),
        h('span', { class: 'zt-partner-card__footer' }, [
          h('span', { class: 'zt-partner-card__hint' }, '同行伙伴'),
          h('span', { class: 'zt-partner-card__state' }, props.selected ? '已选择' : '点击选择'),
        ]),
      ] });
    };
  },
});
