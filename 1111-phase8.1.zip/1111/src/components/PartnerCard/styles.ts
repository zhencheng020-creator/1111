/** 仅作用于 PartnerCard，沿用 Phase 7.1 的卡片语言。 */
export const partnerCardStyles = `
button.zt-card.zt-partner-card {
  --partner-orange: #E86B2A;
  --partner-green: #739B56;
  --partner-blue: #5B8FB9;
  --partner-paper: #F8EEDB;
  --partner-ink: #3B2920;
  box-sizing: border-box;
  display: flex;
  flex-direction: column;
  gap: 16px;
  width: 100%;
  padding: 20px;
  border: 2px solid rgba(59, 41, 32, .16);
  border-radius: 20px;
  background: var(--partner-paper);
  color: var(--partner-ink);
  font-family: inherit;
  text-align: left;
  cursor: pointer;
  touch-action: manipulation;
  -webkit-tap-highlight-color: transparent;
  box-shadow: 0 3px 0 rgba(59, 41, 32, .06);
  transition: border-color 160ms ease, box-shadow 160ms ease, transform 160ms ease;
}
button.zt-card.zt-partner-card--selected {
  border-color: var(--partner-orange);
  box-shadow: 0 4px 16px rgba(232, 107, 42, .12);
}
.zt-partner-card__main {
  display: grid;
  grid-template-columns: 104px minmax(0, 1fr) 24px;
  align-items: start;
  gap: 14px;
}
.zt-partner-card__illustration {
  box-sizing: border-box;
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  gap: 8px;
  width: 104px;
  height: 112px;
  overflow: hidden;
  border: 1px dashed var(--partner-blue);
  border-radius: 16px;
  background: rgba(91, 143, 185, .1);
  color: var(--partner-ink);
}
.zt-partner-card__placeholder-name {
  font-size: 32px;
  font-weight: 700;
  line-height: 1.3;
}
.zt-partner-card__placeholder-label {
  font-size: 12px;
  line-height: 1.4;
  opacity: .7;
}
.zt-partner-card__illustration img {
  display: block;
  width: 100%;
  height: 100%;
  object-fit: contain;
}
.zt-partner-card__content {
  display: flex;
  flex-direction: column;
  align-items: start;
  gap: 10px;
  padding-top: 8px;
  min-width: 0;
  overflow-wrap: anywhere;
}
.zt-partner-card .zt-partner-card__name {
  color: var(--partner-ink);
  font-size: 24px;
  font-weight: 700;
  line-height: 1.3;
}
.zt-partner-card__type {
  padding: 4px 10px;
  border: 1px solid rgba(115, 155, 86, .4);
  border-radius: 8px;
  background: rgba(115, 155, 86, .12);
  color: var(--partner-ink);
  font-size: 12px;
  line-height: 1.5;
}
.zt-partner-card__check {
  box-sizing: border-box;
  display: grid;
  place-items: center;
  width: 24px;
  height: 24px;
  border: 2px solid rgba(59, 41, 32, .25);
  border-radius: 50%;
  color: var(--partner-ink);
  font-size: 16px;
  font-weight: 700;
  line-height: 1;
}
.zt-partner-card--selected .zt-partner-card__check {
  border-color: var(--partner-orange);
  background: var(--partner-orange);
}
.zt-partner-card__status {
  display: grid;
  grid-template-columns: repeat(3, minmax(0, 1fr));
  gap: 8px;
}
.zt-partner-card__metric {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 4px;
  min-width: 0;
  padding: 10px 6px;
  border-radius: 12px;
  color: var(--partner-ink);
}
.zt-partner-card__metric--energy { background: rgba(232, 107, 42, .08); }
.zt-partner-card__metric--comfort { background: rgba(115, 155, 86, .12); }
.zt-partner-card__metric--trust { background: rgba(91, 143, 185, .1); }
.zt-partner-card__metric-label { font-size: 12px; line-height: 1.5; }
.zt-partner-card__metric-value {
  max-width: 100%;
  font-size: 24px;
  font-weight: 700;
  line-height: 1.3;
  font-variant-numeric: tabular-nums;
  overflow-wrap: anywhere;
}
.zt-partner-card__footer {
  display: flex;
  justify-content: space-between;
  align-items: center;
  gap: 12px;
  padding-top: 12px;
  border-top: 1px solid rgba(59, 41, 32, .12);
  font-size: 12px;
  line-height: 1.5;
}
.zt-partner-card__hint { opacity: .65; }
.zt-partner-card__state { font-weight: 700; white-space: nowrap; }
@media (hover: hover) {
  button.zt-card.zt-partner-card:hover {
    border-color: var(--partner-orange);
    transform: translateY(-2px);
  }
}
button.zt-card.zt-partner-card:active { transform: scale(.985); box-shadow: none; }
button.zt-card.zt-partner-card:focus-visible {
  outline: 3px solid var(--partner-green);
  outline-offset: 4px;
}
@media (max-width: 359px) {
  button.zt-card.zt-partner-card { padding: 16px; }
  .zt-partner-card__main { grid-template-columns: 88px minmax(0, 1fr) 24px; gap: 10px; }
  .zt-partner-card__illustration { width: 88px; height: 100px; }
}
@media (prefers-reduced-motion: reduce) {
  button.zt-card.zt-partner-card { transition: none; }
  button.zt-card.zt-partner-card:hover,
  button.zt-card.zt-partner-card:active { transform: none; }
}
`;
