import { defineComponent, h, onMounted, ref } from 'vue';
import type { PropType } from 'vue';
import type { MapNodeStatus } from '../../data/models.ts';
import type { MapNodeProps } from '../props.ts';
import { mapNodeStyles } from './styles.ts';

const statusLabels: Record<MapNodeStatus, string> = {
  locked: '未解锁', current: '当前节点', complete: '已完成', story: '故事节点',
};
const statusMarks: Record<MapNodeStatus, string> = {
  locked: '锁', current: '→', complete: '✓', story: '书',
};

export default defineComponent({
  name: 'MapNode',
  props: {
    name: { type: String, required: true },
    status: { type: String as PropType<MapNodeStatus>, required: true },
    icon: String,
    onClick: Function as PropType<MapNodeProps['onClick']>,
  },
  setup(props) {
    const failedIcon = ref<string | null>(null);
    onMounted(() => {
      if (document.getElementById('zt-map-node-styles')) return;
      const style = document.createElement('style');
      style.id = 'zt-map-node-styles';
      style.textContent = mapNodeStyles;
      document.head.appendChild(style);
    });
    return () => h('button', {
      type: 'button', class: ['zt-map-node', `zt-map-node--${props.status}`],
      disabled: props.status === 'locked',
      'data-figma': 'MapNode', 'data-variant': props.status,
      'aria-label': `${props.name}，${statusLabels[props.status]}`,
      'aria-current': props.status === 'current' ? 'step' : undefined,
      onClick: () => { if (props.status !== 'locked') props.onClick?.(); },
    }, [
      h('span', { class: 'zt-map-node__main' }, [
        h('span', { class: 'zt-map-node__mark', 'aria-hidden': 'true' }, [
          props.icon && failedIcon.value !== props.icon ? h('img', {
            src: props.icon, alt: '', class: 'zt-icon',
            onError: () => { failedIcon.value = props.icon ?? null; },
          }) : statusMarks[props.status],
        ]),
        h('span', { class: 'zt-card__title zt-map-node__name' }, props.name),
      ]),
      h('span', { class: 'zt-map-node__footer' }, [
        h('span', { class: 'zt-caption zt-map-node__status' }, statusLabels[props.status]),
        h('span', { class: 'zt-map-node__hint', 'aria-hidden': 'true' },
          props.status === 'locked' ? '尚未开放' : props.status === 'current' ? '点击探索' : '查看节点'),
      ]),
    ]);
  },
});
