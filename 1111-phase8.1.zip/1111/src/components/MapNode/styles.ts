/** 节点状态由 Props 决定；样式不参与解锁或进度计算。 */
export const mapNodeStyles = `
button.zt-map-node {
  --node-orange: var(--zt-journey-orange, #E86B2A);
  --node-green: var(--zt-field-green, #739B56);
  --node-blue: var(--zt-sky-blue, #5B8FB9);
  --node-paper: var(--zt-paper, #F8EEDB);
  --node-ink: var(--zt-ink, #3B2920);
  --node-accent: var(--node-ink);
  box-sizing: border-box;
  display: flex;
  flex-direction: column;
  gap: 14px;
  width: 100%;
  min-height: 112px;
  padding: 16px;
  border: 2px solid rgba(59, 41, 32, .16);
  border-radius: 18px;
  background: var(--node-paper);
  color: var(--node-ink);
  font-family: inherit;
  text-align: left;
  cursor: pointer;
  touch-action: manipulation;
  -webkit-tap-highlight-color: transparent;
  box-shadow: 0 3px 0 rgba(59, 41, 32, .06);
  transition: border-color 160ms ease, box-shadow 160ms ease, transform 160ms ease;
}
button.zt-map-node--locked { border-style: dashed; cursor: not-allowed; box-shadow: none; }
button.zt-map-node--current {
  --node-accent: var(--node-orange);
  border-color: var(--node-orange);
  box-shadow: 0 4px 16px rgba(232, 107, 42, .12);
}
button.zt-map-node--complete { --node-accent: var(--node-green); border-color: var(--node-green); }
button.zt-map-node--story { --node-accent: var(--node-blue); border-color: var(--node-blue); }
.zt-map-node__main { display: flex; align-items: center; gap: 12px; }
.zt-map-node__mark {
  box-sizing: border-box;
  display: grid;
  place-items: center;
  flex-shrink: 0;
  width: 36px;
  height: 36px;
  border: 1px solid rgba(59, 41, 32, .2);
  border-radius: 12px;
  color: var(--node-ink);
  background: var(--node-paper);
  font-size: 20px;
  font-weight: 700;
  line-height: 1;
  overflow: hidden;
}
.zt-map-node--current .zt-map-node__mark { background: rgba(232, 107, 42, .1); border-color: var(--node-orange); }
.zt-map-node--complete .zt-map-node__mark { background: rgba(115, 155, 86, .12); border-color: var(--node-green); }
.zt-map-node--story .zt-map-node__mark { background: rgba(91, 143, 185, .1); border-color: var(--node-blue); }
.zt-map-node__mark img { display: block; width: 100%; height: 100%; object-fit: contain; }
.zt-map-node .zt-map-node__name {
  min-width: 0;
  color: var(--node-ink);
  font-size: 20px;
  font-weight: 700;
  line-height: 1.4;
  overflow-wrap: anywhere;
}
.zt-map-node__footer {
  display: flex;
  justify-content: space-between;
  align-items: center;
  flex-wrap: wrap;
  gap: 8px;
  font-size: 12px;
  line-height: 1.5;
}
.zt-map-node__status { display: inline-flex; align-items: center; gap: 6px; font-weight: 700; }
.zt-map-node__status::before {
  content: '';
  width: 7px;
  height: 7px;
  border-radius: 50%;
  background: var(--node-accent);
}
.zt-map-node__hint { opacity: .7; }
@media (hover: hover) {
  button.zt-map-node:not(:disabled):hover { transform: translateY(-2px); }
}
button.zt-map-node:not(:disabled):active { transform: scale(.985); box-shadow: none; }
button.zt-map-node:focus-visible { outline: 3px solid var(--node-green); outline-offset: 4px; }
@media (prefers-reduced-motion: reduce) {
  button.zt-map-node { transition: none; }
  button.zt-map-node:not(:disabled):hover,
  button.zt-map-node:not(:disabled):active { transform: none; }
}
`;
