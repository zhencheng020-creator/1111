/** 样式只作用于 IdentityCard；不改动基础 Card 或其他卡片。 */
export const identityCardStyles = `
button.zt-card.zt-identity-card {
  --identity-orange: #E86B2A;
  --identity-green: #739B56;
  --identity-paper: #F8EEDB;
  --identity-ink: #3B2920;
  box-sizing: border-box;
  display: flex;
  flex-direction: column;
  gap: 16px;
  width: 100%;
  padding: 20px;
  border: 2px solid rgba(59, 41, 32, .16);
  border-radius: 20px;
  background: var(--identity-paper);
  color: var(--identity-ink);
  font-family: inherit;
  text-align: left;
  cursor: pointer;
  touch-action: manipulation;
  -webkit-tap-highlight-color: transparent;
  box-shadow: 0 3px 0 rgba(59, 41, 32, .06);
  transition: border-color 160ms ease, box-shadow 160ms ease, transform 160ms ease;
}
button.zt-card.zt-identity-card--selected {
  border-color: var(--identity-orange);
  box-shadow: 0 4px 16px rgba(232, 107, 42, .12);
}
.zt-identity-card__main {
  display: grid;
  grid-template-columns: 64px minmax(0, 1fr) 24px;
  align-items: start;
  gap: 14px;
}
.zt-identity-card__portrait {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 6px;
  min-width: 0;
}
.zt-identity-card__icon {
  box-sizing: border-box;
  display: grid;
  place-items: center;
  width: 64px;
  height: 64px;
  overflow: hidden;
  border: 1px dashed rgba(232, 107, 42, .55);
  border-radius: 16px;
  background: rgba(232, 107, 42, .08);
  color: var(--identity-ink);
  font-size: 24px;
  font-weight: 700;
}
.zt-identity-card__icon img {
  display: block;
  width: 100%;
  height: 100%;
  object-fit: contain;
}
.zt-identity-card__placeholder-label {
  color: var(--identity-ink);
  font-size: 12px;
  line-height: 1.4;
  opacity: .65;
}
.zt-identity-card__content {
  display: flex;
  flex-direction: column;
  gap: 6px;
  min-width: 0;
  overflow-wrap: anywhere;
}
.zt-identity-card .zt-identity-card__name {
  margin: 0;
  color: var(--identity-ink);
  font-size: 24px;
  font-weight: 700;
  line-height: 1.3;
}
.zt-identity-card--selected .zt-identity-card__name {
  color: var(--identity-ink);
}
.zt-identity-card__ability-label {
  align-self: start;
  padding: 3px 8px;
  border-radius: 6px;
  background: rgba(115, 155, 86, .12);
  color: var(--identity-ink);
  font-size: 12px;
  font-weight: 700;
  line-height: 1.4;
}
.zt-identity-card__description {
  color: var(--identity-ink);
  font-size: 16px;
  line-height: 1.5;
}
.zt-identity-card__skill {
  align-self: start;
  padding: 4px 8px;
  border: 1px solid rgba(115, 155, 86, .4);
  border-radius: 8px;
  color: var(--identity-ink);
  background: rgba(115, 155, 86, .12);
  font-size: 12px;
  line-height: 1.5;
}
.zt-identity-card__check {
  box-sizing: border-box;
  display: grid;
  place-items: center;
  width: 24px;
  height: 24px;
  border: 2px solid rgba(59, 41, 32, .25);
  border-radius: 50%;
  color: var(--identity-ink);
  font-size: 16px;
  font-weight: 700;
  line-height: 1;
}
.zt-identity-card--selected .zt-identity-card__check {
  border-color: var(--identity-orange);
  background: var(--identity-orange);
}
.zt-identity-card__footer {
  display: flex;
  justify-content: space-between;
  align-items: center;
  gap: 12px;
  padding-top: 12px;
  border-top: 1px solid rgba(59, 41, 32, .12);
  font-size: 12px;
  line-height: 1.5;
}
.zt-identity-card__hint {
  color: var(--identity-ink);
  opacity: .65;
}
.zt-identity-card__state {
  color: var(--identity-ink);
  font-weight: 700;
  white-space: nowrap;
}
.zt-identity-card--selected .zt-identity-card__state {
  color: var(--identity-ink);
}
@media (hover: hover) {
  button.zt-card.zt-identity-card:hover {
    border-color: var(--identity-orange);
    transform: translateY(-2px);
  }
}
button.zt-card.zt-identity-card:active {
  transform: scale(.985);
  box-shadow: none;
}
button.zt-card.zt-identity-card:focus-visible {
  outline: 3px solid var(--identity-green);
  outline-offset: 4px;
}
@media (prefers-reduced-motion: reduce) {
  button.zt-card.zt-identity-card { transition: none; }
  button.zt-card.zt-identity-card:hover,
  button.zt-card.zt-identity-card:active { transform: none; }
}
`;
