import { defineComponent, h, onMounted, ref } from 'vue';
import type { PropType } from 'vue';
import Card from '../Card/index.ts';
import type { IdentityCardProps } from '../props.ts';
import { identityCardStyles } from './styles.ts';

export default defineComponent({
  name: 'IdentityCard',
  props: {
    id: { type: String, required: true },
    name: { type: String, required: true },
    description: { type: String, required: true },
    skill: { type: String, required: true },
    icon: String,
    selected: { type: Boolean, default: false },
    onSelect: Function as PropType<IdentityCardProps['onSelect']>,
  },
  setup(props) {
    const failedIcon = ref<string | null>(null);
    // 保留现有 TS render 结构；每个文档只注入一次组件样式。
    onMounted(() => {
      if (document.getElementById('zt-identity-card-styles')) return;
      const style = document.createElement('style');
      style.id = 'zt-identity-card-styles';
      style.textContent = identityCardStyles;
      document.head.appendChild(style);
    });
    return () => {
      const placeholder = !props.icon || failedIcon.value === props.icon;
      return h(Card, {
        as: 'button', selected: props.selected,
        class: ['zt-identity-card', { 'zt-identity-card--selected': props.selected }],
        'data-figma': 'Card/Identity',
        'aria-pressed': props.selected,
        onClick: () => props.onSelect?.(props.id),
      }, { default: () => [
        h('span', { class: 'zt-identity-card__main' }, [
          h('span', { class: 'zt-identity-card__portrait', 'aria-hidden': 'true' }, [
            h('span', { class: 'zt-identity-card__icon', 'data-asset-src': props.icon }, [
              placeholder ? h('span', props.name.slice(0, 1)) : h('img', {
                src: props.icon, alt: '', class: 'zt-icon',
                onError: () => { failedIcon.value = props.icon ?? null; },
              }),
            ]),
            placeholder ? h('span', { class: 'zt-identity-card__placeholder-label' }, '图标占位') : null,
          ]),
          h('span', { class: 'zt-identity-card__content' }, [
            h('span', { class: 'zt-card__title zt-identity-card__name' }, props.name),
            h('span', { class: 'zt-identity-card__ability-label' }, '身份能力'),
            h('span', { class: 'zt-card__body zt-identity-card__description' }, props.description),
            // 现有页面两项文案相同，只展示一次，独立 skill 文案仍正常显示。
            props.skill && props.skill !== props.description
              ? h('span', { class: 'zt-card__caption zt-identity-card__skill' }, props.skill) : null,
          ]),
          h('span', { class: 'zt-identity-card__check', 'aria-hidden': 'true' }, props.selected ? '✓' : ''),
        ]),
        h('span', { class: 'zt-identity-card__footer' }, [
          h('span', { class: 'zt-identity-card__hint' }, '同行身份'),
          h('span', { class: 'zt-identity-card__state' }, props.selected ? '已选择' : '点击选择'),
        ]),
      ] });
    };
  },
});
