# 征途生灵组件系统 · Step 4

使用 Vue 3 Composition API + TypeScript：组件通过 `defineComponent` 声明，在 `setup(props)` 中返回渲染函数，直接读取响应式 Props。组件只展示 Props、回传回调，不保存选择、不执行任务效果、不更新业务 store。`src/pages/` 和路由保持不变。

## 目录结构及代码

```text
components/
├── Button/index.ts
├── Card/index.ts
├── IdentityCard/index.ts
├── PartnerCard/index.ts
├── RouteCard/index.ts
├── MissionCard/index.ts
├── StatusBar/index.ts
├── MapNode/index.ts
├── Badge/index.ts
├── AchievementBadge/index.ts  # Badge 的兼容别名
├── design-system/
│   ├── tokens.css              # 原需求颜色和字体令牌
│   └── components.css          # 组件样式，不影响页面全局排版
├── examples/
│   └── ComponentExamples.ts    # 已通过挂载测试的全部组件示例
├── props.ts                   # 全部公开 Props 类型
├── index.ts                   # 统一导出
├── README.md
├── StoryCard/.gitkeep          # 本次未要求，保留原目录
├── ArchiveCard/.gitkeep
├── ResourceBar/.gitkeep
├── PartnerStatus/.gitkeep
└── ProgressBar/.gitkeep
```

| 代码 | Figma 对应名称 | 变体或状态 |
| --- | --- | --- |
| [Button](Button/index.ts) | Button | Primary / Secondary / Disabled |
| [Card](Card/index.ts) | Card | 基础容器，支持默认插槽 |
| [IdentityCard](IdentityCard/index.ts) | Card/Identity | selected |
| [PartnerCard](PartnerCard/index.ts) | Card/Partner | selected |
| [RouteCard](RouteCard/index.ts) | Card/Route | selected |
| [MissionCard](MissionCard/index.ts) | Card/Mission | choices |
| [StatusBar](StatusBar/index.ts) | StatusBar | value / max |
| [MapNode](MapNode/index.ts) | MapNode | locked / current / complete / story |
| [Badge](Badge/index.ts) | Badge | unlocked |

`Card/Partner`、`Card/Route`、`Card/Mission`、`MapNode`、`StatusBar`、`Badge` 沿用已提供的 Figma 映射；`Card/Identity` 按相同命名约定预留，具体 Figma 文件尚未提供。根元素上的 `data-figma` 可用于核对组件名称，`data-variant` 可用于核对变体。

## 设计令牌

颜色仅使用 Journey Orange `#E86B2A`、Field Green `#739B56`、Sky Blue `#5B8FB9`、Paper `#F8EEDB`、Ink `#3B2920`。字体层级为 Title 32px Bold、Heading 24px Bold、Body 16px Regular、Caption 12px Regular。

Primary 使用 Orange，Secondary 使用 Green，Disabled 使用 Paper；地图 current / complete / story 分别使用 Orange / Green / Blue。卡片选中状态以 Orange 标题及 `aria-pressed` 标识。

没有具体 Figma 布局和尺寸数据，当前只使用已知令牌、必要的内容结构及样式重置，没有新增插画、渐变、阴影、字体族或自定义间距尺寸。未提供头像或图标时不渲染图片，不生成替代素材。StatusBar 使用原生 `progress`，实际形状随浏览器变化，待具体设计稿提供后再精确对齐。

在 Vue 应用入口导入一次样式：

```ts
import './components/design-system/components.css';
```

当前是 Vue DOM 组件原型；接入 uni-app / 微信小程序时仍需要平台模板、导航及生命周期适配，本次未做平台集成。

## Props 和回调

完整类型见 [props.ts](props.ts)。字符串作为普通文本渲染，不使用原始 HTML。

- Button：`text` 必填，`variant` 默认 Primary，`disabled` 默认 false，`onClick()`。`disabled=true` 或 Disabled 变体均阻止点击，并显示 Disabled 变体。
- Card：默认插槽承载内容；可选 `as` 为 div（默认）或 button、`selected`、`onClick()`。用作选择卡片时根元素为原生按钮。
- IdentityCard：`id / name / description / skill` 必填；可选 `icon / selected / onSelect(id)`。
- PartnerCard：`id / name / type / energy / comfort / trust` 必填；可选 `avatar / selected / onSelect(id)`。
- RouteCard：`id / name / time / difficulty / description` 必填；可选 `selected / onSelect(id)`。`time`、`difficulty` 为展示字符串，不自行推导难度机制。
- MissionCard：`title / description / choices` 必填，choices 使用数据模型 `MissionChoice[]`；可选 `onChoice(choice)`，回传完整方案，不执行 effect。
- StatusBar：`label / value / max` 必填，可选 `icon`。展示值限制在 0–max；无效 value 按 0 显示，无效或非正 max 按 1 显示；不修改原始数据。
- MapNode：`name / status` 必填，可选 `icon / onClick()`。locked 使用原生 disabled 并阻止回调，其余三个状态可点击。complete 与数据模型一致。
- Badge：`name / unlocked` 必填，可选 `icon`。显示已解锁或未解锁，不包含奖励规则；AchievementBadge 导出指向相同组件。

`selected` 默认 false，由使用方传入。点击只回传 ID，使用方改变 Props 后组件才更新选中显示。所有素材参数均为已有图片的 URL。

## 每个组件的使用示例

以下模板片段可用于后续 Vue 页面。它们仅示范组件 API，不代表已经接入当前页面。`onStart`、`onSelect`、`onChoice`、`onNodeClick` 为使用方提供的回调。

统一导入：

```ts
import {
  Button, Card, IdentityCard, PartnerCard, RouteCard,
  MissionCard, StatusBar, MapNode, Badge,
} from './components/index.ts';
import { missions } from './data/index.ts';
```

Button：

```vue
<Button text="开始同行" variant="Primary" :onClick="onStart" />
<Button text="返回" variant="Secondary" :onClick="onBack" />
<Button text="暂不可用" variant="Disabled" disabled />
```

Card：

```vue
<Card><span>基础卡片内容</span></Card>
```

IdentityCard：

```vue
<IdentityCard
  id="support" name="后勤员" description="资源管理" skill="资源管理"
  :selected="false" :onSelect="onSelect"
/>
```

PartnerCard：

```vue
<PartnerCard
  id="xiaowei" name="小卫" type="探索型"
  :energy="5" :comfort="5" :trust="5"
  :selected="false" :onSelect="onSelect"
/>
```

RouteCard：

```vue
<RouteCard
  id="easy" name="轻体验线" time="40–50分钟"
  difficulty="难度待补充" description="同行路线"
  :selected="false" :onSelect="onSelect"
/>
```

MissionCard：

```vue
<MissionCard
  :title="missions[0].title" :description="missions[0].description"
  :choices="missions[0].choices" :onChoice="onChoice"
/>
```

StatusBar：

```vue
<StatusBar label="伙伴信任" :value="5" :max="5" />
```

MapNode：

```vue
<MapNode name="同行启程站" status="current" :onClick="onNodeClick" />
<MapNode name="草地补给站" status="locked" :onClick="onNodeClick" />
<MapNode name="雪山挑战站" status="complete" :onClick="onNodeClick" />
<MapNode name="无声伙伴故事站" status="story" :onClick="onNodeClick" />
```

Badge（仅展示状态，不属于正式徽章目录）：

```vue
<Badge name="徽章示例" :unlocked="false" />
<Badge name="徽章示例" :unlocked="true" />
```

可实际挂载的完整 TypeScript 示例见 [ComponentExamples.ts](examples/ComponentExamples.ts)。例如在后续 Vue 挂载入口中使用 `createApp(ComponentExamples, { onAction }).mount(container)`，并导入上述 CSS。本次没有新增页面或应用挂载入口。

## 验证

```sh
npm run typecheck
npm test
```

组件测试实际挂载 Vue 组件，验证 Props 展示、响应更新、选中回调、禁用和锁定行为、任务方案回传、进度范围、Badge 状态、示例挂载及文本转义；同时保留原有数据与路由测试。测试使用模拟 DOM，不代表完成 Figma 视觉比对或小程序真机验证。
