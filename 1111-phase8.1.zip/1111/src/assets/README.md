# 视觉资产接入

本轮已完成目录、统一映射、静态文件同步和缺图 fallback 接入。项目中尚未提供真实视觉素材，因此还不能验收真实图片的显示效果。

## 目录

```text
src/assets/
  characters/          # xiaowei、chifeng、feiyu、xiaotuo、aniu
  identity/            # support、scout、medical、record
  backgrounds/         # home、identity、partner、route、map、mission、status、archive
  icons/               # mission、mission-complete、选项 ID、地图节点 ID
  badges/              # 对应已有徽章 ID；未添加任何徽章业务定义
  stories/             # 保留原有故事素材接口
  scenes/              # 保留原有目录
  assetMap.ts          # 统一映射及缺失诊断
  assetManifest.ts     # 同步脚本生成的实际文件清单
  AssetImage.ts        # 图片加载/解码失败时渲染 fallback
  asset-check.json     # 当前缺图检查结果
```

## 导入已有素材

将已有原图放入对应目录，文件名使用上述 ID。支持 PNG、JPG、JPEG、WebP、GIF、SVG、AVIF；映射优先使用实际存在的文件，未提供文件时仅保留预期路径，不创建破图请求。

运行 `npm run assets:sync`，会将 `src/assets` 中已有图片按原目录逐字节复制到 `public/assets`，供开发和生产构建使用。`npm run dev`、`npm run build`、`npm test` 已有的前置脚本都会执行同步。开发服务运行期间导入新素材后，应重新运行同步。

同步记录位于 `public/assets/.source-sync.json`。不会覆盖与源文件不同且未由本脚本管理的 public 文件；此时报告同名冲突。移除源图片时，只清理内容未被修改的旧同步副本，保留手工修改的 public 图片。

同步不生成图片，不缩放、不重编码原图。业务目录、伙伴状态、任务效果和徽章发放机制均不改变。

## 统一映射

```ts
assetMap.characters.xiaowei
assetMap.identity.support
assetMap.backgrounds.Map
assetMap.icons.mission
assetMap.badges[badgeId]
```

保留 `assetMap.xiaowei` 等原调用键。组件 Props/回调接口未改变；页面使用 `assetProp()` 提供确实存在的 icon/avatar，普通图片使用 `resolveAssetUrl()` 和 `AssetImage`。

## fallback

- 缺文件：清单检查后不创建 img，保留角色文字占位、任务图标文字、选项编号、徽章占位或 Paper 背景。
- 404、网络错误、解码失败：原生 img 的 error 事件切换到已有 fallback；业务状态不受影响。
- 图片加载错误后替换成新的 URL：重新尝试加载新 URL。

## 检查

```bash
npm run assets:sync
node scripts/check-assets.mjs
npm run build
```

检查脚本生成 `asset-check.json`，有已登记资源缺失时退出码为 1。当前真实素材 0 张，已登记路径缺失 27 项：伙伴 5、身份 4、背景 8、图标 10。徽章和故事目录未提供业务定义或素材，尚无可核对的预期文件。

已通过构建与缺图/加载失败回退检查。图片同步流程使用隔离临时目录中的系统已有图片验证，测试文件未作为项目视觉素材导入。真实素材及其对应关系仍需提供，之后才能验证真实页面显示。
