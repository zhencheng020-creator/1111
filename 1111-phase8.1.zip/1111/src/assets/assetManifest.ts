// 由 scripts/sync-assets.mjs 生成；列表仅说明实际文件存在。
export const availableAssets: readonly string[] = Object.freeze([]);
