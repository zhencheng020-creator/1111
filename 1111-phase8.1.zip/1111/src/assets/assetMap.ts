import type { IdentityId, PartnerId } from '../data/models.ts';
import type { PageName } from '../router/types.ts';
import { availableAssets } from './assetManifest.ts';

export type AssetCategory = 'characters' | 'identity' | 'backgrounds' | 'icons' | 'badges' | 'stories';
export const assetDirectories: Record<AssetCategory, string> = {
  characters: '/assets/characters/', identity: '/assets/identity/',
  backgrounds: '/assets/backgrounds/', icons: '/assets/icons/',
  badges: '/assets/badges/', stories: '/assets/stories/',
};

/** 文件名对应业务 ID，自动识别已有 PNG/JPG/WebP 等素材。 */
function categoryAssets(category: AssetCategory): Record<string, string> {
  const result: Record<string, string> = {};
  for (const url of availableAssets) {
    if (!url.startsWith(assetDirectories[category])) continue;
    const relative = decodeURIComponent(url.slice(assetDirectories[category].length));
    if (relative.includes('/')) continue;
    const id = relative.replace(/\.[^.]+$/, '');
    if (!result[id] || url.endsWith('.png')) result[id] = url;
  }
  return result;
}

export function assetPath(category: AssetCategory, id: string): string {
  return categoryAssets(category)[id] ?? `${assetDirectories[category]}${encodeURIComponent(id)}.png`;
}
export function catalogAssetPath(relative: string): string {
  return '/assets/' + relative.split('/').map(encodeURIComponent).join('/');
}

const characters: Record<PartnerId, string> = {
  xiaowei: assetPath('characters', 'xiaowei'), chifeng: assetPath('characters', 'chifeng'),
  feiyu: assetPath('characters', 'feiyu'), xiaotuo: assetPath('characters', 'xiaotuo'),
  aniu: assetPath('characters', 'aniu'),
};
const identity: Record<IdentityId, string> = {
  support: assetPath('identity', 'support'), scout: assetPath('identity', 'scout'),
  medical: assetPath('identity', 'medical'), record: assetPath('identity', 'record'),
};
const backgrounds: Record<PageName, string> = {
  Home: assetPath('backgrounds', 'home'), Identity: assetPath('backgrounds', 'identity'),
  Partner: assetPath('backgrounds', 'partner'), Route: assetPath('backgrounds', 'route'),
  Map: assetPath('backgrounds', 'map'), Mission: assetPath('backgrounds', 'mission'),
  Status: assetPath('backgrounds', 'status'), Archive: assetPath('backgrounds', 'archive'),
};
const icons: Record<string, string> = {
  ...categoryAssets('icons'),
  ...Object.fromEntries([
    'mission', 'mission-complete', 'supply-food', 'rest-partner',
    'departure', 'grassland', 'snow-mountain', 'bridge', 'silent-partner', 'finish',
  ].map(id => [id, assetPath('icons', id)])),
};

/** 保留旧角色键；新调用统一按类别访问。 */
export const assetMap = {
  ...characters, characters, identity, backgrounds, icons,
  badges: categoryAssets('badges'), stories: categoryAssets('stories'),
};

/** 只加载清单中确实存在的文件，不再使用人工暂停开关。 */
export const realAssetLoadingEnabled: boolean = availableAssets.length > 0;
export function resolveAssetUrl(path: string | undefined): string | undefined {
  return path && availableAssets.includes(path) ? path : undefined;
}

/** 可选图片 Prop 应省略，不传入显式 undefined，兼容严格类型检查。 */
export function assetProp<K extends 'icon' | 'avatar'>(key: K, path: string | undefined): Partial<Record<K, string>> {
  const url = resolveAssetUrl(path);
  return url ? { [key]: url } as Record<K, string> : {};
}

export function getAssetDiagnostics() {
  const registered = [...new Set([
    ...Object.values(characters), ...Object.values(identity), ...Object.values(backgrounds),
    ...Object.values(icons), ...Object.values(assetMap.badges), ...Object.values(assetMap.stories),
  ])];
  return {
    available: [...availableAssets],
    missing: registered.filter(path => !resolveAssetUrl(path)),
    unmapped: availableAssets.filter(path => !registered.includes(path)),
  };
}
