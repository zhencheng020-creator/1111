import assert from 'node:assert/strict';
import { after, afterEach, test } from 'node:test';
import { Window } from 'happy-dom';
import type { PageName } from '../src/router/types.ts';

const window = new Window({ url: 'http://localhost/' });
for (const [name, value] of Object.entries({
  window, document: window.document, navigator: window.navigator,
  history: window.history, location: window.location,
  Element: window.Element, HTMLElement: window.HTMLElement, SVGElement: window.SVGElement, Node: window.Node,
})) Object.defineProperty(globalThis, name, { value, configurable: true, writable: true });

const { mount, flushPromises, enableAutoUnmount } = await import('@vue/test-utils');
const { nextTick } = await import('vue');
const { createPinia } = await import('pinia');
const { createMemoryHistory } = await import('vue-router');
const { createAppRouter } = await import('../src/router/appRouter.ts');
const { default: App } = await import('../src/App.ts');
const { IdentityCard, PartnerCard, RouteCard, MissionCard, MapNode, Button } = await import('../src/components/index.ts');
const { useUserStore, usePartnerStore, useRouteStore, useMissionStore, useResourceStore } = await import('../src/store/index.ts');
const { assetMap, realAssetLoadingEnabled, resolveAssetUrl } = await import('../src/assets/assetMap.ts');
const { availableAssets } = await import('../src/assets/assetManifest.ts');
enableAutoUnmount(hook => { afterEach(hook); });
after(() => { window.close(); });

async function page(name: PageName, options: { selected?: boolean; grassland?: boolean } = {}) {
  const pinia = createPinia();
  const user = useUserStore(pinia);
  const partner = usePartnerStore(pinia);
  const route = useRouteStore(pinia);
  const resources = useResourceStore(pinia);
  const mission = useMissionStore(pinia);
  if (options.selected) {
    user.selectIdentity('support'); user.selectPartner('xiaowei'); user.selectRoute('easy');
  }
  if (options.grassland) {
    // 仅为单页绑定测试准备状态，不执行完整体验流程。
    route.completeNode('departure'); route.unlockNode('grassland');
  }
  const router = createAppRouter(pinia, createMemoryHistory());
  await router.push(name === 'Mission' ? { name, params: { missionId: 'grassland-supply' } } : { name });
  await router.isReady();
  const wrapper = mount(App, { global: { plugins: [pinia, router] } });
  await flushPromises();
  return { wrapper, router, user, partner, route, resources, mission };
}

test('Home 的开始同行按钮进入 Identity，未选择时下一步不可用', async () => {
  const s = await page('Home');
  assert.equal(s.wrapper.find('[data-page]').attributes('data-page'), 'Home');
  await s.wrapper.findComponent(Button).trigger('click');
  await flushPromises();
  assert.equal(s.router.currentRoute.value.name, 'Identity');
  const next = s.wrapper.findAllComponents(Button).find(button => button.props('text') === '下一步')!;
  assert.equal(next.props('disabled'), true);
});

test('Identity 选择回调写入 userStore，并由 store 控制 selected', async () => {
  const s = await page('Identity');
  const identity = s.wrapper.findAllComponents(IdentityCard).find(card => card.props('id') === 'scout')!;
  await identity.trigger('click');
  await nextTick();
  assert.equal(s.user.identity, 'scout');
  assert.equal(identity.props('selected'), true);
  assert.equal(s.wrapper.findAllComponents(IdentityCard).filter(card => card.props('selected')).length, 1);
  const next = s.wrapper.findAllComponents(Button).find(button => button.props('text') === '下一步')!;
  assert.equal(next.props('disabled'), false);
});

test('Partner 选择初始化伙伴，卡片状态响应 partnerStore 的实时变化', async () => {
  const s = await page('Partner', { selected: true });
  const card = s.wrapper.findAllComponents(PartnerCard).find(card => card.props('id') === 'chifeng')!;
  await card.trigger('click');
  assert.equal(s.user.partner, 'chifeng');
  assert.equal(s.partner.partner?.id, 'chifeng');
  s.partner.increaseComfort(2);
  await nextTick();
  assert.equal(card.props('selected'), true);
  assert.equal(card.props('energy'), 5);
  assert.equal(card.props('comfort'), 6);
  assert.equal(card.props('trust'), 5);
});

test('Route 选择同步用户路线和 routeStore，选中状态由 routeStore 控制', async () => {
  const s = await page('Route', { selected: true });
  const card = s.wrapper.findAllComponents(RouteCard).find(card => card.props('id') === 'challenge')!;
  await card.trigger('click');
  await nextTick();
  assert.equal(s.user.route, 'challenge');
  assert.equal(s.route.routeId, 'challenge');
  assert.equal(card.props('selected'), true);
});

test('Map 读取六个节点，锁定节点不跳转，current 进入对应 Mission', async () => {
  const s = await page('Map', { selected: true });
  const nodes = s.wrapper.findAllComponents(MapNode);
  assert.equal(nodes.length, 6);
  await nodes.find(node => node.props('status') === 'locked')!.trigger('click');
  await flushPromises();
  assert.equal(s.router.currentRoute.value.name, 'Map');
  await nodes.find(node => node.props('status') === 'current')!.trigger('click');
  await flushPromises();
  assert.equal(s.router.currentRoute.value.name, 'Mission');
  assert.equal(s.router.currentRoute.value.params.missionId, 'departure');
  assert.ok(s.wrapper.text().includes('本站任务内容尚未提供'));
  assert.equal(s.wrapper.findAllComponents(MissionCard).length, 0);
  assert.equal(s.user.progress, 0);
});

test('Mission 的真实选择事件调用 selectChoice/applyEffect 并显示结果', async () => {
  const s = await page('Mission', { selected: true, grassland: true });
  const mission = s.wrapper.findComponent(MissionCard);
  assert.equal(mission.props('title'), '草地补给站');
  const button = mission.findAllComponents(Button).find(button => button.props('text') === '伙伴休息')!;
  await button.trigger('click');
  await nextTick();
  assert.equal(s.partner.partner?.comfort, 7);
  assert.equal(s.partner.partner?.trust, 6);
  assert.equal(s.user.progress, 1);
  assert.equal(s.route.nodeStatuses.grassland, 'complete');
  assert.equal(s.wrapper.findAllComponents(MissionCard).length, 0);
  assert.ok(s.wrapper.text().includes('舒适度 +2'));
  assert.ok(s.wrapper.text().includes('信任 +1'));
});

test('Status 展示人物和伙伴真实数值，超过初始值不被进度条截断', async () => {
  const s = await page('Status', { selected: true });
  s.partner.increaseComfort(2); s.partner.increaseTrust();
  s.resources.applyDelta({ energy: 3, food: 3, medical: -1 });
  await nextTick();
  const details = Object.fromEntries(s.wrapper.findAll('dt').map(label => [label.text(), label.element.nextElementSibling?.textContent]));
  assert.equal(details['人物体力'], '8');
  assert.equal(details['粮食'], '13');
  assert.equal(details['医疗资源'], '2');
  assert.equal(details['舒适度'], '7');
  assert.equal(details['信任'], '6');
  assert.equal(details['徽章数量'], '0');
  s.partner.applyDelta({ trust: -5 });
  await nextTick();
  assert.ok(s.wrapper.text().includes('伙伴需要照顾'));
});

test('Archive 自动显示中文选择和任务记录，重新同行清除状态并回到 Home', async () => {
  const s = await page('Archive', { selected: true, grassland: true });
  for (const text of ['后勤员', '小卫', '轻体验线', '同行进行中', '暂无完成任务']) assert.ok(s.wrapper.text().includes(text));
  s.mission.openMission('grassland-supply'); s.mission.selectChoice('rest-partner'); s.mission.applyEffect();
  await nextTick();
  assert.ok(s.wrapper.text().includes('草地补给站'));
  const restart = s.wrapper.findAllComponents(Button).find(button => button.props('text') === '重新同行')!;
  await restart.trigger('click');
  await flushPromises();
  assert.equal(s.router.currentRoute.value.name, 'Home');
  assert.equal(s.user.identity, null);
  assert.equal(s.user.progress, 0);
  assert.equal(s.partner.partner, null);
});

test('运行时路由阻止缺少选择的直接访问，刷新后引导恢复选择', async () => {
  const s = await page('Map');
  assert.equal(s.router.currentRoute.value.name, 'Identity');
  s.user.selectIdentity('support');
  await s.router.push({ name: 'Status' });
  assert.equal(s.router.currentRoute.value.name, 'Partner');
  s.user.selectPartner('xiaowei');
  await s.router.push({ name: 'Archive' });
  assert.equal(s.router.currentRoute.value.name, 'Route');
});

test('assetMap 提供角色静态路径，缺少文件时不创建破图', async () => {
  assert.equal(assetMap.xiaowei, '/assets/characters/xiaowei.png');
  assert.equal(assetMap.chifeng, '/assets/characters/chifeng.png');
  assert.equal(resolveAssetUrl('/assets/not-provided.png'), undefined);
  assert.equal(realAssetLoadingEnabled, false);
  assert.equal(resolveAssetUrl(assetMap.xiaowei), undefined);
  const s = await page('Partner', { selected: true });
  for (const image of s.wrapper.findAll('img')) assert.ok(availableAssets.includes(image.attributes('src')!));
  assert.equal(s.wrapper.findAll('img').length, 0);
});
